package p004io.fabric.sdk.android.services.network;

/* renamed from: io.fabric.sdk.android.services.network.HttpMethod */
public enum HttpMethod {
}
