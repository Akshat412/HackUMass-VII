package p004io.fabric.sdk.android.services.common;

/* renamed from: io.fabric.sdk.android.services.common.SystemCurrentTimeProvider */
public class SystemCurrentTimeProvider implements CurrentTimeProvider {
    public SystemCurrentTimeProvider() {
    }

    public long getCurrentTimeMillis() {
        return System.currentTimeMillis();
    }
}
