package p004io.fabric.sdk.android.services.common;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Build.VERSION;
import android.text.TextUtils;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;
import java.util.concurrent.locks.ReentrantLock;
import java.util.regex.Pattern;
import p004io.fabric.sdk.android.Fabric;
import p004io.fabric.sdk.android.Kit;
import p004io.fabric.sdk.android.Logger;

/* renamed from: io.fabric.sdk.android.services.common.IdManager */
public class IdManager {
    private static final String BAD_ANDROID_ID = "9774d56d682e549c";
    public static final String COLLECT_DEVICE_IDENTIFIERS = "com.crashlytics.CollectDeviceIdentifiers";
    public static final String COLLECT_USER_IDENTIFIERS = "com.crashlytics.CollectUserIdentifiers";
    public static final String DEFAULT_VERSION_NAME = "0.0";
    private static final String FORWARD_SLASH_REGEX = Pattern.quote("/");
    private static final Pattern ID_PATTERN = Pattern.compile("[^\\p{Alnum}]");
    static final String PREFKEY_ADVERTISING_ID = "crashlytics.advertising.id";
    private static final String PREFKEY_INSTALLATION_UUID = "crashlytics.installation.id";
    AdvertisingInfo advertisingInfo;
    AdvertisingInfoProvider advertisingInfoProvider;
    private final Context appContext;
    private final String appIdentifier;
    private final String appInstallIdentifier;
    private final boolean collectHardwareIds;
    private final boolean collectUserIds;
    boolean fetchedAdvertisingInfo;
    FirebaseInfo firebaseInfo;
    private final ReentrantLock installationIdLock;
    private final InstallerPackageNameProvider installerPackageNameProvider;
    private final Collection<Kit> kits;

    /* renamed from: io.fabric.sdk.android.services.common.IdManager$DeviceIdentifierType */
    public enum DeviceIdentifierType {
        ;
        
        public final int protobufIndex;

        private DeviceIdentifierType(int i) {
            String str = r8;
            int i2 = r9;
            this.protobufIndex = i;
        }
    }

    public IdManager(Context context, String str, String str2, Collection<Kit> collection) {
        ReentrantLock reentrantLock;
        InstallerPackageNameProvider installerPackageNameProvider2;
        AdvertisingInfoProvider advertisingInfoProvider2;
        FirebaseInfo firebaseInfo2;
        StringBuilder sb;
        StringBuilder sb2;
        IllegalArgumentException illegalArgumentException;
        IllegalArgumentException illegalArgumentException2;
        IllegalArgumentException illegalArgumentException3;
        Context appContext2 = context;
        String appIdentifier2 = str;
        String appInstallIdentifier2 = str2;
        Collection<Kit> kits2 = collection;
        ReentrantLock reentrantLock2 = reentrantLock;
        ReentrantLock reentrantLock3 = new ReentrantLock();
        this.installationIdLock = reentrantLock2;
        if (appContext2 == null) {
            IllegalArgumentException illegalArgumentException4 = illegalArgumentException3;
            IllegalArgumentException illegalArgumentException5 = new IllegalArgumentException("appContext must not be null");
            throw illegalArgumentException4;
        } else if (appIdentifier2 == null) {
            IllegalArgumentException illegalArgumentException6 = illegalArgumentException2;
            IllegalArgumentException illegalArgumentException7 = new IllegalArgumentException("appIdentifier must not be null");
            throw illegalArgumentException6;
        } else if (kits2 == null) {
            IllegalArgumentException illegalArgumentException8 = illegalArgumentException;
            IllegalArgumentException illegalArgumentException9 = new IllegalArgumentException("kits must not be null");
            throw illegalArgumentException8;
        } else {
            this.appContext = appContext2;
            this.appIdentifier = appIdentifier2;
            this.appInstallIdentifier = appInstallIdentifier2;
            this.kits = kits2;
            InstallerPackageNameProvider installerPackageNameProvider3 = installerPackageNameProvider2;
            InstallerPackageNameProvider installerPackageNameProvider4 = new InstallerPackageNameProvider();
            this.installerPackageNameProvider = installerPackageNameProvider3;
            AdvertisingInfoProvider advertisingInfoProvider3 = advertisingInfoProvider2;
            AdvertisingInfoProvider advertisingInfoProvider4 = new AdvertisingInfoProvider(appContext2);
            this.advertisingInfoProvider = advertisingInfoProvider3;
            FirebaseInfo firebaseInfo3 = firebaseInfo2;
            FirebaseInfo firebaseInfo4 = new FirebaseInfo();
            this.firebaseInfo = firebaseInfo3;
            this.collectHardwareIds = CommonUtils.getBooleanResourceValue(appContext2, COLLECT_DEVICE_IDENTIFIERS, true);
            if (!this.collectHardwareIds) {
                Logger logger = Fabric.getLogger();
                String str3 = Fabric.TAG;
                StringBuilder sb3 = sb2;
                StringBuilder sb4 = new StringBuilder();
                logger.mo23829d(str3, sb3.append("Device ID collection disabled for ").append(appContext2.getPackageName()).toString());
            }
            this.collectUserIds = CommonUtils.getBooleanResourceValue(appContext2, COLLECT_USER_IDENTIFIERS, true);
            if (!this.collectUserIds) {
                Logger logger2 = Fabric.getLogger();
                String str4 = Fabric.TAG;
                StringBuilder sb5 = sb;
                StringBuilder sb6 = new StringBuilder();
                logger2.mo23829d(str4, sb5.append("User information collection disabled for ").append(appContext2.getPackageName()).toString());
            }
        }
    }

    @Deprecated
    public String createIdHeaderValue(String str, String str2) {
        String str3 = str;
        String str4 = str2;
        return "";
    }

    public boolean canCollectUserIds() {
        return this.collectUserIds;
    }

    private String formatId(String str) {
        String id = str;
        return id == null ? null : ID_PATTERN.matcher(id).replaceAll("").toLowerCase(Locale.US);
    }

    public String getAppInstallIdentifier() {
        String appInstallId = this.appInstallIdentifier;
        if (appInstallId == null) {
            SharedPreferences prefs = CommonUtils.getSharedPrefs(this.appContext);
            checkAdvertisingIdRotation(prefs);
            appInstallId = prefs.getString(PREFKEY_INSTALLATION_UUID, null);
            if (appInstallId == null) {
                appInstallId = createInstallationUUID(prefs);
            }
        }
        return appInstallId;
    }

    public String getAppIdentifier() {
        return this.appIdentifier;
    }

    public String getOsVersionString() {
        StringBuilder sb;
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        return sb2.append(getOsDisplayVersionString()).append("/").append(getOsBuildVersionString()).toString();
    }

    public String getOsDisplayVersionString() {
        return removeForwardSlashesIn(VERSION.RELEASE);
    }

    public String getOsBuildVersionString() {
        return removeForwardSlashesIn(VERSION.INCREMENTAL);
    }

    public String getModelName() {
        Object[] objArr = new Object[2];
        Object[] objArr2 = objArr;
        objArr[0] = removeForwardSlashesIn(Build.MANUFACTURER);
        Object[] objArr3 = objArr2;
        Object[] objArr4 = objArr3;
        objArr3[1] = removeForwardSlashesIn(Build.MODEL);
        return String.format(Locale.US, "%s/%s", objArr4);
    }

    private String removeForwardSlashesIn(String str) {
        return str.replaceAll(FORWARD_SLASH_REGEX, "");
    }

    /* JADX INFO: finally extract failed */
    @SuppressLint({"CommitPrefEdits"})
    private String createInstallationUUID(SharedPreferences sharedPreferences) {
        SharedPreferences prefs = sharedPreferences;
        this.installationIdLock.lock();
        try {
            String uuid = prefs.getString(PREFKEY_INSTALLATION_UUID, null);
            if (uuid == null) {
                uuid = formatId(UUID.randomUUID().toString());
                boolean commit = prefs.edit().putString(PREFKEY_INSTALLATION_UUID, uuid).commit();
            }
            String str = uuid;
            this.installationIdLock.unlock();
            return str;
        } catch (Throwable th) {
            Throwable th2 = th;
            this.installationIdLock.unlock();
            throw th2;
        }
    }

    private void checkAdvertisingIdRotation(SharedPreferences sharedPreferences) {
        SharedPreferences prefs = sharedPreferences;
        AdvertisingInfo newAdInfo = getAdvertisingInfo();
        if (newAdInfo != null) {
            flushInstallationIdIfNecessary(prefs, newAdInfo.advertisingId);
        }
    }

    @SuppressLint({"CommitPrefEdits"})
    private void flushInstallationIdIfNecessary(SharedPreferences sharedPreferences, String str) {
        SharedPreferences prefs = sharedPreferences;
        String advertisingId = str;
        this.installationIdLock.lock();
        try {
            if (TextUtils.isEmpty(advertisingId)) {
                this.installationIdLock.unlock();
                return;
            }
            String oldId = prefs.getString(PREFKEY_ADVERTISING_ID, null);
            if (TextUtils.isEmpty(oldId)) {
                boolean commit = prefs.edit().putString(PREFKEY_ADVERTISING_ID, advertisingId).commit();
            } else if (!oldId.equals(advertisingId)) {
                boolean commit2 = prefs.edit().remove(PREFKEY_INSTALLATION_UUID).putString(PREFKEY_ADVERTISING_ID, advertisingId).commit();
            }
            this.installationIdLock.unlock();
        } catch (Throwable th) {
            Throwable th2 = th;
            this.installationIdLock.unlock();
            throw th2;
        }
    }

    public Map<DeviceIdentifierType, String> getDeviceIdentifiers() {
        HashMap hashMap;
        HashMap hashMap2 = hashMap;
        HashMap hashMap3 = new HashMap();
        HashMap hashMap4 = hashMap2;
        for (Kit kit : this.kits) {
            if (kit instanceof DeviceIdentifierProvider) {
                for (Entry entry : ((DeviceIdentifierProvider) kit).getDeviceIdentifiers().entrySet()) {
                    putNonNullIdInto(hashMap4, (DeviceIdentifierType) entry.getKey(), (String) entry.getValue());
                }
            }
        }
        return Collections.unmodifiableMap(hashMap4);
    }

    public String getInstallerPackageName() {
        return this.installerPackageNameProvider.getInstallerPackageName(this.appContext);
    }

    public Boolean isLimitAdTrackingEnabled() {
        Boolean toReturn = null;
        if (shouldCollectHardwareIds()) {
            toReturn = explicitCheckLimitAdTracking();
        }
        return toReturn;
    }

    @Deprecated
    public String getAdvertisingId() {
        return null;
    }

    private void putNonNullIdInto(Map<DeviceIdentifierType, String> map, DeviceIdentifierType deviceIdentifierType, String str) {
        Map<DeviceIdentifierType, String> idMap = map;
        DeviceIdentifierType idKey = deviceIdentifierType;
        String idValue = str;
        if (idValue != null) {
            Object put = idMap.put(idKey, idValue);
        }
    }

    @Deprecated
    public String getAndroidId() {
        return null;
    }

    @Deprecated
    public String getTelephonyId() {
        return null;
    }

    @Deprecated
    public String getWifiMacAddress() {
        return null;
    }

    @Deprecated
    public String getBluetoothMacAddress() {
        return null;
    }

    @Deprecated
    public String getSerialNumber() {
        return null;
    }

    /* access modifiers changed from: protected */
    public boolean shouldCollectHardwareIds() {
        return this.collectHardwareIds && !this.firebaseInfo.isFirebaseCrashlyticsEnabled(this.appContext);
    }

    /* access modifiers changed from: 0000 */
    public synchronized AdvertisingInfo getAdvertisingInfo() {
        AdvertisingInfo advertisingInfo2;
        synchronized (this) {
            if (!this.fetchedAdvertisingInfo) {
                this.advertisingInfo = this.advertisingInfoProvider.getAdvertisingInfo();
                this.fetchedAdvertisingInfo = true;
            }
            advertisingInfo2 = this.advertisingInfo;
        }
        return advertisingInfo2;
    }

    private Boolean explicitCheckLimitAdTracking() {
        AdvertisingInfo advertisingInfo2 = getAdvertisingInfo();
        if (advertisingInfo2 != null) {
            return Boolean.valueOf(advertisingInfo2.limitAdTrackingEnabled);
        }
        return null;
    }
}
