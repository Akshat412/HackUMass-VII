package p004io.fabric.sdk.android.services.network;

import java.security.KeyStoreException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import p004io.fabric.sdk.android.Fabric;
import p004io.fabric.sdk.android.Logger;

/* renamed from: io.fabric.sdk.android.services.network.PinningTrustManager */
class PinningTrustManager implements X509TrustManager {
    private static final X509Certificate[] NO_ISSUERS = new X509Certificate[0];
    private static final long PIN_FRESHNESS_DURATION_MILLIS = 15552000000L;
    private final Set<X509Certificate> cache;
    private final long pinCreationTimeMillis;
    private final List<byte[]> pins;
    private final SystemKeyStore systemKeyStore;
    private final TrustManager[] systemTrustManagers;

    public PinningTrustManager(SystemKeyStore systemKeyStore2, PinningInfoProvider pinningInfoProvider) {
        LinkedList linkedList;
        HashSet hashSet;
        SystemKeyStore keyStore = systemKeyStore2;
        PinningInfoProvider pinningInfoProvider2 = pinningInfoProvider;
        LinkedList linkedList2 = linkedList;
        LinkedList linkedList3 = new LinkedList();
        this.pins = linkedList2;
        HashSet hashSet2 = hashSet;
        HashSet hashSet3 = new HashSet();
        this.cache = Collections.synchronizedSet(hashSet2);
        this.systemTrustManagers = initializeSystemTrustManagers(keyStore);
        this.systemKeyStore = keyStore;
        this.pinCreationTimeMillis = pinningInfoProvider2.getPinCreationTimeInMillis();
        String[] pins2 = pinningInfoProvider2.getPins();
        int length = pins2.length;
        for (int i = 0; i < length; i++) {
            boolean add = this.pins.add(hexStringToByteArray(pins2[i]));
        }
    }

    private TrustManager[] initializeSystemTrustManagers(SystemKeyStore systemKeyStore2) {
        AssertionError assertionError;
        AssertionError assertionError2;
        SystemKeyStore keyStore = systemKeyStore2;
        try {
            TrustManagerFactory tmf = TrustManagerFactory.getInstance("X509");
            tmf.init(keyStore.trustStore);
            return tmf.getTrustManagers();
        } catch (NoSuchAlgorithmException e) {
            NoSuchAlgorithmException nsae = e;
            AssertionError assertionError3 = assertionError2;
            AssertionError assertionError4 = new AssertionError(nsae);
            throw assertionError3;
        } catch (KeyStoreException e2) {
            KeyStoreException e3 = e2;
            AssertionError assertionError5 = assertionError;
            AssertionError assertionError6 = new AssertionError(e3);
            throw assertionError5;
        }
    }

    private boolean isValidPin(X509Certificate x509Certificate) throws CertificateException {
        CertificateException certificateException;
        X509Certificate certificate = x509Certificate;
        try {
            byte[] pin = MessageDigest.getInstance("SHA1").digest(certificate.getPublicKey().getEncoded());
            for (byte[] equals : this.pins) {
                if (Arrays.equals(equals, pin)) {
                    return true;
                }
            }
            return false;
        } catch (NoSuchAlgorithmException e) {
            NoSuchAlgorithmException nsae = e;
            CertificateException certificateException2 = certificateException;
            CertificateException certificateException3 = new CertificateException(nsae);
            throw certificateException2;
        }
    }

    private void checkSystemTrust(X509Certificate[] x509CertificateArr, String str) throws CertificateException {
        X509Certificate[] chain = x509CertificateArr;
        String authType = str;
        TrustManager[] trustManagerArr = this.systemTrustManagers;
        int length = trustManagerArr.length;
        for (int i = 0; i < length; i++) {
            ((X509TrustManager) trustManagerArr[i]).checkServerTrusted(chain, authType);
        }
    }

    private void checkPinTrust(X509Certificate[] x509CertificateArr) throws CertificateException {
        CertificateException certificateException;
        StringBuilder sb;
        X509Certificate[] chain = x509CertificateArr;
        if (this.pinCreationTimeMillis == -1 || System.currentTimeMillis() - this.pinCreationTimeMillis <= PIN_FRESHNESS_DURATION_MILLIS) {
            X509Certificate[] cleanChain = CertificateChainCleaner.getCleanChain(chain, this.systemKeyStore);
            int length = cleanChain.length;
            int i = 0;
            while (i < length) {
                if (!isValidPin(cleanChain[i])) {
                    i++;
                } else {
                    return;
                }
            }
            CertificateException certificateException2 = certificateException;
            CertificateException certificateException3 = new CertificateException("No valid pins found in chain!");
            throw certificateException2;
        }
        Logger logger = Fabric.getLogger();
        String str = Fabric.TAG;
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        logger.mo23842w(str, sb2.append("Certificate pins are stale, (").append(System.currentTimeMillis() - this.pinCreationTimeMillis).append(" millis vs ").append(PIN_FRESHNESS_DURATION_MILLIS).append(" millis) falling back to system trust.").toString());
    }

    public void checkClientTrusted(X509Certificate[] x509CertificateArr, String str) throws CertificateException {
        CertificateException certificateException;
        X509Certificate[] x509CertificateArr2 = x509CertificateArr;
        String str2 = str;
        CertificateException certificateException2 = certificateException;
        CertificateException certificateException3 = new CertificateException("Client certificates not supported!");
        throw certificateException2;
    }

    public void checkServerTrusted(X509Certificate[] x509CertificateArr, String str) throws CertificateException {
        X509Certificate[] chain = x509CertificateArr;
        String authType = str;
        if (!this.cache.contains(chain[0])) {
            checkSystemTrust(chain, authType);
            checkPinTrust(chain);
            boolean add = this.cache.add(chain[0]);
        }
    }

    public X509Certificate[] getAcceptedIssuers() {
        return NO_ISSUERS;
    }

    private byte[] hexStringToByteArray(String str) {
        String s = str;
        int len = s.length();
        byte[] data = new byte[(len / 2)];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i + 1), 16));
        }
        return data;
    }
}
