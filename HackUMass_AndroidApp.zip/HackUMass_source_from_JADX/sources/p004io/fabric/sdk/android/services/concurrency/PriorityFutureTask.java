package p004io.fabric.sdk.android.services.concurrency;

import java.util.Collection;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

/* renamed from: io.fabric.sdk.android.services.concurrency.PriorityFutureTask */
public class PriorityFutureTask<V> extends FutureTask<V> implements Dependency<Task>, PriorityProvider, Task, DelegateProvider {
    final Object delegate;

    public PriorityFutureTask(Callable<V> callable) {
        Callable<V> callable2 = callable;
        super(callable2);
        this.delegate = checkAndInitDelegate(callable2);
    }

    public PriorityFutureTask(Runnable runnable, V v) {
        Runnable runnable2 = runnable;
        super(runnable2, v);
        this.delegate = checkAndInitDelegate(runnable2);
    }

    public int compareTo(Object obj) {
        return ((PriorityProvider) getDelegate()).compareTo(obj);
    }

    public void addDependency(Task task) {
        Task task2 = task;
        ((Dependency) ((PriorityProvider) getDelegate())).addDependency(task2);
    }

    public Collection<Task> getDependencies() {
        return ((Dependency) ((PriorityProvider) getDelegate())).getDependencies();
    }

    public boolean areDependenciesMet() {
        return ((Dependency) ((PriorityProvider) getDelegate())).areDependenciesMet();
    }

    public Priority getPriority() {
        return ((PriorityProvider) getDelegate()).getPriority();
    }

    public void setFinished(boolean z) {
        boolean finished = z;
        ((Task) ((PriorityProvider) getDelegate())).setFinished(finished);
    }

    public boolean isFinished() {
        return ((Task) ((PriorityProvider) getDelegate())).isFinished();
    }

    public void setError(Throwable th) {
        Throwable throwable = th;
        ((Task) ((PriorityProvider) getDelegate())).setError(throwable);
    }

    public Throwable getError() {
        return ((Task) ((PriorityProvider) getDelegate())).getError();
    }

    public <T extends Dependency<Task> & PriorityProvider & Task> T getDelegate() {
        return (Dependency) this.delegate;
    }

    /* access modifiers changed from: protected */
    public <T extends Dependency<Task> & PriorityProvider & Task> T checkAndInitDelegate(Object obj) {
        PriorityTask priorityTask;
        Object object = obj;
        if (PriorityTask.isProperDelegate(object)) {
            return (Dependency) object;
        }
        PriorityTask priorityTask2 = priorityTask;
        PriorityTask priorityTask3 = new PriorityTask();
        return priorityTask2;
    }
}
