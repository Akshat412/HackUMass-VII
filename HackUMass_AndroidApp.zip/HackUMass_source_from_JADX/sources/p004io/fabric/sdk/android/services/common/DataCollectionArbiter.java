package p004io.fabric.sdk.android.services.common;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import p004io.fabric.sdk.android.Fabric;

/* renamed from: io.fabric.sdk.android.services.common.DataCollectionArbiter */
public class DataCollectionArbiter {
    private static final String FIREBASE_CRASHLYTICS_COLLECTION_ENABLED = "firebase_crashlytics_collection_enabled";
    private static final String FIREBASE_CRASHLYTICS_PREFS = "com.google.firebase.crashlytics.prefs";
    private static DataCollectionArbiter instance;
    private static Object instanceLock;
    private volatile boolean crashlyticsDataCollectionEnabled;
    private volatile boolean crashlyticsDataCollectionExplicitlySet;
    private final FirebaseApp firebaseApp;
    private boolean isUnity = false;
    private final SharedPreferences sharedPreferences;

    static {
        Object obj;
        Object obj2 = obj;
        Object obj3 = new Object();
        instanceLock = obj2;
    }

    public static DataCollectionArbiter getInstance(Context context) {
        DataCollectionArbiter dataCollectionArbiter;
        Context applicationContext = context;
        Object obj = instanceLock;
        Object obj2 = obj;
        synchronized (obj) {
            try {
                if (instance == null) {
                    DataCollectionArbiter dataCollectionArbiter2 = dataCollectionArbiter;
                    DataCollectionArbiter dataCollectionArbiter3 = new DataCollectionArbiter(applicationContext);
                    instance = dataCollectionArbiter2;
                }
                DataCollectionArbiter dataCollectionArbiter4 = instance;
                return dataCollectionArbiter4;
            } catch (Throwable th) {
                Throwable th2 = th;
                Object obj3 = obj2;
                throw th2;
            }
        }
    }

    public static void resetForTesting(Context context) {
        DataCollectionArbiter dataCollectionArbiter;
        Context newContext = context;
        Object obj = instanceLock;
        Object obj2 = obj;
        synchronized (obj) {
            try {
                DataCollectionArbiter dataCollectionArbiter2 = dataCollectionArbiter;
                DataCollectionArbiter dataCollectionArbiter3 = new DataCollectionArbiter(newContext);
                instance = dataCollectionArbiter2;
            } catch (Throwable th) {
                Throwable th2 = th;
                Object obj3 = obj2;
                throw th2;
            }
        }
    }

    private DataCollectionArbiter(Context context) {
        RuntimeException runtimeException;
        Context applicationContext = context;
        if (applicationContext == null) {
            RuntimeException runtimeException2 = runtimeException;
            RuntimeException runtimeException3 = new RuntimeException("null context");
            throw runtimeException2;
        }
        this.sharedPreferences = applicationContext.getSharedPreferences(FIREBASE_CRASHLYTICS_PREFS, 0);
        this.firebaseApp = FirebaseAppImpl.getInstance(applicationContext);
        boolean enabled = true;
        boolean explicitlySet = false;
        if (this.sharedPreferences.contains(FIREBASE_CRASHLYTICS_COLLECTION_ENABLED)) {
            enabled = this.sharedPreferences.getBoolean(FIREBASE_CRASHLYTICS_COLLECTION_ENABLED, true);
            explicitlySet = true;
        } else {
            try {
                PackageManager packageManager = applicationContext.getPackageManager();
                if (packageManager != null) {
                    ApplicationInfo applicationInfo = packageManager.getApplicationInfo(applicationContext.getPackageName(), 128);
                    if (!(applicationInfo == null || applicationInfo.metaData == null || !applicationInfo.metaData.containsKey(FIREBASE_CRASHLYTICS_COLLECTION_ENABLED))) {
                        enabled = applicationInfo.metaData.getBoolean(FIREBASE_CRASHLYTICS_COLLECTION_ENABLED);
                        explicitlySet = true;
                    }
                }
            } catch (NameNotFoundException e) {
                Fabric.getLogger().mo23830d(Fabric.TAG, "Unable to get PackageManager. Falling through", e);
            }
        }
        this.crashlyticsDataCollectionEnabled = enabled;
        this.crashlyticsDataCollectionExplicitlySet = explicitlySet;
        this.isUnity = CommonUtils.resolveUnityEditorVersion(applicationContext) != null;
    }

    public boolean isDataCollectionEnabled() {
        if (this.isUnity && this.crashlyticsDataCollectionExplicitlySet) {
            return this.crashlyticsDataCollectionEnabled;
        }
        if (this.firebaseApp != null) {
            return this.firebaseApp.isDataCollectionDefaultEnabled();
        }
        return true;
    }

    public boolean shouldAutoInitialize() {
        return this.crashlyticsDataCollectionEnabled;
    }

    @SuppressLint({"CommitPrefEdits", "ApplySharedPref"})
    public void setCrashlyticsDataCollectionEnabled(boolean z) {
        boolean enabled = z;
        this.crashlyticsDataCollectionEnabled = enabled;
        this.crashlyticsDataCollectionExplicitlySet = true;
        boolean commit = this.sharedPreferences.edit().putBoolean(FIREBASE_CRASHLYTICS_COLLECTION_ENABLED, enabled).commit();
    }
}
