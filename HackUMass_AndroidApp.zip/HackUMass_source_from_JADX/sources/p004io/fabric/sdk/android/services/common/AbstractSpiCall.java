package p004io.fabric.sdk.android.services.common;

import java.util.Collections;
import java.util.Map;
import java.util.regex.Pattern;
import p004io.fabric.sdk.android.Kit;
import p004io.fabric.sdk.android.services.network.HttpMethod;
import p004io.fabric.sdk.android.services.network.HttpRequest;
import p004io.fabric.sdk.android.services.network.HttpRequestFactory;

/* renamed from: io.fabric.sdk.android.services.common.AbstractSpiCall */
public abstract class AbstractSpiCall {
    public static final String ACCEPT_JSON_VALUE = "application/json";
    public static final String ANDROID_CLIENT_TYPE = "android";
    public static final String CLS_ANDROID_SDK_DEVELOPER_TOKEN = "470fa2b4ae81cd56ecbcda9735803434cec591fa";
    public static final String CRASHLYTICS_USER_AGENT = "Crashlytics Android SDK/";
    public static final int DEFAULT_TIMEOUT = 10000;
    public static final String HEADER_ACCEPT = "Accept";
    public static final String HEADER_API_KEY = "X-CRASHLYTICS-API-KEY";
    public static final String HEADER_CLIENT_TYPE = "X-CRASHLYTICS-API-CLIENT-TYPE";
    public static final String HEADER_CLIENT_VERSION = "X-CRASHLYTICS-API-CLIENT-VERSION";
    public static final String HEADER_DEVELOPER_TOKEN = "X-CRASHLYTICS-DEVELOPER-TOKEN";
    public static final String HEADER_REQUEST_ID = "X-REQUEST-ID";
    public static final String HEADER_USER_AGENT = "User-Agent";
    private static final Pattern PROTOCOL_AND_HOST_PATTERN = Pattern.compile("http(s?)://[^\\/]+", 2);
    protected final Kit kit;
    private final HttpMethod method;
    private final String protocolAndHostOverride;
    private final HttpRequestFactory requestFactory;
    private final String url;

    public AbstractSpiCall(Kit kit2, String str, String str2, HttpRequestFactory httpRequestFactory, HttpMethod httpMethod) {
        IllegalArgumentException illegalArgumentException;
        IllegalArgumentException illegalArgumentException2;
        Kit kit3 = kit2;
        String protocolAndHostOverride2 = str;
        String url2 = str2;
        HttpRequestFactory requestFactory2 = httpRequestFactory;
        HttpMethod method2 = httpMethod;
        if (url2 == null) {
            IllegalArgumentException illegalArgumentException3 = illegalArgumentException2;
            IllegalArgumentException illegalArgumentException4 = new IllegalArgumentException("url must not be null.");
            throw illegalArgumentException3;
        } else if (requestFactory2 == null) {
            IllegalArgumentException illegalArgumentException5 = illegalArgumentException;
            IllegalArgumentException illegalArgumentException6 = new IllegalArgumentException("requestFactory must not be null.");
            throw illegalArgumentException5;
        } else {
            this.kit = kit3;
            this.protocolAndHostOverride = protocolAndHostOverride2;
            this.url = overrideProtocolAndHost(url2);
            this.requestFactory = requestFactory2;
            this.method = method2;
        }
    }

    /* access modifiers changed from: protected */
    public String getUrl() {
        return this.url;
    }

    /* access modifiers changed from: protected */
    public HttpRequest getHttpRequest() {
        return getHttpRequest(Collections.emptyMap());
    }

    /* access modifiers changed from: protected */
    public HttpRequest getHttpRequest(Map<String, String> map) {
        StringBuilder sb;
        Map<String, String> queryParams = map;
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        return this.requestFactory.buildHttpRequest(this.method, getUrl(), queryParams).useCaches(false).connectTimeout(DEFAULT_TIMEOUT).header("User-Agent", sb2.append(CRASHLYTICS_USER_AGENT).append(this.kit.getVersion()).toString()).header(HEADER_DEVELOPER_TOKEN, "470fa2b4ae81cd56ecbcda9735803434cec591fa");
    }

    private String overrideProtocolAndHost(String str) {
        String url2 = str;
        String toReturn = url2;
        if (!CommonUtils.isNullOrEmpty(this.protocolAndHostOverride)) {
            toReturn = PROTOCOL_AND_HOST_PATTERN.matcher(url2).replaceFirst(this.protocolAndHostOverride);
        }
        return toReturn;
    }
}
