package p004io.fabric.sdk.android.services.network;

import java.security.GeneralSecurityException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.LinkedList;

/* renamed from: io.fabric.sdk.android.services.network.CertificateChainCleaner */
final class CertificateChainCleaner {
    private CertificateChainCleaner() {
    }

    public static X509Certificate[] getCleanChain(X509Certificate[] x509CertificateArr, SystemKeyStore systemKeyStore) throws CertificateException {
        LinkedList linkedList;
        CertificateException certificateException;
        X509Certificate[] chain = x509CertificateArr;
        SystemKeyStore systemKeyStore2 = systemKeyStore;
        LinkedList linkedList2 = linkedList;
        LinkedList linkedList3 = new LinkedList();
        LinkedList linkedList4 = linkedList2;
        boolean trustedChain = false;
        if (systemKeyStore2.isTrustRoot(chain[0])) {
            trustedChain = true;
        }
        boolean add = linkedList4.add(chain[0]);
        int i = 1;
        while (i < chain.length) {
            if (systemKeyStore2.isTrustRoot(chain[i])) {
                trustedChain = true;
            }
            if (!isValidLink(chain[i], chain[i - 1])) {
                break;
            }
            boolean add2 = linkedList4.add(chain[i]);
            i++;
        }
        X509Certificate trustRoot = systemKeyStore2.getTrustRootFor(chain[i - 1]);
        if (trustRoot != null) {
            boolean add3 = linkedList4.add(trustRoot);
            trustedChain = true;
        }
        if (trustedChain) {
            return (X509Certificate[]) linkedList4.toArray(new X509Certificate[linkedList4.size()]);
        }
        CertificateException certificateException2 = certificateException;
        CertificateException certificateException3 = new CertificateException("Didn't find a trust anchor in chain cleanup!");
        throw certificateException2;
    }

    private static boolean isValidLink(X509Certificate x509Certificate, X509Certificate x509Certificate2) {
        X509Certificate parent = x509Certificate;
        X509Certificate child = x509Certificate2;
        if (!parent.getSubjectX500Principal().equals(child.getIssuerX500Principal())) {
            return false;
        }
        try {
            child.verify(parent.getPublicKey());
            return true;
        } catch (GeneralSecurityException e) {
            GeneralSecurityException generalSecurityException = e;
            return false;
        }
    }
}
