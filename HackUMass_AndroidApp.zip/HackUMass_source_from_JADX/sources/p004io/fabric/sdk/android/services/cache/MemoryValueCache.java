package p004io.fabric.sdk.android.services.cache;

import android.content.Context;

/* renamed from: io.fabric.sdk.android.services.cache.MemoryValueCache */
public class MemoryValueCache<T> extends AbstractValueCache<T> {
    private T value;

    public MemoryValueCache() {
        this(null);
    }

    public MemoryValueCache(ValueCache<T> valueCache) {
        super(valueCache);
    }

    /* access modifiers changed from: protected */
    public void doInvalidate(Context context) {
        Context context2 = context;
        this.value = null;
    }

    /* access modifiers changed from: protected */
    public T getCached(Context context) {
        Context context2 = context;
        return this.value;
    }

    /* access modifiers changed from: protected */
    public void cacheValue(Context context, T t) {
        Context context2 = context;
        T t2 = t;
        this.value = t2;
    }
}
