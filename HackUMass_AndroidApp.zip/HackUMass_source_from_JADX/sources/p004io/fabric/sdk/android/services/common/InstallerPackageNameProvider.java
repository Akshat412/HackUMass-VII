package p004io.fabric.sdk.android.services.common;

import android.content.Context;
import p004io.fabric.sdk.android.Fabric;
import p004io.fabric.sdk.android.services.cache.MemoryValueCache;
import p004io.fabric.sdk.android.services.cache.ValueLoader;

/* renamed from: io.fabric.sdk.android.services.common.InstallerPackageNameProvider */
public class InstallerPackageNameProvider {
    private static final String NO_INSTALLER_PACKAGE_NAME = "";
    private final MemoryValueCache<String> installerPackageNameCache;
    private final ValueLoader<String> installerPackageNameLoader;

    public InstallerPackageNameProvider() {
        C14981 r5;
        MemoryValueCache<String> memoryValueCache;
        C14981 r2 = r5;
        C14981 r3 = new ValueLoader<String>(this) {
            final /* synthetic */ InstallerPackageNameProvider this$0;

            {
                this.this$0 = r5;
            }

            public String load(Context context) throws Exception {
                Context context2 = context;
                String installerPackageName = context2.getPackageManager().getInstallerPackageName(context2.getPackageName());
                return installerPackageName == null ? "" : installerPackageName;
            }
        };
        this.installerPackageNameLoader = r2;
        MemoryValueCache<String> memoryValueCache2 = memoryValueCache;
        MemoryValueCache<String> memoryValueCache3 = new MemoryValueCache<>();
        this.installerPackageNameCache = memoryValueCache2;
    }

    public String getInstallerPackageName(Context context) {
        try {
            String name = (String) this.installerPackageNameCache.get(context, this.installerPackageNameLoader);
            return "".equals(name) ? null : name;
        } catch (Exception e) {
            Fabric.getLogger().mo23832e(Fabric.TAG, "Failed to determine installer package name", e);
            return null;
        }
    }
}
