package p004io.fabric.sdk.android.services.network;

import com.google.appinventor.components.runtime.util.Ev3Constants.Opcode;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.Flushable;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.zip.GZIPInputStream;
import org.shaded.apache.http.protocol.HTTP;

/* renamed from: io.fabric.sdk.android.services.network.HttpRequest */
public class HttpRequest {
    private static final String BOUNDARY = "00content0boundary00";
    public static final String CHARSET_UTF8 = "UTF-8";
    private static ConnectionFactory CONNECTION_FACTORY = ConnectionFactory.DEFAULT;
    public static final String CONTENT_TYPE_FORM = "application/x-www-form-urlencoded";
    public static final String CONTENT_TYPE_JSON = "application/json";
    private static final String CONTENT_TYPE_MULTIPART = "multipart/form-data; boundary=00content0boundary00";
    private static final String CRLF = "\r\n";
    private static final String[] EMPTY_STRINGS = new String[0];
    public static final String ENCODING_GZIP = "gzip";
    public static final String HEADER_ACCEPT = "Accept";
    public static final String HEADER_ACCEPT_CHARSET = "Accept-Charset";
    public static final String HEADER_ACCEPT_ENCODING = "Accept-Encoding";
    public static final String HEADER_AUTHORIZATION = "Authorization";
    public static final String HEADER_CACHE_CONTROL = "Cache-Control";
    public static final String HEADER_CONTENT_ENCODING = "Content-Encoding";
    public static final String HEADER_CONTENT_LENGTH = "Content-Length";
    public static final String HEADER_CONTENT_TYPE = "Content-Type";
    public static final String HEADER_DATE = "Date";
    public static final String HEADER_ETAG = "ETag";
    public static final String HEADER_EXPIRES = "Expires";
    public static final String HEADER_IF_NONE_MATCH = "If-None-Match";
    public static final String HEADER_LAST_MODIFIED = "Last-Modified";
    public static final String HEADER_LOCATION = "Location";
    public static final String HEADER_PROXY_AUTHORIZATION = "Proxy-Authorization";
    public static final String HEADER_REFERER = "Referer";
    public static final String HEADER_SERVER = "Server";
    public static final String HEADER_USER_AGENT = "User-Agent";
    public static final String METHOD_DELETE = "DELETE";
    public static final String METHOD_GET = "GET";
    public static final String METHOD_HEAD = "HEAD";
    public static final String METHOD_OPTIONS = "OPTIONS";
    public static final String METHOD_POST = "POST";
    public static final String METHOD_PUT = "PUT";
    public static final String METHOD_TRACE = "TRACE";
    public static final String PARAM_CHARSET = "charset";
    /* access modifiers changed from: private */
    public int bufferSize = 8192;
    private HttpURLConnection connection = null;
    private boolean form;
    private String httpProxyHost;
    private int httpProxyPort;
    private boolean ignoreCloseExceptions = true;
    private boolean multipart;
    private RequestOutputStream output;
    private final String requestMethod;
    private boolean uncompress = false;
    public final URL url;

    /* renamed from: io.fabric.sdk.android.services.network.HttpRequest$Base64 */
    public static class Base64 {
        private static final byte EQUALS_SIGN = 61;
        private static final String PREFERRED_ENCODING = "US-ASCII";
        private static final byte[] _STANDARD_ALPHABET = {Opcode.JR_FALSE, Opcode.JR_TRUE, Opcode.JR_NAN, Opcode.CP_LT8, Opcode.CP_LT16, Opcode.CP_LT32, Opcode.CP_LTF, Opcode.CP_GT8, Opcode.CP_GT16, Opcode.CP_GT32, Opcode.CP_GTF, Opcode.CP_EQ8, Opcode.CP_EQ16, Opcode.CP_EQ32, Opcode.CP_EQF, Opcode.CP_NEQ8, Opcode.CP_NEQ16, Opcode.CP_NEQ32, Opcode.CP_NEQF, Opcode.CP_LTEQ8, Opcode.CP_LTEQ16, Opcode.CP_LTEQ32, Opcode.CP_LTEQF, Opcode.CP_GTEQ8, Opcode.CP_GTEQ16, Opcode.CP_GTEQ32, Opcode.PORT_CNV_OUTPUT, Opcode.PORT_CNV_INPUT, Opcode.NOTE_TO_FREQ, Opcode.JR_LT8, Opcode.JR_LT16, Opcode.JR_LT32, Opcode.JR_LTF, Opcode.JR_GT8, Opcode.JR_GT16, Opcode.JR_GT32, Opcode.JR_GTF, Opcode.JR_EQ8, Opcode.JR_EQ16, Opcode.JR_EQ32, Opcode.JR_EQF, Opcode.JR_NEQ8, Opcode.JR_NEQ16, Opcode.JR_NEQ32, Opcode.JR_NEQF, Opcode.JR_LTEQ8, Opcode.JR_LTEQ16, Opcode.JR_LTEQ32, Opcode.JR_LTEQF, Opcode.JR_GTEQ8, Opcode.JR_GTEQ16, Opcode.JR_GTEQ32, Opcode.MOVE8_8, Opcode.MOVE8_16, Opcode.MOVE8_32, Opcode.MOVE8_F, Opcode.MOVE16_8, Opcode.MOVE16_16, Opcode.MOVE16_32, Opcode.MOVE16_F, Opcode.MOVE32_8, Opcode.MOVE32_16, 43, Opcode.INIT_BYTES};

        private Base64() {
        }

        private static byte[] encode3to4(byte[] bArr, int i, int i2, byte[] bArr2, int i3) {
            byte[] source = bArr;
            int srcOffset = i;
            int numSigBytes = i2;
            byte[] destination = bArr2;
            int destOffset = i3;
            byte[] ALPHABET = _STANDARD_ALPHABET;
            int inBuff = (numSigBytes > 0 ? (source[srcOffset] << 24) >>> 8 : 0) | (numSigBytes > 1 ? (source[srcOffset + 1] << 24) >>> 16 : 0) | (numSigBytes > 2 ? (source[srcOffset + 2] << 24) >>> 24 : 0);
            switch (numSigBytes) {
                case 1:
                    destination[destOffset] = ALPHABET[inBuff >>> 18];
                    destination[destOffset + 1] = ALPHABET[(inBuff >>> 12) & 63];
                    destination[destOffset + 2] = 61;
                    destination[destOffset + 3] = 61;
                    return destination;
                case 2:
                    destination[destOffset] = ALPHABET[inBuff >>> 18];
                    destination[destOffset + 1] = ALPHABET[(inBuff >>> 12) & 63];
                    destination[destOffset + 2] = ALPHABET[(inBuff >>> 6) & 63];
                    destination[destOffset + 3] = 61;
                    return destination;
                case 3:
                    destination[destOffset] = ALPHABET[inBuff >>> 18];
                    destination[destOffset + 1] = ALPHABET[(inBuff >>> 12) & 63];
                    destination[destOffset + 2] = ALPHABET[(inBuff >>> 6) & 63];
                    destination[destOffset + 3] = ALPHABET[inBuff & 63];
                    return destination;
                default:
                    return destination;
            }
        }

        public static String encode(String str) {
            byte[] bytes;
            String string = str;
            try {
                bytes = string.getBytes("US-ASCII");
            } catch (UnsupportedEncodingException e) {
                UnsupportedEncodingException unsupportedEncodingException = e;
                bytes = string.getBytes();
            }
            return encodeBytes(bytes);
        }

        public static String encodeBytes(byte[] bArr) {
            byte[] source = bArr;
            return encodeBytes(source, 0, source.length);
        }

        public static String encodeBytes(byte[] bArr, int i, int i2) {
            String str;
            String str2;
            byte[] encoded = encodeBytesToBytes(bArr, i, i2);
            try {
                String str3 = str2;
                String str4 = new String(encoded, "US-ASCII");
                return str3;
            } catch (UnsupportedEncodingException e) {
                UnsupportedEncodingException unsupportedEncodingException = e;
                String str5 = str;
                String str6 = new String(encoded);
                return str5;
            }
        }

        public static byte[] encodeBytesToBytes(byte[] bArr, int i, int i2) {
            IllegalArgumentException illegalArgumentException;
            IllegalArgumentException illegalArgumentException2;
            StringBuilder sb;
            IllegalArgumentException illegalArgumentException3;
            StringBuilder sb2;
            NullPointerException nullPointerException;
            byte[] source = bArr;
            int off = i;
            int len = i2;
            if (source == null) {
                NullPointerException nullPointerException2 = nullPointerException;
                NullPointerException nullPointerException3 = new NullPointerException("Cannot serialize a null array.");
                throw nullPointerException2;
            } else if (off < 0) {
                IllegalArgumentException illegalArgumentException4 = illegalArgumentException3;
                StringBuilder sb3 = sb2;
                StringBuilder sb4 = new StringBuilder();
                IllegalArgumentException illegalArgumentException5 = new IllegalArgumentException(sb3.append("Cannot have negative offset: ").append(off).toString());
                throw illegalArgumentException4;
            } else if (len < 0) {
                IllegalArgumentException illegalArgumentException6 = illegalArgumentException2;
                StringBuilder sb5 = sb;
                StringBuilder sb6 = new StringBuilder();
                IllegalArgumentException illegalArgumentException7 = new IllegalArgumentException(sb5.append("Cannot have length offset: ").append(len).toString());
                throw illegalArgumentException6;
            } else if (off + len > source.length) {
                IllegalArgumentException illegalArgumentException8 = illegalArgumentException;
                Object[] objArr = new Object[3];
                Object[] objArr2 = objArr;
                objArr[0] = Integer.valueOf(off);
                Object[] objArr3 = objArr2;
                Object[] objArr4 = objArr3;
                objArr3[1] = Integer.valueOf(len);
                Object[] objArr5 = objArr4;
                Object[] objArr6 = objArr5;
                objArr5[2] = Integer.valueOf(source.length);
                IllegalArgumentException illegalArgumentException9 = new IllegalArgumentException(String.format(Locale.ENGLISH, "Cannot have offset of %d and length of %d with array of length %d", objArr6));
                throw illegalArgumentException8;
            } else {
                byte[] outBuff = new byte[(((len / 3) * 4) + (len % 3 > 0 ? 4 : 0))];
                int d = 0;
                int e = 0;
                int len2 = len - 2;
                while (d < len2) {
                    byte[] encode3to4 = encode3to4(source, d + off, 3, outBuff, e);
                    d += 3;
                    e += 4;
                }
                if (d < len) {
                    byte[] encode3to42 = encode3to4(source, d + off, len - d, outBuff, e);
                    e += 4;
                }
                if (e > outBuff.length - 1) {
                    return outBuff;
                }
                byte[] finalOut = new byte[e];
                System.arraycopy(outBuff, 0, finalOut, 0, e);
                return finalOut;
            }
        }
    }

    /* renamed from: io.fabric.sdk.android.services.network.HttpRequest$CloseOperation */
    protected static abstract class CloseOperation<V> extends Operation<V> {
        private final Closeable closeable;
        private final boolean ignoreCloseExceptions;

        protected CloseOperation(Closeable closeable2, boolean z) {
            boolean ignoreCloseExceptions2 = z;
            this.closeable = closeable2;
            this.ignoreCloseExceptions = ignoreCloseExceptions2;
        }

        /* access modifiers changed from: protected */
        public void done() throws IOException {
            if (this.closeable instanceof Flushable) {
                ((Flushable) this.closeable).flush();
            }
            if (this.ignoreCloseExceptions) {
                try {
                    this.closeable.close();
                } catch (IOException e) {
                    IOException iOException = e;
                }
            } else {
                this.closeable.close();
            }
        }
    }

    /* renamed from: io.fabric.sdk.android.services.network.HttpRequest$ConnectionFactory */
    public interface ConnectionFactory {
        public static final ConnectionFactory DEFAULT;

        HttpURLConnection create(URL url) throws IOException;

        HttpURLConnection create(URL url, Proxy proxy) throws IOException;

        static {
            C15211 r2;
            C15211 r0 = r2;
            C15211 r1 = new ConnectionFactory() {
                public HttpURLConnection create(URL url) throws IOException {
                    return (HttpURLConnection) url.openConnection();
                }

                public HttpURLConnection create(URL url, Proxy proxy) throws IOException {
                    return (HttpURLConnection) url.openConnection(proxy);
                }
            };
            DEFAULT = r0;
        }
    }

    /* renamed from: io.fabric.sdk.android.services.network.HttpRequest$FlushOperation */
    protected static abstract class FlushOperation<V> extends Operation<V> {
        private final Flushable flushable;

        protected FlushOperation(Flushable flushable2) {
            this.flushable = flushable2;
        }

        /* access modifiers changed from: protected */
        public void done() throws IOException {
            this.flushable.flush();
        }
    }

    /* renamed from: io.fabric.sdk.android.services.network.HttpRequest$HttpRequestException */
    public static class HttpRequestException extends RuntimeException {
        private static final long serialVersionUID = -1170466989781746231L;

        protected HttpRequestException(IOException iOException) {
            super(iOException);
        }

        public IOException getCause() {
            return (IOException) super.getCause();
        }
    }

    /* renamed from: io.fabric.sdk.android.services.network.HttpRequest$Operation */
    protected static abstract class Operation<V> implements Callable<V> {
        /* access modifiers changed from: protected */
        public abstract void done() throws IOException;

        /* access modifiers changed from: protected */
        public abstract V run() throws HttpRequestException, IOException;

        protected Operation() {
        }

        public V call() throws HttpRequestException {
            boolean thrown;
            HttpRequestException httpRequestException;
            HttpRequestException httpRequestException2;
            HttpRequestException httpRequestException3;
            try {
                Object run = run();
                try {
                    done();
                } catch (IOException e) {
                    IOException e2 = e;
                    if (0 == 0) {
                        HttpRequestException httpRequestException4 = httpRequestException3;
                        HttpRequestException httpRequestException5 = new HttpRequestException(e2);
                        throw httpRequestException4;
                    }
                }
                return run;
            } catch (HttpRequestException e3) {
                thrown = true;
                throw e3;
            } catch (IOException e4) {
                IOException e5 = e4;
                thrown = true;
                HttpRequestException httpRequestException6 = httpRequestException;
                HttpRequestException httpRequestException7 = new HttpRequestException(e5);
                throw httpRequestException6;
            } catch (Throwable th) {
                Throwable th2 = th;
                try {
                    done();
                } catch (IOException e6) {
                    IOException e7 = e6;
                    if (!thrown) {
                        HttpRequestException httpRequestException8 = httpRequestException2;
                        HttpRequestException httpRequestException9 = new HttpRequestException(e7);
                        throw httpRequestException8;
                    }
                }
                throw th2;
            }
        }
    }

    /* renamed from: io.fabric.sdk.android.services.network.HttpRequest$RequestOutputStream */
    public static class RequestOutputStream extends BufferedOutputStream {
        /* access modifiers changed from: private */
        public final CharsetEncoder encoder;

        public RequestOutputStream(OutputStream outputStream, String str, int i) {
            String charset = str;
            super(outputStream, i);
            this.encoder = Charset.forName(HttpRequest.getValidCharset(charset)).newEncoder();
        }

        public RequestOutputStream write(String str) throws IOException {
            ByteBuffer bytes = this.encoder.encode(CharBuffer.wrap(str));
            super.write(bytes.array(), 0, bytes.limit());
            return this;
        }
    }

    /* access modifiers changed from: private */
    public static String getValidCharset(String str) {
        String charset = str;
        if (charset == null || charset.length() <= 0) {
            return "UTF-8";
        }
        return charset;
    }

    private static StringBuilder addPathSeparator(String str, StringBuilder sb) {
        String baseUrl = str;
        StringBuilder result = sb;
        if (baseUrl.indexOf(58) + 2 == baseUrl.lastIndexOf(47)) {
            StringBuilder append = result.append('/');
        }
        return result;
    }

    private static StringBuilder addParamPrefix(String str, StringBuilder sb) {
        String baseUrl = str;
        StringBuilder result = sb;
        int queryStart = baseUrl.indexOf(63);
        int lastChar = result.length() - 1;
        if (queryStart == -1) {
            StringBuilder append = result.append('?');
        } else if (queryStart < lastChar && baseUrl.charAt(lastChar) != '&') {
            StringBuilder append2 = result.append('&');
        }
        return result;
    }

    public static void setConnectionFactory(ConnectionFactory connectionFactory) {
        ConnectionFactory connectionFactory2 = connectionFactory;
        if (connectionFactory2 == null) {
            CONNECTION_FACTORY = ConnectionFactory.DEFAULT;
        } else {
            CONNECTION_FACTORY = connectionFactory2;
        }
    }

    public static String encode(CharSequence charSequence) throws HttpRequestException {
        HttpRequestException httpRequestException;
        URL url2;
        IOException iOException;
        HttpRequestException httpRequestException2;
        URI uri;
        StringBuilder sb;
        StringBuilder sb2;
        try {
            URL url3 = url2;
            URL url4 = new URL(charSequence.toString());
            URL parsed = url3;
            String host = parsed.getHost();
            int port = parsed.getPort();
            if (port != -1) {
                StringBuilder sb3 = sb2;
                StringBuilder sb4 = new StringBuilder();
                host = sb3.append(host).append(':').append(Integer.toString(port)).toString();
            }
            try {
                URI uri2 = uri;
                URI uri3 = new URI(parsed.getProtocol(), host, parsed.getPath(), parsed.getQuery(), parsed.getRef());
                String encoded = uri2.toASCIIString();
                int paramsStart = encoded.indexOf(63);
                if (paramsStart > 0 && paramsStart + 1 < encoded.length()) {
                    StringBuilder sb5 = sb;
                    StringBuilder sb6 = new StringBuilder();
                    encoded = sb5.append(encoded.substring(0, paramsStart + 1)).append(encoded.substring(paramsStart + 1).replace("+", "%2B").replace("#", "%23")).toString();
                }
                return encoded;
            } catch (URISyntaxException e) {
                URISyntaxException e2 = e;
                IOException iOException2 = iOException;
                IOException iOException3 = new IOException("Parsing URI failed");
                IOException io = iOException2;
                Throwable initCause = io.initCause(e2);
                HttpRequestException httpRequestException3 = httpRequestException2;
                HttpRequestException httpRequestException4 = new HttpRequestException(io);
                throw httpRequestException3;
            }
        } catch (IOException e3) {
            IOException e4 = e3;
            HttpRequestException httpRequestException5 = httpRequestException;
            HttpRequestException httpRequestException6 = new HttpRequestException(e4);
            throw httpRequestException5;
        }
    }

    public static String append(CharSequence charSequence, Map<?, ?> map) {
        StringBuilder sb;
        Map<?, ?> params = map;
        String baseUrl = charSequence.toString();
        if (params == null || params.isEmpty()) {
            return baseUrl;
        }
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder(baseUrl);
        StringBuilder result = sb2;
        StringBuilder addPathSeparator = addPathSeparator(baseUrl, result);
        StringBuilder addParamPrefix = addParamPrefix(baseUrl, result);
        Iterator it = params.entrySet().iterator();
        Entry entry = (Entry) it.next();
        StringBuilder append = result.append(entry.getKey().toString());
        StringBuilder append2 = result.append('=');
        Object value = entry.getValue();
        if (value != null) {
            StringBuilder append3 = result.append(value);
        }
        while (it.hasNext()) {
            StringBuilder append4 = result.append('&');
            Entry entry2 = (Entry) it.next();
            StringBuilder append5 = result.append(entry2.getKey().toString());
            StringBuilder append6 = result.append('=');
            Object value2 = entry2.getValue();
            if (value2 != null) {
                StringBuilder append7 = result.append(value2);
            }
        }
        return result.toString();
    }

    public static String append(CharSequence charSequence, Object... objArr) {
        StringBuilder sb;
        IllegalArgumentException illegalArgumentException;
        Object[] params = objArr;
        String baseUrl = charSequence.toString();
        if (params == null || params.length == 0) {
            return baseUrl;
        }
        if (params.length % 2 != 0) {
            IllegalArgumentException illegalArgumentException2 = illegalArgumentException;
            IllegalArgumentException illegalArgumentException3 = new IllegalArgumentException("Must specify an even number of parameter names/values");
            throw illegalArgumentException2;
        }
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder(baseUrl);
        StringBuilder result = sb2;
        StringBuilder addPathSeparator = addPathSeparator(baseUrl, result);
        StringBuilder addParamPrefix = addParamPrefix(baseUrl, result);
        StringBuilder append = result.append(params[0]);
        StringBuilder append2 = result.append('=');
        Object value = params[1];
        if (value != null) {
            StringBuilder append3 = result.append(value);
        }
        for (int i = 2; i < params.length; i += 2) {
            StringBuilder append4 = result.append('&');
            StringBuilder append5 = result.append(params[i]);
            StringBuilder append6 = result.append('=');
            Object value2 = params[i + 1];
            if (value2 != null) {
                StringBuilder append7 = result.append(value2);
            }
        }
        return result.toString();
    }

    public static HttpRequest get(CharSequence charSequence) throws HttpRequestException {
        HttpRequest httpRequest;
        HttpRequest httpRequest2 = httpRequest;
        HttpRequest httpRequest3 = new HttpRequest(charSequence, "GET");
        return httpRequest2;
    }

    public static HttpRequest get(URL url2) throws HttpRequestException {
        HttpRequest httpRequest;
        HttpRequest httpRequest2 = httpRequest;
        HttpRequest httpRequest3 = new HttpRequest(url2, "GET");
        return httpRequest2;
    }

    public static HttpRequest get(CharSequence charSequence, Map<?, ?> map, boolean z) {
        boolean encode = z;
        String url2 = append(charSequence, map);
        return get((CharSequence) encode ? encode(url2) : url2);
    }

    public static HttpRequest get(CharSequence charSequence, boolean z, Object... objArr) {
        boolean encode = z;
        String url2 = append(charSequence, objArr);
        return get((CharSequence) encode ? encode(url2) : url2);
    }

    public static HttpRequest post(CharSequence charSequence) throws HttpRequestException {
        HttpRequest httpRequest;
        HttpRequest httpRequest2 = httpRequest;
        HttpRequest httpRequest3 = new HttpRequest(charSequence, "POST");
        return httpRequest2;
    }

    public static HttpRequest post(URL url2) throws HttpRequestException {
        HttpRequest httpRequest;
        HttpRequest httpRequest2 = httpRequest;
        HttpRequest httpRequest3 = new HttpRequest(url2, "POST");
        return httpRequest2;
    }

    public static HttpRequest post(CharSequence charSequence, Map<?, ?> map, boolean z) {
        boolean encode = z;
        String url2 = append(charSequence, map);
        return post((CharSequence) encode ? encode(url2) : url2);
    }

    public static HttpRequest post(CharSequence charSequence, boolean z, Object... objArr) {
        boolean encode = z;
        String url2 = append(charSequence, objArr);
        return post((CharSequence) encode ? encode(url2) : url2);
    }

    public static HttpRequest put(CharSequence charSequence) throws HttpRequestException {
        HttpRequest httpRequest;
        HttpRequest httpRequest2 = httpRequest;
        HttpRequest httpRequest3 = new HttpRequest(charSequence, "PUT");
        return httpRequest2;
    }

    public static HttpRequest put(URL url2) throws HttpRequestException {
        HttpRequest httpRequest;
        HttpRequest httpRequest2 = httpRequest;
        HttpRequest httpRequest3 = new HttpRequest(url2, "PUT");
        return httpRequest2;
    }

    public static HttpRequest put(CharSequence charSequence, Map<?, ?> map, boolean z) {
        boolean encode = z;
        String url2 = append(charSequence, map);
        return put((CharSequence) encode ? encode(url2) : url2);
    }

    public static HttpRequest put(CharSequence charSequence, boolean z, Object... objArr) {
        boolean encode = z;
        String url2 = append(charSequence, objArr);
        return put((CharSequence) encode ? encode(url2) : url2);
    }

    public static HttpRequest delete(CharSequence charSequence) throws HttpRequestException {
        HttpRequest httpRequest;
        HttpRequest httpRequest2 = httpRequest;
        HttpRequest httpRequest3 = new HttpRequest(charSequence, "DELETE");
        return httpRequest2;
    }

    public static HttpRequest delete(URL url2) throws HttpRequestException {
        HttpRequest httpRequest;
        HttpRequest httpRequest2 = httpRequest;
        HttpRequest httpRequest3 = new HttpRequest(url2, "DELETE");
        return httpRequest2;
    }

    public static HttpRequest delete(CharSequence charSequence, Map<?, ?> map, boolean z) {
        boolean encode = z;
        String url2 = append(charSequence, map);
        return delete((CharSequence) encode ? encode(url2) : url2);
    }

    public static HttpRequest delete(CharSequence charSequence, boolean z, Object... objArr) {
        boolean encode = z;
        String url2 = append(charSequence, objArr);
        return delete((CharSequence) encode ? encode(url2) : url2);
    }

    public static HttpRequest head(CharSequence charSequence) throws HttpRequestException {
        HttpRequest httpRequest;
        HttpRequest httpRequest2 = httpRequest;
        HttpRequest httpRequest3 = new HttpRequest(charSequence, "HEAD");
        return httpRequest2;
    }

    public static HttpRequest head(URL url2) throws HttpRequestException {
        HttpRequest httpRequest;
        HttpRequest httpRequest2 = httpRequest;
        HttpRequest httpRequest3 = new HttpRequest(url2, "HEAD");
        return httpRequest2;
    }

    public static HttpRequest head(CharSequence charSequence, Map<?, ?> map, boolean z) {
        boolean encode = z;
        String url2 = append(charSequence, map);
        return head((CharSequence) encode ? encode(url2) : url2);
    }

    public static HttpRequest head(CharSequence charSequence, boolean z, Object... objArr) {
        boolean encode = z;
        String url2 = append(charSequence, objArr);
        return head((CharSequence) encode ? encode(url2) : url2);
    }

    public static HttpRequest options(CharSequence charSequence) throws HttpRequestException {
        HttpRequest httpRequest;
        HttpRequest httpRequest2 = httpRequest;
        HttpRequest httpRequest3 = new HttpRequest(charSequence, "OPTIONS");
        return httpRequest2;
    }

    public static HttpRequest options(URL url2) throws HttpRequestException {
        HttpRequest httpRequest;
        HttpRequest httpRequest2 = httpRequest;
        HttpRequest httpRequest3 = new HttpRequest(url2, "OPTIONS");
        return httpRequest2;
    }

    public static HttpRequest trace(CharSequence charSequence) throws HttpRequestException {
        HttpRequest httpRequest;
        HttpRequest httpRequest2 = httpRequest;
        HttpRequest httpRequest3 = new HttpRequest(charSequence, "TRACE");
        return httpRequest2;
    }

    public static HttpRequest trace(URL url2) throws HttpRequestException {
        HttpRequest httpRequest;
        HttpRequest httpRequest2 = httpRequest;
        HttpRequest httpRequest3 = new HttpRequest(url2, "TRACE");
        return httpRequest2;
    }

    public static void keepAlive(boolean z) {
        String property = setProperty("http.keepAlive", Boolean.toString(z));
    }

    public static void proxyHost(String str) {
        String host = str;
        String property = setProperty("http.proxyHost", host);
        String property2 = setProperty("https.proxyHost", host);
    }

    public static void proxyPort(int i) {
        String portValue = Integer.toString(i);
        String property = setProperty("http.proxyPort", portValue);
        String property2 = setProperty("https.proxyPort", portValue);
    }

    public static void nonProxyHosts(String... strArr) {
        StringBuilder sb;
        String[] hosts = strArr;
        if (hosts == null || hosts.length <= 0) {
            String property = setProperty("http.nonProxyHosts", null);
            return;
        }
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        StringBuilder separated = sb2;
        int last = hosts.length - 1;
        for (int i = 0; i < last; i++) {
            StringBuilder append = separated.append(hosts[i]).append('|');
        }
        StringBuilder append2 = separated.append(hosts[last]);
        String property2 = setProperty("http.nonProxyHosts", separated.toString());
    }

    /* JADX WARNING: type inference failed for: r7v0 */
    /* JADX WARNING: type inference failed for: r3v2 */
    /* JADX WARNING: type inference failed for: r2v0 */
    /* JADX WARNING: type inference failed for: r2v1 */
    /* JADX WARNING: type inference failed for: r3v3, types: [java.security.PrivilegedAction] */
    /* JADX WARNING: type inference failed for: r7v1 */
    /* JADX WARNING: type inference failed for: r3v7 */
    /* JADX WARNING: type inference failed for: r2v2 */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 6 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static java.lang.String setProperty(java.lang.String r8, java.lang.String r9) {
        /*
            r0 = r8
            r1 = r9
            r3 = r1
            if (r3 == 0) goto L_0x0019
            io.fabric.sdk.android.services.network.HttpRequest$1 r3 = new io.fabric.sdk.android.services.network.HttpRequest$1
            r7 = r3
            r3 = r7
            r4 = r7
            r5 = r0
            r6 = r1
            r4.<init>(r5, r6)
            r2 = r3
        L_0x0010:
            r3 = r2
            java.lang.Object r3 = java.security.AccessController.doPrivileged(r3)
            java.lang.String r3 = (java.lang.String) r3
            r0 = r3
            return r0
        L_0x0019:
            io.fabric.sdk.android.services.network.HttpRequest$2 r3 = new io.fabric.sdk.android.services.network.HttpRequest$2
            r7 = r3
            r3 = r7
            r4 = r7
            r5 = r0
            r4.<init>(r5)
            r2 = r3
            goto L_0x0010
        */
        throw new UnsupportedOperationException("Method not decompiled: p004io.fabric.sdk.android.services.network.HttpRequest.setProperty(java.lang.String, java.lang.String):java.lang.String");
    }

    public HttpRequest(CharSequence charSequence, String str) throws HttpRequestException {
        HttpRequestException httpRequestException;
        URL url2;
        CharSequence url3 = charSequence;
        String method = str;
        try {
            URL url4 = url2;
            URL url5 = new URL(url3.toString());
            this.url = url4;
            this.requestMethod = method;
        } catch (MalformedURLException e) {
            MalformedURLException e2 = e;
            HttpRequestException httpRequestException2 = httpRequestException;
            HttpRequestException httpRequestException3 = new HttpRequestException(e2);
            throw httpRequestException2;
        }
    }

    public HttpRequest(URL url2, String str) throws HttpRequestException {
        URL url3 = url2;
        String method = str;
        this.url = url3;
        this.requestMethod = method;
    }

    private Proxy createProxy() {
        Proxy proxy;
        InetSocketAddress inetSocketAddress;
        Proxy proxy2 = proxy;
        Type type = Type.HTTP;
        InetSocketAddress inetSocketAddress2 = inetSocketAddress;
        InetSocketAddress inetSocketAddress3 = new InetSocketAddress(this.httpProxyHost, this.httpProxyPort);
        Proxy proxy3 = new Proxy(type, inetSocketAddress2);
        return proxy2;
    }

    private HttpURLConnection createConnection() {
        HttpRequestException httpRequestException;
        HttpURLConnection connection2;
        try {
            if (this.httpProxyHost != null) {
                connection2 = CONNECTION_FACTORY.create(this.url, createProxy());
            } else {
                connection2 = CONNECTION_FACTORY.create(this.url);
            }
            connection2.setRequestMethod(this.requestMethod);
            return connection2;
        } catch (IOException e) {
            IOException e2 = e;
            HttpRequestException httpRequestException2 = httpRequestException;
            HttpRequestException httpRequestException3 = new HttpRequestException(e2);
            throw httpRequestException2;
        }
    }

    public String toString() {
        StringBuilder sb;
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        return sb2.append(method()).append(' ').append(url()).toString();
    }

    public HttpURLConnection getConnection() {
        if (this.connection == null) {
            this.connection = createConnection();
        }
        return this.connection;
    }

    public HttpRequest ignoreCloseExceptions(boolean z) {
        this.ignoreCloseExceptions = z;
        return this;
    }

    public boolean ignoreCloseExceptions() {
        return this.ignoreCloseExceptions;
    }

    public int code() throws HttpRequestException {
        HttpRequestException httpRequestException;
        try {
            HttpRequest closeOutput = closeOutput();
            return getConnection().getResponseCode();
        } catch (IOException e) {
            IOException e2 = e;
            HttpRequestException httpRequestException2 = httpRequestException;
            HttpRequestException httpRequestException3 = new HttpRequestException(e2);
            throw httpRequestException2;
        }
    }

    public HttpRequest code(AtomicInteger atomicInteger) throws HttpRequestException {
        atomicInteger.set(code());
        return this;
    }

    /* renamed from: ok */
    public boolean mo24202ok() throws HttpRequestException {
        return 200 == code();
    }

    public boolean created() throws HttpRequestException {
        return 201 == code();
    }

    public boolean serverError() throws HttpRequestException {
        return 500 == code();
    }

    public boolean badRequest() throws HttpRequestException {
        return 400 == code();
    }

    public boolean notFound() throws HttpRequestException {
        return 404 == code();
    }

    public boolean notModified() throws HttpRequestException {
        return 304 == code();
    }

    public String message() throws HttpRequestException {
        HttpRequestException httpRequestException;
        try {
            HttpRequest closeOutput = closeOutput();
            return getConnection().getResponseMessage();
        } catch (IOException e) {
            IOException e2 = e;
            HttpRequestException httpRequestException2 = httpRequestException;
            HttpRequestException httpRequestException3 = new HttpRequestException(e2);
            throw httpRequestException2;
        }
    }

    public HttpRequest disconnect() {
        getConnection().disconnect();
        return this;
    }

    public HttpRequest chunk(int i) {
        getConnection().setChunkedStreamingMode(i);
        return this;
    }

    public HttpRequest bufferSize(int i) {
        IllegalArgumentException illegalArgumentException;
        int size = i;
        if (size < 1) {
            IllegalArgumentException illegalArgumentException2 = illegalArgumentException;
            IllegalArgumentException illegalArgumentException3 = new IllegalArgumentException("Size must be greater than zero");
            throw illegalArgumentException2;
        }
        this.bufferSize = size;
        return this;
    }

    public int bufferSize() {
        return this.bufferSize;
    }

    public HttpRequest uncompress(boolean z) {
        this.uncompress = z;
        return this;
    }

    /* access modifiers changed from: protected */
    public ByteArrayOutputStream byteStream() {
        ByteArrayOutputStream byteArrayOutputStream;
        ByteArrayOutputStream byteArrayOutputStream2;
        int size = contentLength();
        if (size > 0) {
            ByteArrayOutputStream byteArrayOutputStream3 = byteArrayOutputStream2;
            ByteArrayOutputStream byteArrayOutputStream4 = new ByteArrayOutputStream(size);
            return byteArrayOutputStream3;
        }
        ByteArrayOutputStream byteArrayOutputStream5 = byteArrayOutputStream;
        ByteArrayOutputStream byteArrayOutputStream6 = new ByteArrayOutputStream();
        return byteArrayOutputStream5;
    }

    public String body(String str) throws HttpRequestException {
        HttpRequestException httpRequestException;
        String charset = str;
        ByteArrayOutputStream output2 = byteStream();
        try {
            HttpRequest copy = copy((InputStream) buffer(), (OutputStream) output2);
            return output2.toString(getValidCharset(charset));
        } catch (IOException e) {
            IOException e2 = e;
            HttpRequestException httpRequestException2 = httpRequestException;
            HttpRequestException httpRequestException3 = new HttpRequestException(e2);
            throw httpRequestException2;
        }
    }

    public String body() throws HttpRequestException {
        return body(charset());
    }

    public HttpRequest body(AtomicReference<String> atomicReference) throws HttpRequestException {
        atomicReference.set(body());
        return this;
    }

    public HttpRequest body(AtomicReference<String> atomicReference, String str) throws HttpRequestException {
        atomicReference.set(body(str));
        return this;
    }

    public boolean isBodyEmpty() throws HttpRequestException {
        return contentLength() == 0;
    }

    public byte[] bytes() throws HttpRequestException {
        HttpRequestException httpRequestException;
        ByteArrayOutputStream output2 = byteStream();
        try {
            HttpRequest copy = copy((InputStream) buffer(), (OutputStream) output2);
            return output2.toByteArray();
        } catch (IOException e) {
            IOException e2 = e;
            HttpRequestException httpRequestException2 = httpRequestException;
            HttpRequestException httpRequestException3 = new HttpRequestException(e2);
            throw httpRequestException2;
        }
    }

    public BufferedInputStream buffer() throws HttpRequestException {
        BufferedInputStream bufferedInputStream;
        BufferedInputStream bufferedInputStream2 = bufferedInputStream;
        BufferedInputStream bufferedInputStream3 = new BufferedInputStream(stream(), this.bufferSize);
        return bufferedInputStream2;
    }

    public InputStream stream() throws HttpRequestException {
        InputStream stream;
        HttpRequestException httpRequestException;
        HttpRequestException httpRequestException2;
        GZIPInputStream gZIPInputStream;
        HttpRequestException httpRequestException3;
        if (code() < 400) {
            try {
                stream = getConnection().getInputStream();
            } catch (IOException e) {
                IOException e2 = e;
                HttpRequestException httpRequestException4 = httpRequestException3;
                HttpRequestException httpRequestException5 = new HttpRequestException(e2);
                throw httpRequestException4;
            }
        } else {
            stream = getConnection().getErrorStream();
            if (stream == null) {
                try {
                    stream = getConnection().getInputStream();
                } catch (IOException e3) {
                    IOException e4 = e3;
                    HttpRequestException httpRequestException6 = httpRequestException;
                    HttpRequestException httpRequestException7 = new HttpRequestException(e4);
                    throw httpRequestException6;
                }
            }
        }
        if (!this.uncompress || !ENCODING_GZIP.equals(contentEncoding())) {
            return stream;
        }
        try {
            GZIPInputStream gZIPInputStream2 = gZIPInputStream;
            GZIPInputStream gZIPInputStream3 = new GZIPInputStream(stream);
            return gZIPInputStream2;
        } catch (IOException e5) {
            IOException e6 = e5;
            HttpRequestException httpRequestException8 = httpRequestException2;
            HttpRequestException httpRequestException9 = new HttpRequestException(e6);
            throw httpRequestException8;
        }
    }

    public InputStreamReader reader(String str) throws HttpRequestException {
        HttpRequestException httpRequestException;
        InputStreamReader inputStreamReader;
        try {
            InputStreamReader inputStreamReader2 = inputStreamReader;
            InputStreamReader inputStreamReader3 = new InputStreamReader(stream(), getValidCharset(str));
            return inputStreamReader2;
        } catch (UnsupportedEncodingException e) {
            UnsupportedEncodingException e2 = e;
            HttpRequestException httpRequestException2 = httpRequestException;
            HttpRequestException httpRequestException3 = new HttpRequestException(e2);
            throw httpRequestException2;
        }
    }

    public InputStreamReader reader() throws HttpRequestException {
        return reader(charset());
    }

    public BufferedReader bufferedReader(String str) throws HttpRequestException {
        BufferedReader bufferedReader;
        BufferedReader bufferedReader2 = bufferedReader;
        BufferedReader bufferedReader3 = new BufferedReader(reader(str), this.bufferSize);
        return bufferedReader2;
    }

    public BufferedReader bufferedReader() throws HttpRequestException {
        return bufferedReader(charset());
    }

    public HttpRequest receive(File file) throws HttpRequestException {
        HttpRequestException httpRequestException;
        BufferedOutputStream bufferedOutputStream;
        FileOutputStream fileOutputStream;
        C15153 r10;
        try {
            BufferedOutputStream bufferedOutputStream2 = bufferedOutputStream;
            FileOutputStream fileOutputStream2 = fileOutputStream;
            FileOutputStream fileOutputStream3 = new FileOutputStream(file);
            BufferedOutputStream bufferedOutputStream3 = new BufferedOutputStream(fileOutputStream2, this.bufferSize);
            BufferedOutputStream bufferedOutputStream4 = bufferedOutputStream2;
            C15153 r4 = r10;
            final BufferedOutputStream bufferedOutputStream5 = bufferedOutputStream4;
            C15153 r5 = new CloseOperation<HttpRequest>(this, bufferedOutputStream4, this.ignoreCloseExceptions) {
                final /* synthetic */ HttpRequest this$0;

                {
                    Closeable closeable = r10;
                    boolean ignoreCloseExceptions = r11;
                    OutputStream outputStream = r12;
                    this.this$0 = r9;
                }

                /* access modifiers changed from: protected */
                public HttpRequest run() throws HttpRequestException, IOException {
                    return this.this$0.receive(bufferedOutputStream5);
                }
            };
            return (HttpRequest) r4.call();
        } catch (FileNotFoundException e) {
            FileNotFoundException e2 = e;
            HttpRequestException httpRequestException2 = httpRequestException;
            HttpRequestException httpRequestException3 = new HttpRequestException(e2);
            throw httpRequestException2;
        }
    }

    public HttpRequest receive(OutputStream outputStream) throws HttpRequestException {
        HttpRequestException httpRequestException;
        try {
            return copy((InputStream) buffer(), outputStream);
        } catch (IOException e) {
            IOException e2 = e;
            HttpRequestException httpRequestException2 = httpRequestException;
            HttpRequestException httpRequestException3 = new HttpRequestException(e2);
            throw httpRequestException2;
        }
    }

    public HttpRequest receive(PrintStream printStream) throws HttpRequestException {
        return receive((OutputStream) printStream);
    }

    public HttpRequest receive(Appendable appendable) throws HttpRequestException {
        C15164 r10;
        Appendable appendable2 = appendable;
        BufferedReader reader = bufferedReader();
        C15164 r3 = r10;
        final BufferedReader bufferedReader = reader;
        final Appendable appendable3 = appendable2;
        C15164 r4 = new CloseOperation<HttpRequest>(this, reader, this.ignoreCloseExceptions) {
            final /* synthetic */ HttpRequest this$0;

            {
                Closeable closeable = r11;
                boolean ignoreCloseExceptions = r12;
                BufferedReader bufferedReader = r13;
                Appendable appendable = r14;
                this.this$0 = r10;
            }

            public HttpRequest run() throws IOException {
                CharBuffer buffer = CharBuffer.allocate(this.this$0.bufferSize);
                while (true) {
                    int read = bufferedReader.read(buffer);
                    int read2 = read;
                    if (read == -1) {
                        return this.this$0;
                    }
                    Buffer rewind = buffer.rewind();
                    Appendable append = appendable3.append(buffer, 0, read2);
                    Buffer rewind2 = buffer.rewind();
                }
            }
        };
        return (HttpRequest) r3.call();
    }

    public HttpRequest receive(Writer writer) throws HttpRequestException {
        C15175 r10;
        Writer writer2 = writer;
        BufferedReader reader = bufferedReader();
        C15175 r3 = r10;
        final BufferedReader bufferedReader = reader;
        final Writer writer3 = writer2;
        C15175 r4 = new CloseOperation<HttpRequest>(this, reader, this.ignoreCloseExceptions) {
            final /* synthetic */ HttpRequest this$0;

            {
                Closeable closeable = r11;
                boolean ignoreCloseExceptions = r12;
                BufferedReader bufferedReader = r13;
                Writer writer = r14;
                this.this$0 = r10;
            }

            public HttpRequest run() throws IOException {
                return this.this$0.copy((Reader) bufferedReader, writer3);
            }
        };
        return (HttpRequest) r3.call();
    }

    public HttpRequest readTimeout(int i) {
        getConnection().setReadTimeout(i);
        return this;
    }

    public HttpRequest connectTimeout(int i) {
        getConnection().setConnectTimeout(i);
        return this;
    }

    public HttpRequest header(String str, String str2) {
        getConnection().setRequestProperty(str, str2);
        return this;
    }

    public HttpRequest header(String str, Number number) {
        Number value = number;
        return header(str, value != null ? value.toString() : null);
    }

    public HttpRequest headers(Map<String, String> map) {
        Map<String, String> headers = map;
        if (!headers.isEmpty()) {
            for (Entry header : headers.entrySet()) {
                HttpRequest header2 = header(header);
            }
        }
        return this;
    }

    public HttpRequest header(Entry<String, String> entry) {
        Entry<String, String> header = entry;
        return header((String) header.getKey(), (String) header.getValue());
    }

    public String header(String str) throws HttpRequestException {
        String name = str;
        HttpRequest closeOutputQuietly = closeOutputQuietly();
        return getConnection().getHeaderField(name);
    }

    public Map<String, List<String>> headers() throws HttpRequestException {
        HttpRequest closeOutputQuietly = closeOutputQuietly();
        return getConnection().getHeaderFields();
    }

    public long dateHeader(String str) throws HttpRequestException {
        return dateHeader(str, -1);
    }

    public long dateHeader(String str, long j) throws HttpRequestException {
        String name = str;
        long defaultValue = j;
        HttpRequest closeOutputQuietly = closeOutputQuietly();
        return getConnection().getHeaderFieldDate(name, defaultValue);
    }

    public int intHeader(String str) throws HttpRequestException {
        return intHeader(str, -1);
    }

    public int intHeader(String str, int i) throws HttpRequestException {
        String name = str;
        int defaultValue = i;
        HttpRequest closeOutputQuietly = closeOutputQuietly();
        return getConnection().getHeaderFieldInt(name, defaultValue);
    }

    public String[] headers(String str) {
        String name = str;
        Map headers = headers();
        if (headers == null || headers.isEmpty()) {
            return EMPTY_STRINGS;
        }
        List list = (List) headers.get(name);
        if (list == null || list.isEmpty()) {
            return EMPTY_STRINGS;
        }
        return (String[]) list.toArray(new String[list.size()]);
    }

    public String parameter(String str, String str2) {
        return getParam(header(str), str2);
    }

    public Map<String, String> parameters(String str) {
        return getParams(header(str));
    }

    /* access modifiers changed from: protected */
    public Map<String, String> getParams(String str) {
        int end;
        LinkedHashMap linkedHashMap;
        String header = str;
        if (header == null || header.length() == 0) {
            return Collections.emptyMap();
        }
        int headerLength = header.length();
        int start = header.indexOf(59) + 1;
        if (start == 0 || start == headerLength) {
            return Collections.emptyMap();
        }
        int end2 = header.indexOf(59, start);
        if (end2 == -1) {
            end2 = headerLength;
        }
        LinkedHashMap linkedHashMap2 = linkedHashMap;
        LinkedHashMap linkedHashMap3 = new LinkedHashMap();
        LinkedHashMap linkedHashMap4 = linkedHashMap2;
        while (start < end) {
            int nameEnd = header.indexOf(61, start);
            if (nameEnd != -1 && nameEnd < end) {
                String name = header.substring(start, nameEnd).trim();
                if (name.length() > 0) {
                    String value = header.substring(nameEnd + 1, end).trim();
                    int length = value.length();
                    if (length != 0) {
                        if (length > 2 && '\"' == value.charAt(0) && '\"' == value.charAt(length - 1)) {
                            Object put = linkedHashMap4.put(name, value.substring(1, length - 1));
                        } else {
                            Object put2 = linkedHashMap4.put(name, value);
                        }
                    }
                }
            }
            start = end + 1;
            end = header.indexOf(59, start);
            if (end == -1) {
                end = headerLength;
            }
        }
        return linkedHashMap4;
    }

    /* access modifiers changed from: protected */
    public String getParam(String str, String str2) {
        int end;
        String value = str;
        String paramName = str2;
        if (value == null || value.length() == 0) {
            return null;
        }
        int length = value.length();
        int start = value.indexOf(59) + 1;
        if (start == 0 || start == length) {
            return null;
        }
        int end2 = value.indexOf(59, start);
        if (end2 == -1) {
            end2 = length;
        }
        while (start < end) {
            int nameEnd = value.indexOf(61, start);
            if (nameEnd != -1 && nameEnd < end && paramName.equals(value.substring(start, nameEnd).trim())) {
                String paramValue = value.substring(nameEnd + 1, end).trim();
                int valueLength = paramValue.length();
                if (valueLength != 0) {
                    if (valueLength > 2 && '\"' == paramValue.charAt(0) && '\"' == paramValue.charAt(valueLength - 1)) {
                        return paramValue.substring(1, valueLength - 1);
                    }
                    return paramValue;
                }
            }
            start = end + 1;
            end = value.indexOf(59, start);
            if (end == -1) {
                end = length;
            }
        }
        return null;
    }

    public String charset() {
        return parameter("Content-Type", PARAM_CHARSET);
    }

    public HttpRequest userAgent(String str) {
        return header("User-Agent", str);
    }

    public HttpRequest referer(String str) {
        return header(HEADER_REFERER, str);
    }

    public HttpRequest useCaches(boolean z) {
        getConnection().setUseCaches(z);
        return this;
    }

    public HttpRequest acceptEncoding(String str) {
        return header(HEADER_ACCEPT_ENCODING, str);
    }

    public HttpRequest acceptGzipEncoding() {
        return acceptEncoding(ENCODING_GZIP);
    }

    public HttpRequest acceptCharset(String str) {
        return header(HEADER_ACCEPT_CHARSET, str);
    }

    public String contentEncoding() {
        return header("Content-Encoding");
    }

    public String server() {
        return header("Server");
    }

    public long date() {
        return dateHeader("Date");
    }

    public String cacheControl() {
        return header(HEADER_CACHE_CONTROL);
    }

    public String eTag() {
        return header(HEADER_ETAG);
    }

    public long expires() {
        return dateHeader(HEADER_EXPIRES);
    }

    public long lastModified() {
        return dateHeader(HEADER_LAST_MODIFIED);
    }

    public String location() {
        return header(HEADER_LOCATION);
    }

    public HttpRequest authorization(String str) {
        return header("Authorization", str);
    }

    public HttpRequest proxyAuthorization(String str) {
        return header("Proxy-Authorization", str);
    }

    public HttpRequest basic(String str, String str2) {
        StringBuilder sb;
        StringBuilder sb2;
        String name = str;
        String password = str2;
        StringBuilder sb3 = sb;
        StringBuilder sb4 = new StringBuilder();
        StringBuilder append = sb3.append("Basic ");
        StringBuilder sb5 = sb2;
        StringBuilder sb6 = new StringBuilder();
        return authorization(append.append(Base64.encode(sb5.append(name).append(':').append(password).toString())).toString());
    }

    public HttpRequest proxyBasic(String str, String str2) {
        StringBuilder sb;
        StringBuilder sb2;
        String name = str;
        String password = str2;
        StringBuilder sb3 = sb;
        StringBuilder sb4 = new StringBuilder();
        StringBuilder append = sb3.append("Basic ");
        StringBuilder sb5 = sb2;
        StringBuilder sb6 = new StringBuilder();
        return proxyAuthorization(append.append(Base64.encode(sb5.append(name).append(':').append(password).toString())).toString());
    }

    public HttpRequest ifModifiedSince(long j) {
        getConnection().setIfModifiedSince(j);
        return this;
    }

    public HttpRequest ifNoneMatch(String str) {
        return header(HEADER_IF_NONE_MATCH, str);
    }

    public HttpRequest contentType(String str) {
        return contentType(str, null);
    }

    public HttpRequest contentType(String str, String str2) {
        StringBuilder sb;
        String contentType = str;
        String charset = str2;
        if (charset == null || charset.length() <= 0) {
            return header("Content-Type", contentType);
        }
        String str3 = HTTP.CHARSET_PARAM;
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        return header("Content-Type", sb2.append(contentType).append(HTTP.CHARSET_PARAM).append(charset).toString());
    }

    public String contentType() {
        return header("Content-Type");
    }

    public int contentLength() {
        return intHeader("Content-Length");
    }

    public HttpRequest contentLength(String str) {
        return contentLength(Integer.parseInt(str));
    }

    public HttpRequest contentLength(int i) {
        getConnection().setFixedLengthStreamingMode(i);
        return this;
    }

    public HttpRequest accept(String str) {
        return header("Accept", str);
    }

    public HttpRequest acceptJson() {
        return accept("application/json");
    }

    /* access modifiers changed from: protected */
    public HttpRequest copy(InputStream inputStream, OutputStream outputStream) throws IOException {
        C15186 r10;
        InputStream input = inputStream;
        C15186 r3 = r10;
        final InputStream inputStream2 = input;
        final OutputStream outputStream2 = outputStream;
        C15186 r4 = new CloseOperation<HttpRequest>(this, input, this.ignoreCloseExceptions) {
            final /* synthetic */ HttpRequest this$0;

            {
                Closeable closeable = r11;
                boolean ignoreCloseExceptions = r12;
                InputStream inputStream = r13;
                OutputStream outputStream = r14;
                this.this$0 = r10;
            }

            public HttpRequest run() throws IOException {
                byte[] buffer = new byte[this.this$0.bufferSize];
                while (true) {
                    int read = inputStream2.read(buffer);
                    int read2 = read;
                    if (read == -1) {
                        return this.this$0;
                    }
                    outputStream2.write(buffer, 0, read2);
                }
            }
        };
        return (HttpRequest) r3.call();
    }

    /* access modifiers changed from: protected */
    public HttpRequest copy(Reader reader, Writer writer) throws IOException {
        C15197 r10;
        Reader input = reader;
        C15197 r3 = r10;
        final Reader reader2 = input;
        final Writer writer2 = writer;
        C15197 r4 = new CloseOperation<HttpRequest>(this, input, this.ignoreCloseExceptions) {
            final /* synthetic */ HttpRequest this$0;

            {
                Closeable closeable = r11;
                boolean ignoreCloseExceptions = r12;
                Reader reader = r13;
                Writer writer = r14;
                this.this$0 = r10;
            }

            public HttpRequest run() throws IOException {
                char[] buffer = new char[this.this$0.bufferSize];
                while (true) {
                    int read = reader2.read(buffer);
                    int read2 = read;
                    if (read == -1) {
                        return this.this$0;
                    }
                    writer2.write(buffer, 0, read2);
                }
            }
        };
        return (HttpRequest) r3.call();
    }

    /* access modifiers changed from: protected */
    public HttpRequest closeOutput() throws IOException {
        if (this.output == null) {
            return this;
        }
        if (this.multipart) {
            RequestOutputStream write = this.output.write("\r\n--00content0boundary00--\r\n");
        }
        if (this.ignoreCloseExceptions) {
            try {
                this.output.close();
            } catch (IOException e) {
                IOException iOException = e;
            }
        } else {
            this.output.close();
        }
        this.output = null;
        return this;
    }

    /* access modifiers changed from: protected */
    public HttpRequest closeOutputQuietly() throws HttpRequestException {
        HttpRequestException httpRequestException;
        try {
            return closeOutput();
        } catch (IOException e) {
            IOException e2 = e;
            HttpRequestException httpRequestException2 = httpRequestException;
            HttpRequestException httpRequestException3 = new HttpRequestException(e2);
            throw httpRequestException2;
        }
    }

    /* access modifiers changed from: protected */
    public HttpRequest openOutput() throws IOException {
        RequestOutputStream requestOutputStream;
        if (this.output != null) {
            return this;
        }
        getConnection().setDoOutput(true);
        RequestOutputStream requestOutputStream2 = requestOutputStream;
        RequestOutputStream requestOutputStream3 = new RequestOutputStream(getConnection().getOutputStream(), getParam(getConnection().getRequestProperty("Content-Type"), PARAM_CHARSET), this.bufferSize);
        this.output = requestOutputStream2;
        return this;
    }

    /* access modifiers changed from: protected */
    public HttpRequest startPart() throws IOException {
        if (!this.multipart) {
            this.multipart = true;
            HttpRequest openOutput = contentType(CONTENT_TYPE_MULTIPART).openOutput();
            RequestOutputStream write = this.output.write("--00content0boundary00\r\n");
        } else {
            RequestOutputStream write2 = this.output.write("\r\n--00content0boundary00\r\n");
        }
        return this;
    }

    /* access modifiers changed from: protected */
    public HttpRequest writePartHeader(String str, String str2) throws IOException {
        return writePartHeader(str, str2, null);
    }

    /* access modifiers changed from: protected */
    public HttpRequest writePartHeader(String str, String str2, String str3) throws IOException {
        StringBuilder sb;
        String name = str;
        String filename = str2;
        String contentType = str3;
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        StringBuilder partBuffer = sb2;
        StringBuilder append = partBuffer.append("form-data; name=\"").append(name);
        if (filename != null) {
            StringBuilder append2 = partBuffer.append("\"; filename=\"").append(filename);
        }
        StringBuilder append3 = partBuffer.append('\"');
        HttpRequest partHeader = partHeader("Content-Disposition", partBuffer.toString());
        if (contentType != null) {
            HttpRequest partHeader2 = partHeader("Content-Type", contentType);
        }
        return send((CharSequence) CRLF);
    }

    public HttpRequest part(String str, String str2) {
        return part(str, (String) null, str2);
    }

    public HttpRequest part(String str, String str2, String str3) throws HttpRequestException {
        return part(str, str2, (String) null, str3);
    }

    public HttpRequest part(String str, String str2, String str3, String str4) throws HttpRequestException {
        HttpRequestException httpRequestException;
        String name = str;
        String filename = str2;
        String contentType = str3;
        String part = str4;
        try {
            HttpRequest startPart = startPart();
            HttpRequest writePartHeader = writePartHeader(name, filename, contentType);
            RequestOutputStream write = this.output.write(part);
            return this;
        } catch (IOException e) {
            IOException e2 = e;
            HttpRequestException httpRequestException2 = httpRequestException;
            HttpRequestException httpRequestException3 = new HttpRequestException(e2);
            throw httpRequestException2;
        }
    }

    public HttpRequest part(String str, Number number) throws HttpRequestException {
        return part(str, (String) null, number);
    }

    public HttpRequest part(String str, String str2, Number number) throws HttpRequestException {
        Number part = number;
        return part(str, str2, part != null ? part.toString() : null);
    }

    public HttpRequest part(String str, File file) throws HttpRequestException {
        return part(str, (String) null, file);
    }

    public HttpRequest part(String str, String str2, File file) throws HttpRequestException {
        return part(str, str2, (String) null, file);
    }

    public HttpRequest part(String str, String str2, String str3, File file) throws HttpRequestException {
        HttpRequestException httpRequestException;
        BufferedInputStream bufferedInputStream;
        FileInputStream fileInputStream;
        String name = str;
        String filename = str2;
        String contentType = str3;
        BufferedInputStream bufferedInputStream2 = null;
        try {
            BufferedInputStream bufferedInputStream3 = bufferedInputStream;
            FileInputStream fileInputStream2 = fileInputStream;
            FileInputStream fileInputStream3 = new FileInputStream(file);
            BufferedInputStream bufferedInputStream4 = new BufferedInputStream(fileInputStream2);
            bufferedInputStream2 = bufferedInputStream3;
            HttpRequest part = part(name, filename, contentType, (InputStream) bufferedInputStream2);
            if (bufferedInputStream2 != null) {
                try {
                    bufferedInputStream2.close();
                } catch (IOException e) {
                    IOException iOException = e;
                }
            }
            return part;
        } catch (IOException e2) {
            IOException e3 = e2;
            HttpRequestException httpRequestException2 = httpRequestException;
            HttpRequestException httpRequestException3 = new HttpRequestException(e3);
            throw httpRequestException2;
        } catch (Throwable th) {
            Throwable th2 = th;
            if (bufferedInputStream2 != null) {
                try {
                    bufferedInputStream2.close();
                } catch (IOException e4) {
                    IOException iOException2 = e4;
                }
            }
            throw th2;
        }
    }

    public HttpRequest part(String str, InputStream inputStream) throws HttpRequestException {
        return part(str, (String) null, (String) null, inputStream);
    }

    public HttpRequest part(String str, String str2, String str3, InputStream inputStream) throws HttpRequestException {
        HttpRequestException httpRequestException;
        String name = str;
        String filename = str2;
        String contentType = str3;
        InputStream part = inputStream;
        try {
            HttpRequest startPart = startPart();
            HttpRequest writePartHeader = writePartHeader(name, filename, contentType);
            HttpRequest copy = copy(part, (OutputStream) this.output);
            return this;
        } catch (IOException e) {
            IOException e2 = e;
            HttpRequestException httpRequestException2 = httpRequestException;
            HttpRequestException httpRequestException3 = new HttpRequestException(e2);
            throw httpRequestException2;
        }
    }

    public HttpRequest partHeader(String str, String str2) throws HttpRequestException {
        return send((CharSequence) str).send((CharSequence) ": ").send((CharSequence) str2).send((CharSequence) CRLF);
    }

    public HttpRequest send(File file) throws HttpRequestException {
        HttpRequestException httpRequestException;
        BufferedInputStream bufferedInputStream;
        FileInputStream fileInputStream;
        try {
            BufferedInputStream bufferedInputStream2 = bufferedInputStream;
            FileInputStream fileInputStream2 = fileInputStream;
            FileInputStream fileInputStream3 = new FileInputStream(file);
            BufferedInputStream bufferedInputStream3 = new BufferedInputStream(fileInputStream2);
            return send((InputStream) bufferedInputStream2);
        } catch (FileNotFoundException e) {
            FileNotFoundException e2 = e;
            HttpRequestException httpRequestException2 = httpRequestException;
            HttpRequestException httpRequestException3 = new HttpRequestException(e2);
            throw httpRequestException2;
        }
    }

    public HttpRequest send(byte[] bArr) throws HttpRequestException {
        ByteArrayInputStream byteArrayInputStream;
        ByteArrayInputStream byteArrayInputStream2 = byteArrayInputStream;
        ByteArrayInputStream byteArrayInputStream3 = new ByteArrayInputStream(bArr);
        return send((InputStream) byteArrayInputStream2);
    }

    public HttpRequest send(InputStream inputStream) throws HttpRequestException {
        HttpRequestException httpRequestException;
        InputStream input = inputStream;
        try {
            HttpRequest openOutput = openOutput();
            HttpRequest copy = copy(input, (OutputStream) this.output);
            return this;
        } catch (IOException e) {
            IOException e2 = e;
            HttpRequestException httpRequestException2 = httpRequestException;
            HttpRequestException httpRequestException3 = new HttpRequestException(e2);
            throw httpRequestException2;
        }
    }

    public HttpRequest send(Reader reader) throws HttpRequestException {
        HttpRequestException httpRequestException;
        OutputStreamWriter outputStreamWriter;
        C15208 r9;
        Reader input = reader;
        try {
            HttpRequest openOutput = openOutput();
            OutputStreamWriter outputStreamWriter2 = outputStreamWriter;
            OutputStreamWriter outputStreamWriter3 = new OutputStreamWriter(this.output, this.output.encoder.charset());
            OutputStreamWriter outputStreamWriter4 = outputStreamWriter2;
            C15208 r3 = r9;
            final Reader reader2 = input;
            final OutputStreamWriter outputStreamWriter5 = outputStreamWriter4;
            C15208 r4 = new FlushOperation<HttpRequest>(this, outputStreamWriter4) {
                final /* synthetic */ HttpRequest this$0;

                {
                    Flushable flushable = r9;
                    Reader reader = r10;
                    Writer writer = r11;
                    this.this$0 = r8;
                }

                /* access modifiers changed from: protected */
                public HttpRequest run() throws IOException {
                    return this.this$0.copy(reader2, outputStreamWriter5);
                }
            };
            return (HttpRequest) r3.call();
        } catch (IOException e) {
            IOException e2 = e;
            HttpRequestException httpRequestException2 = httpRequestException;
            HttpRequestException httpRequestException3 = new HttpRequestException(e2);
            throw httpRequestException2;
        }
    }

    public HttpRequest send(CharSequence charSequence) throws HttpRequestException {
        HttpRequestException httpRequestException;
        CharSequence value = charSequence;
        try {
            HttpRequest openOutput = openOutput();
            RequestOutputStream write = this.output.write(value.toString());
            return this;
        } catch (IOException e) {
            IOException e2 = e;
            HttpRequestException httpRequestException2 = httpRequestException;
            HttpRequestException httpRequestException3 = new HttpRequestException(e2);
            throw httpRequestException2;
        }
    }

    public OutputStreamWriter writer() throws HttpRequestException {
        HttpRequestException httpRequestException;
        OutputStreamWriter outputStreamWriter;
        try {
            HttpRequest openOutput = openOutput();
            OutputStreamWriter outputStreamWriter2 = outputStreamWriter;
            OutputStreamWriter outputStreamWriter3 = new OutputStreamWriter(this.output, this.output.encoder.charset());
            return outputStreamWriter2;
        } catch (IOException e) {
            IOException e2 = e;
            HttpRequestException httpRequestException2 = httpRequestException;
            HttpRequestException httpRequestException3 = new HttpRequestException(e2);
            throw httpRequestException2;
        }
    }

    public HttpRequest form(Map<?, ?> map) throws HttpRequestException {
        return form(map, "UTF-8");
    }

    public HttpRequest form(Entry<?, ?> entry) throws HttpRequestException {
        return form(entry, "UTF-8");
    }

    public HttpRequest form(Entry<?, ?> entry, String str) throws HttpRequestException {
        Entry<?, ?> entry2 = entry;
        return form(entry2.getKey(), entry2.getValue(), str);
    }

    public HttpRequest form(Object obj, Object obj2) throws HttpRequestException {
        return form(obj, obj2, "UTF-8");
    }

    public HttpRequest form(Object obj, Object obj2, String str) throws HttpRequestException {
        HttpRequestException httpRequestException;
        Object name = obj;
        Object value = obj2;
        String charset = str;
        boolean first = !this.form;
        if (first) {
            HttpRequest contentType = contentType("application/x-www-form-urlencoded", charset);
            this.form = true;
        }
        String charset2 = getValidCharset(charset);
        try {
            HttpRequest openOutput = openOutput();
            if (!first) {
                this.output.write(38);
            }
            RequestOutputStream write = this.output.write(URLEncoder.encode(name.toString(), charset2));
            this.output.write(61);
            if (value != null) {
                RequestOutputStream write2 = this.output.write(URLEncoder.encode(value.toString(), charset2));
            }
            return this;
        } catch (IOException e) {
            IOException e2 = e;
            HttpRequestException httpRequestException2 = httpRequestException;
            HttpRequestException httpRequestException3 = new HttpRequestException(e2);
            throw httpRequestException2;
        }
    }

    public HttpRequest form(Map<?, ?> map, String str) throws HttpRequestException {
        Map<?, ?> values = map;
        String charset = str;
        if (!values.isEmpty()) {
            for (Entry form2 : values.entrySet()) {
                HttpRequest form3 = form(form2, charset);
            }
        }
        return this;
    }

    public HttpRequest trustAllCerts() throws HttpRequestException {
        return this;
    }

    public HttpRequest trustAllHosts() {
        return this;
    }

    public URL url() {
        return getConnection().getURL();
    }

    public String method() {
        return getConnection().getRequestMethod();
    }

    public HttpRequest useProxy(String str, int i) {
        IllegalStateException illegalStateException;
        String proxyHost = str;
        int proxyPort = i;
        if (this.connection != null) {
            IllegalStateException illegalStateException2 = illegalStateException;
            IllegalStateException illegalStateException3 = new IllegalStateException("The connection has already been created. This method must be called before reading or writing to the request.");
            throw illegalStateException2;
        }
        this.httpProxyHost = proxyHost;
        this.httpProxyPort = proxyPort;
        return this;
    }

    public HttpRequest followRedirects(boolean z) {
        getConnection().setInstanceFollowRedirects(z);
        return this;
    }
}
