package p004io.fabric.sdk.android.services.concurrency;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/* renamed from: io.fabric.sdk.android.services.concurrency.PriorityTask */
public class PriorityTask implements Dependency<Task>, PriorityProvider, Task {
    private final List<Task> dependencies;
    private final AtomicBoolean hasRun;
    private final AtomicReference<Throwable> throwable;

    public PriorityTask() {
        ArrayList arrayList;
        AtomicBoolean atomicBoolean;
        AtomicReference<Throwable> atomicReference;
        ArrayList arrayList2 = arrayList;
        ArrayList arrayList3 = new ArrayList();
        this.dependencies = arrayList2;
        AtomicBoolean atomicBoolean2 = atomicBoolean;
        AtomicBoolean atomicBoolean3 = new AtomicBoolean(false);
        this.hasRun = atomicBoolean2;
        AtomicReference<Throwable> atomicReference2 = atomicReference;
        AtomicReference<Throwable> atomicReference3 = new AtomicReference<>(null);
        this.throwable = atomicReference2;
    }

    public synchronized Collection<Task> getDependencies() {
        Collection unmodifiableCollection;
        synchronized (this) {
            unmodifiableCollection = Collections.unmodifiableCollection(this.dependencies);
        }
        return unmodifiableCollection;
    }

    public synchronized void addDependency(Task task) {
        Task task2 = task;
        synchronized (this) {
            boolean add = this.dependencies.add(task2);
        }
    }

    public boolean areDependenciesMet() {
        for (Task isFinished : getDependencies()) {
            if (!isFinished.isFinished()) {
                return false;
            }
        }
        return true;
    }

    public synchronized void setFinished(boolean z) {
        boolean finished = z;
        synchronized (this) {
            this.hasRun.set(finished);
        }
    }

    public boolean isFinished() {
        return this.hasRun.get();
    }

    public Priority getPriority() {
        return Priority.NORMAL;
    }

    public void setError(Throwable th) {
        Throwable throwable2 = th;
        this.throwable.set(throwable2);
    }

    public Throwable getError() {
        return (Throwable) this.throwable.get();
    }

    public int compareTo(Object obj) {
        return Priority.compareTo(this, obj);
    }

    public static boolean isProperDelegate(Object obj) {
        Object object = obj;
        try {
            return (((Dependency) object) == null || ((Task) object) == null || ((PriorityProvider) object) == null) ? false : true;
        } catch (ClassCastException e) {
            ClassCastException classCastException = e;
            return false;
        }
    }
}
