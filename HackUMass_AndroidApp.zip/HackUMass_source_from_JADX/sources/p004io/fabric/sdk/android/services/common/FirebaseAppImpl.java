package p004io.fabric.sdk.android.services.common;

import android.content.Context;
import java.lang.reflect.Method;
import p004io.fabric.sdk.android.Fabric;
import p004io.fabric.sdk.android.Logger;

/* renamed from: io.fabric.sdk.android.services.common.FirebaseAppImpl */
final class FirebaseAppImpl implements FirebaseApp {
    private static final String FIREBASE_APP_CLASS = "com.google.firebase.FirebaseApp";
    private static final String GET_INSTANCE_METHOD = "getInstance";
    private static final String IS_DATA_COLLECTION_ENABLED_METHOD = "isDataCollectionDefaultEnabled";
    private final Object firebaseAppInstance;
    private final Method isDataCollectionDefaultEnabledMethod;

    public static FirebaseApp getInstance(Context context) {
        StringBuilder sb;
        FirebaseAppImpl firebaseAppImpl;
        try {
            Class firebaseAppClass = context.getClassLoader().loadClass(FIREBASE_APP_CLASS);
            FirebaseAppImpl firebaseAppImpl2 = firebaseAppImpl;
            FirebaseAppImpl firebaseAppImpl3 = new FirebaseAppImpl(firebaseAppClass, firebaseAppClass.getDeclaredMethod(GET_INSTANCE_METHOD, new Class[0]).invoke(firebaseAppClass, new Object[0]));
            return firebaseAppImpl2;
        } catch (ClassNotFoundException e) {
            ClassNotFoundException classNotFoundException = e;
            Fabric.getLogger().mo23829d(Fabric.TAG, "Could not find class: com.google.firebase.FirebaseApp");
            return null;
        } catch (NoSuchMethodException e2) {
            NoSuchMethodException e3 = e2;
            Logger logger = Fabric.getLogger();
            String str = Fabric.TAG;
            StringBuilder sb2 = sb;
            StringBuilder sb3 = new StringBuilder();
            logger.mo23829d(str, sb2.append("Could not find method: ").append(e3.getMessage()).toString());
            return null;
        } catch (Exception e4) {
            Fabric.getLogger().mo23830d(Fabric.TAG, "Unexpected error loading FirebaseApp instance.", e4);
            return null;
        }
    }

    private FirebaseAppImpl(Class cls, Object obj) throws NoSuchMethodException {
        Class firebaseAppClass = cls;
        this.firebaseAppInstance = obj;
        this.isDataCollectionDefaultEnabledMethod = firebaseAppClass.getDeclaredMethod(IS_DATA_COLLECTION_ENABLED_METHOD, new Class[0]);
    }

    public boolean isDataCollectionDefaultEnabled() {
        try {
            return ((Boolean) this.isDataCollectionDefaultEnabledMethod.invoke(this.firebaseAppInstance, new Object[0])).booleanValue();
        } catch (Exception e) {
            Fabric.getLogger().mo23830d(Fabric.TAG, "Cannot check isDataCollectionDefaultEnabled on FirebaseApp.", e);
            return false;
        }
    }
}
