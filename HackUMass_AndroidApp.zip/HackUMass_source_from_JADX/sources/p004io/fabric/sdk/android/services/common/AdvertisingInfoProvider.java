package p004io.fabric.sdk.android.services.common;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;
import p004io.fabric.sdk.android.Fabric;
import p004io.fabric.sdk.android.services.persistence.PreferenceStore;
import p004io.fabric.sdk.android.services.persistence.PreferenceStoreImpl;

/* renamed from: io.fabric.sdk.android.services.common.AdvertisingInfoProvider */
class AdvertisingInfoProvider {
    private static final String ADVERTISING_INFO_PREFERENCES = "TwitterAdvertisingInfoPreferences";
    private static final String PREFKEY_ADVERTISING_ID = "advertising_id";
    private static final String PREFKEY_LIMIT_AD_TRACKING = "limit_ad_tracking_enabled";
    private final Context context;
    private final PreferenceStore preferenceStore;

    public AdvertisingInfoProvider(Context context2) {
        PreferenceStoreImpl preferenceStoreImpl;
        Context context3 = context2;
        this.context = context3.getApplicationContext();
        PreferenceStoreImpl preferenceStoreImpl2 = preferenceStoreImpl;
        PreferenceStoreImpl preferenceStoreImpl3 = new PreferenceStoreImpl(context3, ADVERTISING_INFO_PREFERENCES);
        this.preferenceStore = preferenceStoreImpl2;
    }

    public AdvertisingInfo getAdvertisingInfo() {
        AdvertisingInfo infoToReturn = getInfoFromPreferences();
        if (isInfoValid(infoToReturn)) {
            Fabric.getLogger().mo23829d(Fabric.TAG, "Using AdvertisingInfo from Preference Store");
            refreshInfoIfNeededAsync(infoToReturn);
            return infoToReturn;
        }
        AdvertisingInfo infoToReturn2 = getAdvertisingInfoFromStrategies();
        storeInfoToPreferences(infoToReturn2);
        return infoToReturn2;
    }

    private void refreshInfoIfNeededAsync(AdvertisingInfo advertisingInfo) {
        Thread thread;
        C14921 r8;
        Thread thread2 = thread;
        C14921 r4 = r8;
        final AdvertisingInfo advertisingInfo2 = advertisingInfo;
        C14921 r5 = new BackgroundPriorityRunnable(this) {
            final /* synthetic */ AdvertisingInfoProvider this$0;

            {
                AdvertisingInfo advertisingInfo = r7;
                this.this$0 = r6;
            }

            public void onRun() {
                AdvertisingInfo infoToStore = this.this$0.getAdvertisingInfoFromStrategies();
                if (!advertisingInfo2.equals(infoToStore)) {
                    Fabric.getLogger().mo23829d(Fabric.TAG, "Asychronously getting Advertising Info and storing it to preferences");
                    this.this$0.storeInfoToPreferences(infoToStore);
                }
            }
        };
        Thread thread3 = new Thread(r4);
        thread2.start();
    }

    /* access modifiers changed from: private */
    @SuppressLint({"CommitPrefEdits"})
    public void storeInfoToPreferences(AdvertisingInfo advertisingInfo) {
        AdvertisingInfo infoToReturn = advertisingInfo;
        if (isInfoValid(infoToReturn)) {
            boolean save = this.preferenceStore.save(this.preferenceStore.edit().putString(PREFKEY_ADVERTISING_ID, infoToReturn.advertisingId).putBoolean(PREFKEY_LIMIT_AD_TRACKING, infoToReturn.limitAdTrackingEnabled));
        } else {
            boolean save2 = this.preferenceStore.save(this.preferenceStore.edit().remove(PREFKEY_ADVERTISING_ID).remove(PREFKEY_LIMIT_AD_TRACKING));
        }
    }

    /* access modifiers changed from: protected */
    public AdvertisingInfo getInfoFromPreferences() {
        AdvertisingInfo advertisingInfo;
        AdvertisingInfo advertisingInfo2 = advertisingInfo;
        AdvertisingInfo advertisingInfo3 = new AdvertisingInfo(this.preferenceStore.get().getString(PREFKEY_ADVERTISING_ID, ""), this.preferenceStore.get().getBoolean(PREFKEY_LIMIT_AD_TRACKING, false));
        return advertisingInfo2;
    }

    public AdvertisingInfoStrategy getReflectionStrategy() {
        AdvertisingInfoReflectionStrategy advertisingInfoReflectionStrategy;
        AdvertisingInfoReflectionStrategy advertisingInfoReflectionStrategy2 = advertisingInfoReflectionStrategy;
        AdvertisingInfoReflectionStrategy advertisingInfoReflectionStrategy3 = new AdvertisingInfoReflectionStrategy(this.context);
        return advertisingInfoReflectionStrategy2;
    }

    public AdvertisingInfoStrategy getServiceStrategy() {
        AdvertisingInfoServiceStrategy advertisingInfoServiceStrategy;
        AdvertisingInfoServiceStrategy advertisingInfoServiceStrategy2 = advertisingInfoServiceStrategy;
        AdvertisingInfoServiceStrategy advertisingInfoServiceStrategy3 = new AdvertisingInfoServiceStrategy(this.context);
        return advertisingInfoServiceStrategy2;
    }

    private boolean isInfoValid(AdvertisingInfo advertisingInfo) {
        AdvertisingInfo advertisingInfo2 = advertisingInfo;
        return advertisingInfo2 != null && !TextUtils.isEmpty(advertisingInfo2.advertisingId);
    }

    /* access modifiers changed from: private */
    public AdvertisingInfo getAdvertisingInfoFromStrategies() {
        AdvertisingInfo infoToReturn = getReflectionStrategy().getAdvertisingInfo();
        if (!isInfoValid(infoToReturn)) {
            infoToReturn = getServiceStrategy().getAdvertisingInfo();
            if (!isInfoValid(infoToReturn)) {
                Fabric.getLogger().mo23829d(Fabric.TAG, "AdvertisingInfo not present");
            } else {
                Fabric.getLogger().mo23829d(Fabric.TAG, "Using AdvertisingInfo from Service Provider");
            }
        } else {
            Fabric.getLogger().mo23829d(Fabric.TAG, "Using AdvertisingInfo from Reflection Provider");
        }
        return infoToReturn;
    }
}
