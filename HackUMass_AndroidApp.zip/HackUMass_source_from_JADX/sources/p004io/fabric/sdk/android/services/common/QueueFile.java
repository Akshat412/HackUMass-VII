package p004io.fabric.sdk.android.services.common;

import android.support.p000v4.media.session.PlaybackStateCompat;
import com.google.appinventor.components.runtime.util.Ev3Constants.Opcode;
import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.util.NoSuchElementException;
import java.util.logging.Level;
import java.util.logging.Logger;

/* renamed from: io.fabric.sdk.android.services.common.QueueFile */
public class QueueFile implements Closeable {
    static final int HEADER_LENGTH = 16;
    private static final int INITIAL_LENGTH = 4096;
    private static final Logger LOGGER = Logger.getLogger(QueueFile.class.getName());
    private final byte[] buffer = new byte[16];
    private int elementCount;
    int fileLength;
    private Element first;
    private Element last;
    /* access modifiers changed from: private */
    public final RandomAccessFile raf;

    /* renamed from: io.fabric.sdk.android.services.common.QueueFile$Element */
    static class Element {
        static final int HEADER_LENGTH = 4;
        static final Element NULL;
        final int length;
        final int position;

        static {
            Element element;
            Element element2 = element;
            Element element3 = new Element(0, 0);
            NULL = element2;
        }

        Element(int i, int i2) {
            int length2 = i2;
            this.position = i;
            this.length = length2;
        }

        public String toString() {
            StringBuilder sb;
            StringBuilder sb2 = sb;
            StringBuilder sb3 = new StringBuilder();
            return sb2.append(getClass().getSimpleName()).append("[position = ").append(this.position).append(", length = ").append(this.length).append("]").toString();
        }
    }

    /* renamed from: io.fabric.sdk.android.services.common.QueueFile$ElementInputStream */
    private final class ElementInputStream extends InputStream {
        private int position;
        private int remaining;
        final /* synthetic */ QueueFile this$0;

        /* synthetic */ ElementInputStream(QueueFile queueFile, Element element, C14991 r10) {
            C14991 r3 = r10;
            this(queueFile, element);
        }

        private ElementInputStream(QueueFile queueFile, Element element) {
            QueueFile queueFile2 = queueFile;
            Element element2 = element;
            this.this$0 = queueFile2;
            this.position = queueFile2.wrapPosition(element2.position + 4);
            this.remaining = element2.length;
        }

        public int read(byte[] bArr, int i, int i2) throws IOException {
            ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException;
            byte[] buffer = bArr;
            int offset = i;
            int length = i2;
            Object access$200 = QueueFile.nonNull(buffer, "buffer");
            if ((offset | length) < 0 || length > buffer.length - offset) {
                ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException2 = arrayIndexOutOfBoundsException;
                ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException3 = new ArrayIndexOutOfBoundsException();
                throw arrayIndexOutOfBoundsException2;
            } else if (this.remaining <= 0) {
                return -1;
            } else {
                if (length > this.remaining) {
                    length = this.remaining;
                }
                this.this$0.ringRead(this.position, buffer, offset, length);
                this.position = this.this$0.wrapPosition(this.position + length);
                this.remaining -= length;
                return length;
            }
        }

        public int read() throws IOException {
            if (this.remaining == 0) {
                return -1;
            }
            this.this$0.raf.seek((long) this.position);
            int b = this.this$0.raf.read();
            this.position = this.this$0.wrapPosition(this.position + 1);
            this.remaining--;
            return b;
        }
    }

    /* renamed from: io.fabric.sdk.android.services.common.QueueFile$ElementReader */
    public interface ElementReader {
        void read(InputStream inputStream, int i) throws IOException;
    }

    public QueueFile(File file) throws IOException {
        File file2 = file;
        if (!file2.exists()) {
            initialize(file2);
        }
        this.raf = open(file2);
        readHeader();
    }

    QueueFile(RandomAccessFile randomAccessFile) throws IOException {
        RandomAccessFile raf2 = randomAccessFile;
        this.raf = raf2;
        readHeader();
    }

    private static void writeInt(byte[] bArr, int i, int i2) {
        byte[] buffer2 = bArr;
        int offset = i;
        int value = i2;
        buffer2[offset] = (byte) (value >> 24);
        buffer2[offset + 1] = (byte) (value >> 16);
        buffer2[offset + 2] = (byte) (value >> 8);
        buffer2[offset + 3] = (byte) value;
    }

    private static void writeInts(byte[] bArr, int... iArr) {
        byte[] buffer2 = bArr;
        int offset = 0;
        int[] iArr2 = iArr;
        int length = iArr2.length;
        for (int i = 0; i < length; i++) {
            writeInt(buffer2, offset, iArr2[i]);
            offset += 4;
        }
    }

    private static int readInt(byte[] bArr, int i) {
        byte[] buffer2 = bArr;
        int offset = i;
        return ((buffer2[offset] & Opcode.TST) << 24) + ((buffer2[offset + 1] & Opcode.TST) << 16) + ((buffer2[offset + 2] & Opcode.TST) << 8) + (buffer2[offset + 3] & Opcode.TST);
    }

    private void readHeader() throws IOException {
        IOException iOException;
        StringBuilder sb;
        this.raf.seek(0);
        this.raf.readFully(this.buffer);
        this.fileLength = readInt(this.buffer, 0);
        if (((long) this.fileLength) > this.raf.length()) {
            IOException iOException2 = iOException;
            StringBuilder sb2 = sb;
            StringBuilder sb3 = new StringBuilder();
            IOException iOException3 = new IOException(sb2.append("File is truncated. Expected length: ").append(this.fileLength).append(", Actual length: ").append(this.raf.length()).toString());
            throw iOException2;
        }
        this.elementCount = readInt(this.buffer, 4);
        int firstOffset = readInt(this.buffer, 8);
        int lastOffset = readInt(this.buffer, 12);
        this.first = readElement(firstOffset);
        this.last = readElement(lastOffset);
    }

    private void writeHeader(int i, int i2, int i3, int i4) throws IOException {
        int fileLength2 = i;
        int elementCount2 = i2;
        int firstPosition = i3;
        int lastPosition = i4;
        byte[] bArr = this.buffer;
        int[] iArr = new int[4];
        int[] iArr2 = iArr;
        iArr[0] = fileLength2;
        int[] iArr3 = iArr2;
        int[] iArr4 = iArr3;
        iArr3[1] = elementCount2;
        int[] iArr5 = iArr4;
        int[] iArr6 = iArr5;
        iArr5[2] = firstPosition;
        int[] iArr7 = iArr6;
        int[] iArr8 = iArr7;
        iArr7[3] = lastPosition;
        writeInts(bArr, iArr8);
        this.raf.seek(0);
        this.raf.write(this.buffer);
    }

    private Element readElement(int i) throws IOException {
        Element element;
        int position = i;
        if (position == 0) {
            return Element.NULL;
        }
        this.raf.seek((long) position);
        Element element2 = element;
        Element element3 = new Element(position, this.raf.readInt());
        return element2;
    }

    private static void initialize(File file) throws IOException {
        File file2;
        StringBuilder sb;
        IOException iOException;
        File file3 = file;
        File file4 = file2;
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        File file5 = new File(sb2.append(file3.getPath()).append(".tmp").toString());
        File tempFile = file4;
        RandomAccessFile raf2 = open(tempFile);
        try {
            raf2.setLength(PlaybackStateCompat.ACTION_SKIP_TO_QUEUE_ITEM);
            raf2.seek(0);
            byte[] headerBuffer = new byte[16];
            writeInts(headerBuffer, 4096, 0, 0, 0);
            raf2.write(headerBuffer);
            raf2.close();
            if (!tempFile.renameTo(file3)) {
                IOException iOException2 = iOException;
                IOException iOException3 = new IOException("Rename failed!");
                throw iOException2;
            }
        } catch (Throwable th) {
            Throwable th2 = th;
            raf2.close();
            throw th2;
        }
    }

    private static RandomAccessFile open(File file) throws FileNotFoundException {
        RandomAccessFile randomAccessFile;
        RandomAccessFile randomAccessFile2 = randomAccessFile;
        RandomAccessFile randomAccessFile3 = new RandomAccessFile(file, "rwd");
        return randomAccessFile2;
    }

    /* access modifiers changed from: private */
    public int wrapPosition(int i) {
        int position = i;
        return position < this.fileLength ? position : (16 + position) - this.fileLength;
    }

    private void ringWrite(int i, byte[] bArr, int i2, int i3) throws IOException {
        byte[] buffer2 = bArr;
        int offset = i2;
        int count = i3;
        int position = wrapPosition(i);
        if (position + count <= this.fileLength) {
            this.raf.seek((long) position);
            this.raf.write(buffer2, offset, count);
            return;
        }
        int beforeEof = this.fileLength - position;
        this.raf.seek((long) position);
        this.raf.write(buffer2, offset, beforeEof);
        this.raf.seek(16);
        this.raf.write(buffer2, offset + beforeEof, count - beforeEof);
    }

    /* access modifiers changed from: private */
    public void ringRead(int i, byte[] bArr, int i2, int i3) throws IOException {
        byte[] buffer2 = bArr;
        int offset = i2;
        int count = i3;
        int position = wrapPosition(i);
        if (position + count <= this.fileLength) {
            this.raf.seek((long) position);
            this.raf.readFully(buffer2, offset, count);
            return;
        }
        int beforeEof = this.fileLength - position;
        this.raf.seek((long) position);
        this.raf.readFully(buffer2, offset, beforeEof);
        this.raf.seek(16);
        this.raf.readFully(buffer2, offset + beforeEof, count - beforeEof);
    }

    public void add(byte[] bArr) throws IOException {
        byte[] data = bArr;
        add(data, 0, data.length);
    }

    public synchronized void add(byte[] bArr, int i, int i2) throws IOException {
        IndexOutOfBoundsException indexOutOfBoundsException;
        int wrapPosition;
        Element element;
        byte[] data = bArr;
        int offset = i;
        int count = i2;
        synchronized (this) {
            Object nonNull = nonNull(data, "buffer");
            if ((offset | count) < 0 || count > data.length - offset) {
                IndexOutOfBoundsException indexOutOfBoundsException2 = indexOutOfBoundsException;
                IndexOutOfBoundsException indexOutOfBoundsException3 = new IndexOutOfBoundsException();
                throw indexOutOfBoundsException2;
            }
            expandIfNecessary(count);
            boolean wasEmpty = isEmpty();
            if (wasEmpty) {
                wrapPosition = 16;
            } else {
                wrapPosition = wrapPosition(this.last.position + 4 + this.last.length);
            }
            int position = wrapPosition;
            Element element2 = element;
            Element element3 = new Element(position, count);
            Element newLast = element2;
            writeInt(this.buffer, 0, count);
            ringWrite(newLast.position, this.buffer, 0, 4);
            ringWrite(newLast.position + 4, data, offset, count);
            writeHeader(this.fileLength, this.elementCount + 1, wasEmpty ? newLast.position : this.first.position, newLast.position);
            this.last = newLast;
            this.elementCount++;
            if (wasEmpty) {
                this.first = this.last;
            }
        }
    }

    public int usedBytes() {
        if (this.elementCount == 0) {
            return 16;
        }
        if (this.last.position >= this.first.position) {
            return (this.last.position - this.first.position) + 4 + this.last.length + 16;
        }
        return (((this.last.position + 4) + this.last.length) + this.fileLength) - this.first.position;
    }

    private int remainingBytes() {
        return this.fileLength - usedBytes();
    }

    public synchronized boolean isEmpty() {
        boolean z;
        synchronized (this) {
            z = this.elementCount == 0;
        }
        return z;
    }

    private void expandIfNecessary(int i) throws IOException {
        int newLength;
        Element element;
        AssertionError assertionError;
        int elementLength = 4 + i;
        int remainingBytes = remainingBytes();
        if (remainingBytes < elementLength) {
            int previousLength = this.fileLength;
            do {
                remainingBytes += previousLength;
                newLength = previousLength << 1;
                previousLength = newLength;
            } while (remainingBytes < elementLength);
            setLength(newLength);
            int endOfLastElement = wrapPosition(this.last.position + 4 + this.last.length);
            if (endOfLastElement < this.first.position) {
                FileChannel channel = this.raf.getChannel();
                FileChannel position = channel.position((long) this.fileLength);
                int count = endOfLastElement - 4;
                if (channel.transferTo(16, (long) count, channel) != ((long) count)) {
                    AssertionError assertionError2 = assertionError;
                    AssertionError assertionError3 = new AssertionError("Copied insufficient number of bytes!");
                    throw assertionError2;
                }
            }
            if (this.last.position < this.first.position) {
                int newLastPosition = (this.fileLength + this.last.position) - 16;
                writeHeader(newLength, this.elementCount, this.first.position, newLastPosition);
                Element element2 = element;
                Element element3 = new Element(newLastPosition, this.last.length);
                this.last = element2;
            } else {
                writeHeader(newLength, this.elementCount, this.first.position, this.last.position);
            }
            this.fileLength = newLength;
        }
    }

    private void setLength(int i) throws IOException {
        this.raf.setLength((long) i);
        this.raf.getChannel().force(true);
    }

    public synchronized byte[] peek() throws IOException {
        byte[] bArr;
        synchronized (this) {
            if (isEmpty()) {
                bArr = null;
            } else {
                int length = this.first.length;
                byte[] data = new byte[length];
                ringRead(this.first.position + 4, data, 0, length);
                bArr = data;
            }
        }
        return bArr;
    }

    public synchronized void peek(ElementReader elementReader) throws IOException {
        ElementInputStream elementInputStream;
        ElementReader reader = elementReader;
        synchronized (this) {
            if (this.elementCount > 0) {
                ElementReader elementReader2 = reader;
                ElementInputStream elementInputStream2 = elementInputStream;
                ElementInputStream elementInputStream3 = new ElementInputStream(this, this.first, null);
                elementReader2.read(elementInputStream2, this.first.length);
            }
        }
    }

    public synchronized void forEach(ElementReader elementReader) throws IOException {
        ElementInputStream elementInputStream;
        ElementReader reader = elementReader;
        synchronized (this) {
            int position = this.first.position;
            for (int i = 0; i < this.elementCount; i++) {
                Element current = readElement(position);
                ElementReader elementReader2 = reader;
                ElementInputStream elementInputStream2 = elementInputStream;
                ElementInputStream elementInputStream3 = new ElementInputStream(this, current, null);
                elementReader2.read(elementInputStream2, current.length);
                position = wrapPosition(current.position + 4 + current.length);
            }
        }
    }

    /* access modifiers changed from: private */
    public static <T> T nonNull(T t, String str) {
        NullPointerException nullPointerException;
        T t2 = t;
        String name = str;
        if (t2 != null) {
            return t2;
        }
        NullPointerException nullPointerException2 = nullPointerException;
        NullPointerException nullPointerException3 = new NullPointerException(name);
        throw nullPointerException2;
    }

    public synchronized int size() {
        int i;
        synchronized (this) {
            i = this.elementCount;
        }
        return i;
    }

    public synchronized void remove() throws IOException {
        Element element;
        NoSuchElementException noSuchElementException;
        synchronized (this) {
            if (isEmpty()) {
                NoSuchElementException noSuchElementException2 = noSuchElementException;
                NoSuchElementException noSuchElementException3 = new NoSuchElementException();
                throw noSuchElementException2;
            } else if (this.elementCount == 1) {
                clear();
            } else {
                int newFirstPosition = wrapPosition(this.first.position + 4 + this.first.length);
                ringRead(newFirstPosition, this.buffer, 0, 4);
                int length = readInt(this.buffer, 0);
                writeHeader(this.fileLength, this.elementCount - 1, newFirstPosition, this.last.position);
                this.elementCount--;
                Element element2 = element;
                Element element3 = new Element(newFirstPosition, length);
                this.first = element2;
            }
        }
    }

    public synchronized void clear() throws IOException {
        synchronized (this) {
            writeHeader(4096, 0, 0, 0);
            this.elementCount = 0;
            this.first = Element.NULL;
            this.last = Element.NULL;
            if (this.fileLength > 4096) {
                setLength(4096);
            }
            this.fileLength = 4096;
        }
    }

    public synchronized void close() throws IOException {
        synchronized (this) {
            this.raf.close();
        }
    }

    public boolean hasSpaceFor(int i, int i2) {
        return (usedBytes() + 4) + i <= i2;
    }

    public String toString() {
        StringBuilder sb;
        C14991 r8;
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        StringBuilder builder = sb2;
        StringBuilder append = builder.append(getClass().getSimpleName()).append('[');
        StringBuilder append2 = builder.append("fileLength=").append(this.fileLength);
        StringBuilder append3 = builder.append(", size=").append(this.elementCount);
        StringBuilder append4 = builder.append(", first=").append(this.first);
        StringBuilder append5 = builder.append(", last=").append(this.last);
        StringBuilder append6 = builder.append(", element lengths=[");
        try {
            C14991 r4 = r8;
            final StringBuilder sb4 = builder;
            C14991 r5 = new ElementReader(this) {
                boolean first = true;
                final /* synthetic */ QueueFile this$0;

                {
                    StringBuilder sb = r7;
                    this.this$0 = r6;
                }

                public void read(InputStream inputStream, int i) throws IOException {
                    InputStream inputStream2 = inputStream;
                    int length = i;
                    if (this.first) {
                        this.first = false;
                    } else {
                        StringBuilder append = sb4.append(", ");
                    }
                    StringBuilder append2 = sb4.append(length);
                }
            };
            forEach(r4);
        } catch (IOException e) {
            LOGGER.log(Level.WARNING, "read error", e);
        }
        StringBuilder append7 = builder.append("]]");
        return builder.toString();
    }
}
