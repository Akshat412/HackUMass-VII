package p004io.fabric.sdk.android.services.persistence;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build.VERSION;
import android.os.Environment;
import java.io.File;
import p004io.fabric.sdk.android.Fabric;
import p004io.fabric.sdk.android.Kit;

/* renamed from: io.fabric.sdk.android.services.persistence.FileStoreImpl */
public class FileStoreImpl implements FileStore {
    private final String contentPath;
    private final Context context;
    private final String legacySupport;

    public FileStoreImpl(Kit kit) {
        StringBuilder sb;
        IllegalStateException illegalStateException;
        Kit kit2 = kit;
        if (kit2.getContext() == null) {
            IllegalStateException illegalStateException2 = illegalStateException;
            IllegalStateException illegalStateException3 = new IllegalStateException("Cannot get directory before context has been set. Call Fabric.with() first");
            throw illegalStateException2;
        }
        this.context = kit2.getContext();
        this.contentPath = kit2.getPath();
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        this.legacySupport = sb2.append("Android/").append(this.context.getPackageName()).toString();
    }

    public File getCacheDir() {
        return prepare(this.context.getCacheDir());
    }

    public File getExternalCacheDir() {
        File file;
        StringBuilder sb;
        File file2 = null;
        if (isExternalStorageAvailable()) {
            if (VERSION.SDK_INT >= 8) {
                file2 = this.context.getExternalCacheDir();
            } else {
                File file3 = file;
                File externalStorageDirectory = Environment.getExternalStorageDirectory();
                StringBuilder sb2 = sb;
                StringBuilder sb3 = new StringBuilder();
                File file4 = new File(externalStorageDirectory, sb2.append(this.legacySupport).append("/cache/").append(this.contentPath).toString());
                file2 = file3;
            }
        }
        return prepare(file2);
    }

    public File getFilesDir() {
        return prepare(this.context.getFilesDir());
    }

    @TargetApi(8)
    public File getExternalFilesDir() {
        File file;
        StringBuilder sb;
        File file2 = null;
        if (isExternalStorageAvailable()) {
            if (VERSION.SDK_INT >= 8) {
                file2 = this.context.getExternalFilesDir(null);
            } else {
                File file3 = file;
                File externalStorageDirectory = Environment.getExternalStorageDirectory();
                StringBuilder sb2 = sb;
                StringBuilder sb3 = new StringBuilder();
                File file4 = new File(externalStorageDirectory, sb2.append(this.legacySupport).append("/files/").append(this.contentPath).toString());
                file2 = file3;
            }
        }
        return prepare(file2);
    }

    /* access modifiers changed from: 0000 */
    public File prepare(File file) {
        File file2 = file;
        if (file2 == null) {
            Fabric.getLogger().mo23829d(Fabric.TAG, "Null File");
        } else if (file2.exists() || file2.mkdirs()) {
            return file2;
        } else {
            Fabric.getLogger().mo23842w(Fabric.TAG, "Couldn't create file");
        }
        return null;
    }

    /* access modifiers changed from: 0000 */
    public boolean isExternalStorageAvailable() {
        if ("mounted".equals(Environment.getExternalStorageState())) {
            return true;
        }
        Fabric.getLogger().mo23842w(Fabric.TAG, "External Storage is not mounted and/or writable\nHave you declared android.permission.WRITE_EXTERNAL_STORAGE in the manifest?");
        return false;
    }
}
