package p004io.fabric.sdk.android.services.persistence;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Build.VERSION;
import p004io.fabric.sdk.android.Kit;

/* renamed from: io.fabric.sdk.android.services.persistence.PreferenceStoreImpl */
public class PreferenceStoreImpl implements PreferenceStore {
    private final Context context;
    private final String preferenceName;
    private final SharedPreferences sharedPreferences;

    public PreferenceStoreImpl(Context context2, String str) {
        IllegalStateException illegalStateException;
        Context context3 = context2;
        String name = str;
        if (context3 == null) {
            IllegalStateException illegalStateException2 = illegalStateException;
            IllegalStateException illegalStateException3 = new IllegalStateException("Cannot get directory before context has been set. Call Fabric.with() first");
            throw illegalStateException2;
        }
        this.context = context3;
        this.preferenceName = name;
        this.sharedPreferences = this.context.getSharedPreferences(this.preferenceName, 0);
    }

    @Deprecated
    public PreferenceStoreImpl(Kit kit) {
        Kit kit2 = kit;
        this(kit2.getContext(), kit2.getClass().getName());
    }

    public SharedPreferences get() {
        return this.sharedPreferences;
    }

    public Editor edit() {
        return this.sharedPreferences.edit();
    }

    @TargetApi(9)
    public boolean save(Editor editor) {
        Editor editor2 = editor;
        if (VERSION.SDK_INT < 9) {
            return editor2.commit();
        }
        editor2.apply();
        return true;
    }
}
