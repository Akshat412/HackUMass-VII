package p004io.fabric.sdk.android.services.concurrency.internal;

import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicReference;

/* renamed from: io.fabric.sdk.android.services.concurrency.internal.RetryFuture */
class RetryFuture<T> extends AbstractFuture<T> implements Runnable {
    private final RetryThreadPoolExecutor executor;
    RetryState retryState;
    private final AtomicReference<Thread> runner;
    private final Callable<T> task;

    RetryFuture(Callable<T> callable, RetryState retryState2, RetryThreadPoolExecutor retryThreadPoolExecutor) {
        AtomicReference<Thread> atomicReference;
        RetryState retryState3 = retryState2;
        RetryThreadPoolExecutor executor2 = retryThreadPoolExecutor;
        this.task = callable;
        this.retryState = retryState3;
        this.executor = executor2;
        AtomicReference<Thread> atomicReference2 = atomicReference;
        AtomicReference<Thread> atomicReference3 = new AtomicReference<>();
        this.runner = atomicReference2;
    }

    public void run() {
        if (!isDone() && this.runner.compareAndSet(null, Thread.currentThread())) {
            try {
                boolean z = set(this.task.call());
                Object andSet = this.runner.getAndSet(null);
            } catch (Throwable th) {
                Throwable th2 = th;
                Object andSet2 = this.runner.getAndSet(null);
                throw th2;
            }
        }
    }

    private RetryPolicy getRetryPolicy() {
        return this.retryState.getRetryPolicy();
    }

    private Backoff getBackoff() {
        return this.retryState.getBackoff();
    }

    private int getRetryCount() {
        return this.retryState.getRetryCount();
    }

    /* access modifiers changed from: protected */
    public void interruptTask() {
        Thread thread = (Thread) this.runner.getAndSet(null);
        if (thread != null) {
            thread.interrupt();
        }
    }
}
