package p004io.fabric.sdk.android.services.concurrency.internal;

/* renamed from: io.fabric.sdk.android.services.concurrency.internal.Backoff */
public interface Backoff {
    long getDelayMillis(int i);
}
