package p004io.fabric.sdk.android.services.common;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import com.google.appinventor.components.common.PropertyTypeConstants;
import p004io.fabric.sdk.android.Fabric;
import p004io.fabric.sdk.android.Logger;

/* renamed from: io.fabric.sdk.android.services.common.ApiKey */
public class ApiKey {
    static final String CRASHLYTICS_API_KEY = "com.crashlytics.ApiKey";
    static final String FABRIC_API_KEY = "io.fabric.ApiKey";
    static final String STRING_TWITTER_CONSUMER_SECRET = "@string/twitter_consumer_secret";

    public ApiKey() {
    }

    @Deprecated
    public static String getApiKey(Context context) {
        ApiKey apiKey;
        Context context2 = context;
        Fabric.getLogger().mo23842w(Fabric.TAG, "getApiKey(context) is deprecated, please upgrade kit(s) to the latest version.");
        ApiKey apiKey2 = apiKey;
        ApiKey apiKey3 = new ApiKey();
        return apiKey2.getValue(context2);
    }

    @Deprecated
    public static String getApiKey(Context context, boolean z) {
        ApiKey apiKey;
        Context context2 = context;
        boolean z2 = z;
        Fabric.getLogger().mo23842w(Fabric.TAG, "getApiKey(context, debug) is deprecated, please upgrade kit(s) to the latest version.");
        ApiKey apiKey2 = apiKey;
        ApiKey apiKey3 = new ApiKey();
        return apiKey2.getValue(context2);
    }

    public String getValue(Context context) {
        Context context2 = context;
        String apiKey = getApiKeyFromManifest(context2);
        if (TextUtils.isEmpty(apiKey)) {
            apiKey = getApiKeyFromStrings(context2);
        }
        if (TextUtils.isEmpty(apiKey)) {
            apiKey = getApiKeyFromFirebaseAppId(context2);
        }
        if (TextUtils.isEmpty(apiKey)) {
            logErrorOrThrowException(context2);
        }
        return apiKey;
    }

    /* access modifiers changed from: protected */
    public String getApiKeyFromFirebaseAppId(Context context) {
        FirebaseInfo firebaseInfo;
        Context context2 = context;
        FirebaseInfo firebaseInfo2 = firebaseInfo;
        FirebaseInfo firebaseInfo3 = new FirebaseInfo();
        return firebaseInfo2.getApiKeyFromFirebaseAppId(context2);
    }

    /* access modifiers changed from: protected */
    public String getApiKeyFromManifest(Context context) {
        StringBuilder sb;
        Context context2 = context;
        String apiKey = null;
        try {
            Bundle bundle = context2.getPackageManager().getApplicationInfo(context2.getPackageName(), 128).metaData;
            if (bundle != null) {
                apiKey = bundle.getString(FABRIC_API_KEY);
                if (STRING_TWITTER_CONSUMER_SECRET.equals(apiKey)) {
                    Fabric.getLogger().mo23829d(Fabric.TAG, "Ignoring bad default value for Fabric ApiKey set by FirebaseUI-Auth");
                    apiKey = null;
                }
                if (apiKey == null) {
                    Fabric.getLogger().mo23829d(Fabric.TAG, "Falling back to Crashlytics key lookup from Manifest");
                    apiKey = bundle.getString(CRASHLYTICS_API_KEY);
                }
            }
        } catch (Exception e) {
            Exception e2 = e;
            Logger logger = Fabric.getLogger();
            String str = Fabric.TAG;
            StringBuilder sb2 = sb;
            StringBuilder sb3 = new StringBuilder();
            logger.mo23829d(str, sb2.append("Caught non-fatal exception while retrieving apiKey: ").append(e2).toString());
        }
        return apiKey;
    }

    /* access modifiers changed from: protected */
    public String getApiKeyFromStrings(Context context) {
        Context context2 = context;
        String apiKey = null;
        int id = CommonUtils.getResourcesIdentifier(context2, FABRIC_API_KEY, PropertyTypeConstants.PROPERTY_TYPE_STRING);
        if (id == 0) {
            Fabric.getLogger().mo23829d(Fabric.TAG, "Falling back to Crashlytics key lookup from Strings");
            id = CommonUtils.getResourcesIdentifier(context2, CRASHLYTICS_API_KEY, PropertyTypeConstants.PROPERTY_TYPE_STRING);
        }
        if (id != 0) {
            apiKey = context2.getResources().getString(id);
        }
        return apiKey;
    }

    /* access modifiers changed from: protected */
    public void logErrorOrThrowException(Context context) {
        IllegalArgumentException illegalArgumentException;
        Context context2 = context;
        if (Fabric.isDebuggable() || CommonUtils.isAppDebuggable(context2)) {
            IllegalArgumentException illegalArgumentException2 = illegalArgumentException;
            IllegalArgumentException illegalArgumentException3 = new IllegalArgumentException(buildApiKeyInstructions());
            throw illegalArgumentException2;
        }
        Fabric.getLogger().mo23831e(Fabric.TAG, buildApiKeyInstructions());
    }

    /* access modifiers changed from: protected */
    public String buildApiKeyInstructions() {
        return "Fabric could not be initialized, API key missing from AndroidManifest.xml. Add the following tag to your Application element \n\t<meta-data android:name=\"io.fabric.ApiKey\" android:value=\"YOUR_API_KEY\"/>";
    }
}
