package p004io.fabric.sdk.android.services.common;

import android.content.Context;
import java.lang.reflect.Method;
import p004io.fabric.sdk.android.Fabric;

/* renamed from: io.fabric.sdk.android.services.common.AdvertisingInfoReflectionStrategy */
class AdvertisingInfoReflectionStrategy implements AdvertisingInfoStrategy {
    private static final String CLASS_NAME_ADVERTISING_ID_CLIENT = "com.google.android.gms.ads.identifier.AdvertisingIdClient";
    private static final String CLASS_NAME_ADVERTISING_ID_CLIENT_INFO = "com.google.android.gms.ads.identifier.AdvertisingIdClient$Info";
    private static final String CLASS_NAME_GOOGLE_PLAY_SERVICES_UTILS = "com.google.android.gms.common.GooglePlayServicesUtil";
    private static final int GOOGLE_PLAY_SERVICES_SUCCESS_CODE = 0;
    private static final String METHOD_NAME_GET_ADVERTISING_ID_INFO = "getAdvertisingIdInfo";
    private static final String METHOD_NAME_GET_ID = "getId";
    private static final String METHOD_NAME_IS_GOOGLE_PLAY_SERVICES_AVAILABLE = "isGooglePlayServicesAvailable";
    private static final String METHOD_NAME_IS_LIMITED_AD_TRACKING_ENABLED = "isLimitAdTrackingEnabled";
    private final Context context;

    public AdvertisingInfoReflectionStrategy(Context context2) {
        this.context = context2.getApplicationContext();
    }

    /* access modifiers changed from: 0000 */
    public boolean isGooglePlayServiceAvailable(Context context2) {
        Context context3 = context2;
        try {
            Class cls = Class.forName(CLASS_NAME_GOOGLE_PLAY_SERVICES_UTILS);
            String str = METHOD_NAME_IS_GOOGLE_PLAY_SERVICES_AVAILABLE;
            Class[] clsArr = new Class[1];
            Class[] clsArr2 = clsArr;
            clsArr[0] = Context.class;
            Method method = cls.getMethod(str, clsArr2);
            Object[] objArr = new Object[1];
            Object[] objArr2 = objArr;
            objArr[0] = context3;
            return ((Integer) method.invoke(null, objArr2)).intValue() == 0;
        } catch (Exception e) {
            Exception exc = e;
            return false;
        }
    }

    public AdvertisingInfo getAdvertisingInfo() {
        AdvertisingInfo advertisingInfo;
        if (!isGooglePlayServiceAvailable(this.context)) {
            return null;
        }
        AdvertisingInfo advertisingInfo2 = advertisingInfo;
        AdvertisingInfo advertisingInfo3 = new AdvertisingInfo(getAdvertisingId(), isLimitAdTrackingEnabled());
        return advertisingInfo2;
    }

    private String getAdvertisingId() {
        try {
            return (String) Class.forName(CLASS_NAME_ADVERTISING_ID_CLIENT_INFO).getMethod(METHOD_NAME_GET_ID, new Class[0]).invoke(getInfo(), new Object[0]);
        } catch (Exception e) {
            Exception exc = e;
            Fabric.getLogger().mo23842w(Fabric.TAG, "Could not call getId on com.google.android.gms.ads.identifier.AdvertisingIdClient$Info");
            return null;
        }
    }

    private boolean isLimitAdTrackingEnabled() {
        try {
            return ((Boolean) Class.forName(CLASS_NAME_ADVERTISING_ID_CLIENT_INFO).getMethod(METHOD_NAME_IS_LIMITED_AD_TRACKING_ENABLED, new Class[0]).invoke(getInfo(), new Object[0])).booleanValue();
        } catch (Exception e) {
            Exception exc = e;
            Fabric.getLogger().mo23842w(Fabric.TAG, "Could not call isLimitAdTrackingEnabled on com.google.android.gms.ads.identifier.AdvertisingIdClient$Info");
            return false;
        }
    }

    private Object getInfo() {
        try {
            Class cls = Class.forName(CLASS_NAME_ADVERTISING_ID_CLIENT);
            String str = METHOD_NAME_GET_ADVERTISING_ID_INFO;
            Class[] clsArr = new Class[1];
            Class[] clsArr2 = clsArr;
            clsArr[0] = Context.class;
            Method method = cls.getMethod(str, clsArr2);
            Object[] objArr = new Object[1];
            Object[] objArr2 = objArr;
            objArr[0] = this.context;
            return method.invoke(null, objArr2);
        } catch (Exception e) {
            Exception exc = e;
            Fabric.getLogger().mo23842w(Fabric.TAG, "Could not call getAdvertisingIdInfo on com.google.android.gms.ads.identifier.AdvertisingIdClient");
            return null;
        }
    }
}
