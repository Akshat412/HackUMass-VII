package p004io.fabric.sdk.android.services.network;

import android.text.TextUtils;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.TreeMap;

/* renamed from: io.fabric.sdk.android.services.network.UrlUtils */
public final class UrlUtils {
    public static final String UTF8 = "UTF8";

    private UrlUtils() {
    }

    public static TreeMap<String, String> getQueryParams(URI uri, boolean z) {
        return getQueryParams(uri.getRawQuery(), z);
    }

    public static TreeMap<String, String> getQueryParams(String str, boolean z) {
        TreeMap treeMap;
        String paramsString = str;
        boolean decode = z;
        TreeMap treeMap2 = treeMap;
        TreeMap treeMap3 = new TreeMap();
        TreeMap treeMap4 = treeMap2;
        if (paramsString == null) {
            return treeMap4;
        }
        String[] split = paramsString.split("&");
        int length = split.length;
        for (int i = 0; i < length; i++) {
            String[] nameValuePair = split[i].split("=");
            if (nameValuePair.length == 2) {
                if (decode) {
                    Object put = treeMap4.put(urlDecode(nameValuePair[0]), urlDecode(nameValuePair[1]));
                } else {
                    Object put2 = treeMap4.put(nameValuePair[0], nameValuePair[1]);
                }
            } else if (!TextUtils.isEmpty(nameValuePair[0])) {
                if (decode) {
                    Object put3 = treeMap4.put(urlDecode(nameValuePair[0]), "");
                } else {
                    Object put4 = treeMap4.put(nameValuePair[0], "");
                }
            }
        }
        return treeMap4;
    }

    public static String urlEncode(String str) {
        RuntimeException runtimeException;
        String s = str;
        if (s == null) {
            return "";
        }
        try {
            return URLEncoder.encode(s, UTF8);
        } catch (UnsupportedEncodingException e) {
            UnsupportedEncodingException unlikely = e;
            RuntimeException runtimeException2 = runtimeException;
            RuntimeException runtimeException3 = new RuntimeException(unlikely.getMessage(), unlikely);
            throw runtimeException2;
        }
    }

    public static String urlDecode(String str) {
        RuntimeException runtimeException;
        String s = str;
        if (s == null) {
            return "";
        }
        try {
            return URLDecoder.decode(s, UTF8);
        } catch (UnsupportedEncodingException e) {
            UnsupportedEncodingException unlikely = e;
            RuntimeException runtimeException2 = runtimeException;
            RuntimeException runtimeException3 = new RuntimeException(unlikely.getMessage(), unlikely);
            throw runtimeException2;
        }
    }

    public static String percentEncode(String str) {
        StringBuilder sb;
        String s = str;
        if (s == null) {
            return "";
        }
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        StringBuilder sb4 = sb2;
        String encoded = urlEncode(s);
        int encodedLength = encoded.length();
        int i = 0;
        while (i < encodedLength) {
            char c = encoded.charAt(i);
            if (c == '*') {
                StringBuilder append = sb4.append("%2A");
            } else if (c == '+') {
                StringBuilder append2 = sb4.append("%20");
            } else if (c == '%' && i + 2 < encodedLength && encoded.charAt(i + 1) == '7' && encoded.charAt(i + 2) == 'E') {
                StringBuilder append3 = sb4.append('~');
                i += 2;
            } else {
                StringBuilder append4 = sb4.append(c);
            }
            i++;
        }
        return sb4.toString();
    }
}
