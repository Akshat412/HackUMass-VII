package p004io.fabric.sdk.android.services.common;

import android.content.Context;
import android.content.res.Resources.NotFoundException;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import p004io.fabric.sdk.android.services.concurrency.PriorityRunnable;

/* renamed from: io.fabric.sdk.android.services.common.SafeToast */
public class SafeToast extends Toast {
    public SafeToast(Context context) {
        super(context);
    }

    public void show() {
        Handler handler;
        C15001 r6;
        if (Looper.myLooper() == Looper.getMainLooper()) {
            super.show();
            return;
        }
        Handler handler2 = handler;
        Handler handler3 = new Handler(Looper.getMainLooper());
        Handler handler4 = handler2;
        C15001 r3 = r6;
        C15001 r4 = new PriorityRunnable(this) {
            final /* synthetic */ SafeToast this$0;

            {
                this.this$0 = r5;
            }

            public void run() {
                SafeToast.super.show();
            }
        };
        boolean post = handler4.post(r3);
    }

    public static Toast makeText(Context context, CharSequence charSequence, int i) {
        SafeToast safeToast;
        Context context2 = context;
        Toast origToast = Toast.makeText(context2, charSequence, i);
        SafeToast safeToast2 = safeToast;
        SafeToast safeToast3 = new SafeToast(context2);
        SafeToast safeToast4 = safeToast2;
        safeToast4.setView(origToast.getView());
        safeToast4.setDuration(origToast.getDuration());
        return safeToast4;
    }

    public static Toast makeText(Context context, int i, int i2) throws NotFoundException {
        Context context2 = context;
        return makeText(context2, context2.getResources().getText(i), i2);
    }
}
