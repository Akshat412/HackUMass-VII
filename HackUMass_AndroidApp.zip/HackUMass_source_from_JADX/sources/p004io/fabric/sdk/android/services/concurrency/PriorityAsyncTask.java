package p004io.fabric.sdk.android.services.concurrency;

import java.util.Collection;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import p004io.fabric.sdk.android.services.concurrency.AsyncTask.Status;

/* renamed from: io.fabric.sdk.android.services.concurrency.PriorityAsyncTask */
public abstract class PriorityAsyncTask<Params, Progress, Result> extends AsyncTask<Params, Progress, Result> implements Dependency<Task>, PriorityProvider, Task, DelegateProvider {
    private final PriorityTask priorityTask;

    /* renamed from: io.fabric.sdk.android.services.concurrency.PriorityAsyncTask$ProxyExecutor */
    private static class ProxyExecutor<Result> implements Executor {
        private final Executor executor;
        /* access modifiers changed from: private */
        public final PriorityAsyncTask task;

        public ProxyExecutor(Executor executor2, PriorityAsyncTask priorityAsyncTask) {
            PriorityAsyncTask task2 = priorityAsyncTask;
            this.executor = executor2;
            this.task = task2;
        }

        public void execute(Runnable runnable) {
            C15061 r8;
            Runnable command = runnable;
            Executor executor2 = this.executor;
            C15061 r3 = r8;
            C15061 r4 = new PriorityFutureTask<Result>(this, command, null) {
                final /* synthetic */ ProxyExecutor this$0;

                {
                    Runnable runnable = r9;
                    Object obj = r10;
                    this.this$0 = r8;
                }

                public <T extends Dependency<Task> & PriorityProvider & Task> T getDelegate() {
                    return this.this$0.task;
                }
            };
            executor2.execute(r3);
        }
    }

    public PriorityAsyncTask() {
        PriorityTask priorityTask2;
        PriorityTask priorityTask3 = priorityTask2;
        PriorityTask priorityTask4 = new PriorityTask();
        this.priorityTask = priorityTask3;
    }

    public final void executeOnExecutor(ExecutorService executorService, Params... paramsArr) {
        ProxyExecutor proxyExecutor;
        Params[] params = paramsArr;
        ProxyExecutor proxyExecutor2 = proxyExecutor;
        ProxyExecutor proxyExecutor3 = new ProxyExecutor(executorService, this);
        AsyncTask executeOnExecutor = super.executeOnExecutor(proxyExecutor2, params);
    }

    public int compareTo(Object obj) {
        return Priority.compareTo(this, obj);
    }

    public void addDependency(Task task) {
        IllegalStateException illegalStateException;
        Task task2 = task;
        if (getStatus() != Status.PENDING) {
            IllegalStateException illegalStateException2 = illegalStateException;
            IllegalStateException illegalStateException3 = new IllegalStateException("Must not add Dependency after task is running");
            throw illegalStateException2;
        }
        ((Dependency) ((PriorityProvider) getDelegate())).addDependency(task2);
    }

    public Collection<Task> getDependencies() {
        return ((Dependency) ((PriorityProvider) getDelegate())).getDependencies();
    }

    public boolean areDependenciesMet() {
        return ((Dependency) ((PriorityProvider) getDelegate())).areDependenciesMet();
    }

    public Priority getPriority() {
        return ((PriorityProvider) getDelegate()).getPriority();
    }

    public void setFinished(boolean z) {
        boolean finished = z;
        ((Task) ((PriorityProvider) getDelegate())).setFinished(finished);
    }

    public boolean isFinished() {
        return ((Task) ((PriorityProvider) getDelegate())).isFinished();
    }

    public void setError(Throwable th) {
        Throwable throwable = th;
        ((Task) ((PriorityProvider) getDelegate())).setError(throwable);
    }

    public Throwable getError() {
        return ((Task) ((PriorityProvider) getDelegate())).getError();
    }

    public <T extends Dependency<Task> & PriorityProvider & Task> T getDelegate() {
        return this.priorityTask;
    }
}
