package p004io.fabric.sdk.android.services.concurrency.internal;

import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.AbstractQueuedSynchronizer;

/* renamed from: io.fabric.sdk.android.services.concurrency.internal.AbstractFuture */
public abstract class AbstractFuture<V> implements Future<V> {
    private final Sync<V> sync;

    /* renamed from: io.fabric.sdk.android.services.concurrency.internal.AbstractFuture$Sync */
    static final class Sync<V> extends AbstractQueuedSynchronizer {
        static final int CANCELLED = 4;
        static final int COMPLETED = 2;
        static final int COMPLETING = 1;
        static final int INTERRUPTED = 8;
        static final int RUNNING = 0;
        private static final long serialVersionUID = 0;
        private Throwable exception;
        private V value;

        Sync() {
        }

        /* access modifiers changed from: protected */
        public int tryAcquireShared(int i) {
            int i2 = i;
            if (isDone()) {
                return 1;
            }
            return -1;
        }

        /* access modifiers changed from: protected */
        public boolean tryReleaseShared(int i) {
            setState(i);
            return true;
        }

        /* access modifiers changed from: 0000 */
        public V get(long j) throws TimeoutException, CancellationException, ExecutionException, InterruptedException {
            TimeoutException timeoutException;
            if (tryAcquireSharedNanos(-1, j)) {
                return getValue();
            }
            TimeoutException timeoutException2 = timeoutException;
            TimeoutException timeoutException3 = new TimeoutException("Timeout waiting for task.");
            throw timeoutException2;
        }

        /* access modifiers changed from: 0000 */
        public V get() throws CancellationException, ExecutionException, InterruptedException {
            acquireSharedInterruptibly(-1);
            return getValue();
        }

        private V getValue() throws CancellationException, ExecutionException {
            ExecutionException executionException;
            IllegalStateException illegalStateException;
            StringBuilder sb;
            int state = getState();
            switch (state) {
                case 2:
                    if (this.exception == null) {
                        return this.value;
                    }
                    ExecutionException executionException2 = executionException;
                    ExecutionException executionException3 = new ExecutionException(this.exception);
                    throw executionException2;
                case 4:
                case 8:
                    throw AbstractFuture.cancellationExceptionWithCause("Task was cancelled.", this.exception);
                default:
                    IllegalStateException illegalStateException2 = illegalStateException;
                    StringBuilder sb2 = sb;
                    StringBuilder sb3 = new StringBuilder();
                    IllegalStateException illegalStateException3 = new IllegalStateException(sb2.append("Error, synchronizer in invalid state: ").append(state).toString());
                    throw illegalStateException2;
            }
        }

        /* access modifiers changed from: 0000 */
        public boolean isDone() {
            return (getState() & 14) != 0;
        }

        /* access modifiers changed from: 0000 */
        public boolean isCancelled() {
            return (getState() & 12) != 0;
        }

        /* access modifiers changed from: 0000 */
        public boolean wasInterrupted() {
            return getState() == 8;
        }

        /* access modifiers changed from: 0000 */
        public boolean set(V v) {
            return complete(v, null, 2);
        }

        /* access modifiers changed from: 0000 */
        public boolean setException(Throwable th) {
            return complete(null, th, 2);
        }

        /* access modifiers changed from: 0000 */
        public boolean cancel(boolean z) {
            return complete(null, null, z ? 8 : 4);
        }

        /* JADX WARNING: type inference failed for: r2v0 */
        /* JADX WARNING: type inference failed for: r6v6 */
        /* JADX WARNING: type inference failed for: r6v7, types: [java.lang.Throwable] */
        /* JADX WARNING: type inference failed for: r9v0 */
        /* JADX WARNING: type inference failed for: r6v10 */
        /* JADX WARNING: Multi-variable type inference failed */
        /* JADX WARNING: Unknown variable types count: 3 */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private boolean complete(V r11, java.lang.Throwable r12, int r13) {
            /*
                r10 = this;
                r0 = r10
                r1 = r11
                r2 = r12
                r3 = r13
                r5 = r0
                r6 = 0
                r7 = 1
                boolean r5 = r5.compareAndSetState(r6, r7)
                r4 = r5
                r5 = r4
                if (r5 == 0) goto L_0x0033
                r5 = r0
                r6 = r1
                r5.value = r6
                r5 = r0
                r6 = r3
                r7 = 12
                r6 = r6 & 12
                if (r6 == 0) goto L_0x0031
                java.util.concurrent.CancellationException r6 = new java.util.concurrent.CancellationException
                r9 = r6
                r6 = r9
                r7 = r9
                java.lang.String r8 = "Future.cancel() was called."
                r7.<init>(r8)
            L_0x0026:
                r5.exception = r6
                r5 = r0
                r6 = r3
                boolean r5 = r5.releaseShared(r6)
            L_0x002e:
                r5 = r4
                r0 = r5
                return r0
            L_0x0031:
                r6 = r2
                goto L_0x0026
            L_0x0033:
                r5 = r0
                int r5 = r5.getState()
                r6 = 1
                if (r5 != r6) goto L_0x002e
                r5 = r0
                r6 = -1
                r5.acquireShared(r6)
                goto L_0x002e
            */
            throw new UnsupportedOperationException("Method not decompiled: p004io.fabric.sdk.android.services.concurrency.internal.AbstractFuture.Sync.complete(java.lang.Object, java.lang.Throwable, int):boolean");
        }
    }

    protected AbstractFuture() {
        Sync<V> sync2;
        Sync<V> sync3 = sync2;
        Sync<V> sync4 = new Sync<>();
        this.sync = sync3;
    }

    static final CancellationException cancellationExceptionWithCause(String str, Throwable th) {
        CancellationException cancellationException;
        Throwable cause = th;
        CancellationException cancellationException2 = cancellationException;
        CancellationException cancellationException3 = new CancellationException(str);
        CancellationException exception = cancellationException2;
        Throwable initCause = exception.initCause(cause);
        return exception;
    }

    public V get(long j, TimeUnit timeUnit) throws InterruptedException, TimeoutException, ExecutionException {
        return this.sync.get(timeUnit.toNanos(j));
    }

    public V get() throws InterruptedException, ExecutionException {
        return this.sync.get();
    }

    public boolean isDone() {
        return this.sync.isDone();
    }

    public boolean isCancelled() {
        return this.sync.isCancelled();
    }

    public boolean cancel(boolean z) {
        boolean mayInterruptIfRunning = z;
        if (!this.sync.cancel(mayInterruptIfRunning)) {
            return false;
        }
        if (mayInterruptIfRunning) {
            interruptTask();
        }
        return true;
    }

    /* access modifiers changed from: protected */
    public void interruptTask() {
    }

    /* access modifiers changed from: protected */
    public final boolean wasInterrupted() {
        return this.sync.wasInterrupted();
    }

    /* access modifiers changed from: protected */
    public boolean set(V v) {
        return this.sync.set(v);
    }

    /* access modifiers changed from: protected */
    public boolean setException(Throwable th) {
        NullPointerException nullPointerException;
        Throwable throwable = th;
        if (throwable != null) {
            return this.sync.setException(throwable);
        }
        NullPointerException nullPointerException2 = nullPointerException;
        NullPointerException nullPointerException3 = new NullPointerException();
        throw nullPointerException2;
    }
}
