package p004io.fabric.sdk.android.services.common;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.hardware.SensorManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Debug;
import android.os.StatFs;
import android.provider.Settings.Secure;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import com.google.appinventor.components.common.PropertyTypeConstants;
import com.google.appinventor.components.runtime.util.Ev3Constants.Opcode;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.Flushable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import p004io.fabric.sdk.android.Fabric;
import p004io.fabric.sdk.android.Logger;

/* renamed from: io.fabric.sdk.android.services.common.CommonUtils */
public class CommonUtils {
    static final int BYTES_IN_A_GIGABYTE = 1073741824;
    static final int BYTES_IN_A_KILOBYTE = 1024;
    static final int BYTES_IN_A_MEGABYTE = 1048576;
    private static final String CLS_SHARED_PREFERENCES_NAME = "com.crashlytics.prefs";
    static final boolean CLS_TRACE_DEFAULT = false;
    static final String CLS_TRACE_PREFERENCE_NAME = "com.crashlytics.Trace";
    static final String CRASHLYTICS_BUILD_ID = "com.crashlytics.android.build_id";
    public static final int DEVICE_STATE_BETAOS = 8;
    public static final int DEVICE_STATE_COMPROMISEDLIBRARIES = 32;
    public static final int DEVICE_STATE_DEBUGGERATTACHED = 4;
    public static final int DEVICE_STATE_ISSIMULATOR = 1;
    public static final int DEVICE_STATE_JAILBROKEN = 2;
    public static final int DEVICE_STATE_VENDORINTERNAL = 16;
    static final String FABRIC_BUILD_ID = "io.fabric.android.build_id";
    public static final Comparator<File> FILE_MODIFIED_COMPARATOR;
    public static final String GOOGLE_SDK = "google_sdk";
    private static final char[] HEX_VALUES = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
    private static final String LOG_PRIORITY_NAME_ASSERT = "A";
    private static final String LOG_PRIORITY_NAME_DEBUG = "D";
    private static final String LOG_PRIORITY_NAME_ERROR = "E";
    private static final String LOG_PRIORITY_NAME_INFO = "I";
    private static final String LOG_PRIORITY_NAME_UNKNOWN = "?";
    private static final String LOG_PRIORITY_NAME_VERBOSE = "V";
    private static final String LOG_PRIORITY_NAME_WARN = "W";
    public static final String SDK = "sdk";
    public static final String SHA1_INSTANCE = "SHA-1";
    public static final String SHA256_INSTANCE = "SHA-256";
    private static final long UNCALCULATED_TOTAL_RAM = -1;
    static final String UNITY_EDITOR_VERSION = "com.google.firebase.crashlytics.unity_version";
    private static Boolean clsTrace = null;
    private static long totalRamInBytes = -1;

    /* renamed from: io.fabric.sdk.android.services.common.CommonUtils$Architecture */
    enum Architecture {
        ;
        
        private static final Map<String, Architecture> matcher = null;

        static {
            HashMap hashMap;
            HashMap hashMap2 = hashMap;
            HashMap hashMap3 = new HashMap(4);
            matcher = hashMap2;
            Object put = matcher.put("armeabi-v7a", ARMV7);
            Object put2 = matcher.put("armeabi", ARMV6);
            Object put3 = matcher.put("arm64-v8a", ARM64);
            Object put4 = matcher.put("x86", X86_32);
        }

        static Architecture getValue() {
            String arch = Build.CPU_ABI;
            if (TextUtils.isEmpty(arch)) {
                Fabric.getLogger().mo23829d(Fabric.TAG, "Architecture#getValue()::Build.CPU_ABI returned null or empty");
                return UNKNOWN;
            }
            Architecture value = (Architecture) matcher.get(arch.toLowerCase(Locale.US));
            if (value == null) {
                value = UNKNOWN;
            }
            return value;
        }
    }

    public CommonUtils() {
    }

    static {
        C14941 r4;
        C14941 r0 = r4;
        C14941 r1 = new Comparator<File>() {
            public int compare(File file, File file2) {
                return (int) (file.lastModified() - file2.lastModified());
            }
        };
        FILE_MODIFIED_COMPARATOR = r0;
    }

    public static SharedPreferences getSharedPrefs(Context context) {
        return context.getSharedPreferences(CLS_SHARED_PREFERENCES_NAME, 0);
    }

    public static String extractFieldFromSystemFile(File file, String str) {
        StringBuilder sb;
        BufferedReader bufferedReader;
        FileReader fileReader;
        File file2 = file;
        String fieldname = str;
        String toReturn = null;
        if (file2.exists()) {
            try {
                BufferedReader bufferedReader2 = bufferedReader;
                FileReader fileReader2 = fileReader;
                FileReader fileReader3 = new FileReader(file2);
                BufferedReader bufferedReader3 = new BufferedReader(fileReader2, 1024);
                BufferedReader br = bufferedReader2;
                while (true) {
                    String readLine = br.readLine();
                    String line = readLine;
                    if (readLine == null) {
                        break;
                    }
                    String[] pieces = Pattern.compile("\\s*:\\s*").split(line, 2);
                    if (pieces.length > 1 && pieces[0].equals(fieldname)) {
                        toReturn = pieces[1];
                        break;
                    }
                }
                closeOrLog(br, "Failed to close system file reader.");
            } catch (Exception e) {
                Exception e2 = e;
                Logger logger = Fabric.getLogger();
                String str2 = Fabric.TAG;
                StringBuilder sb2 = sb;
                StringBuilder sb3 = new StringBuilder();
                logger.mo23832e(str2, sb2.append("Error parsing ").append(file2).toString(), e2);
                closeOrLog(null, "Failed to close system file reader.");
            } catch (Throwable th) {
                Throwable th2 = th;
                closeOrLog(null, "Failed to close system file reader.");
                throw th2;
            }
        }
        return toReturn;
    }

    public static int getCpuArchitectureInt() {
        return Architecture.getValue().ordinal();
    }

    public static synchronized long getTotalRamInBytes() {
        long bytes;
        File file;
        StringBuilder sb;
        StringBuilder sb2;
        synchronized (CommonUtils.class) {
            if (totalRamInBytes == -1) {
                long bytes2 = 0;
                File file2 = file;
                File file3 = new File("/proc/meminfo");
                String result = extractFieldFromSystemFile(file2, "MemTotal");
                if (!TextUtils.isEmpty(result)) {
                    String result2 = result.toUpperCase(Locale.US);
                    try {
                        if (result2.endsWith("KB")) {
                            bytes2 = convertMemInfoToBytes(result2, "KB", 1024);
                        } else if (result2.endsWith("MB")) {
                            bytes2 = convertMemInfoToBytes(result2, "MB", 1048576);
                        } else if (result2.endsWith("GB")) {
                            bytes2 = convertMemInfoToBytes(result2, "GB", 1073741824);
                        } else {
                            Logger logger = Fabric.getLogger();
                            String str = Fabric.TAG;
                            StringBuilder sb3 = sb2;
                            StringBuilder sb4 = new StringBuilder();
                            logger.mo23829d(str, sb3.append("Unexpected meminfo format while computing RAM: ").append(result2).toString());
                        }
                    } catch (NumberFormatException e) {
                        NumberFormatException e2 = e;
                        Logger logger2 = Fabric.getLogger();
                        String str2 = Fabric.TAG;
                        StringBuilder sb5 = sb;
                        StringBuilder sb6 = new StringBuilder();
                        logger2.mo23832e(str2, sb5.append("Unexpected meminfo format while computing RAM: ").append(result2).toString(), e2);
                    }
                }
                totalRamInBytes = bytes2;
            }
            bytes = totalRamInBytes;
        }
        return bytes;
    }

    static long convertMemInfoToBytes(String str, String str2, int i) {
        return Long.parseLong(str.split(str2)[0].trim()) * ((long) i);
    }

    public static RunningAppProcessInfo getAppProcessInfo(String str, Context context) {
        String packageName = str;
        List runningAppProcesses = ((ActivityManager) context.getSystemService("activity")).getRunningAppProcesses();
        RunningAppProcessInfo procInfo = null;
        if (runningAppProcesses != null) {
            Iterator it = runningAppProcesses.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                RunningAppProcessInfo info = (RunningAppProcessInfo) it.next();
                if (info.processName.equals(packageName)) {
                    procInfo = info;
                    break;
                }
            }
        }
        return procInfo;
    }

    public static String streamToString(InputStream inputStream) throws IOException {
        Scanner scanner;
        Scanner scanner2 = scanner;
        Scanner scanner3 = new Scanner(inputStream);
        Scanner s = scanner2.useDelimiter("\\A");
        return s.hasNext() ? s.next() : "";
    }

    public static String sha1(String str) {
        return hash(str, SHA1_INSTANCE);
    }

    public static String sha256(String str) {
        return hash(str, SHA256_INSTANCE);
    }

    public static String sha1(InputStream inputStream) {
        return hash(inputStream, SHA1_INSTANCE);
    }

    private static String hash(String str, String str2) {
        return hash(str.getBytes(), str2);
    }

    private static String hash(InputStream inputStream, String str) {
        InputStream source = inputStream;
        try {
            MessageDigest digest = MessageDigest.getInstance(str);
            byte[] buffer = new byte[1024];
            while (true) {
                int read = source.read(buffer);
                int length = read;
                if (read == -1) {
                    return hexify(digest.digest());
                }
                digest.update(buffer, 0, length);
            }
        } catch (Exception e) {
            Fabric.getLogger().mo23832e(Fabric.TAG, "Could not calculate hash for app icon.", e);
            return "";
        }
    }

    private static String hash(byte[] bArr, String str) {
        StringBuilder sb;
        String algorithm = str;
        try {
            MessageDigest digest = MessageDigest.getInstance(algorithm);
            digest.update(bArr);
            return hexify(digest.digest());
        } catch (NoSuchAlgorithmException e) {
            NoSuchAlgorithmException e2 = e;
            Logger logger = Fabric.getLogger();
            String str2 = Fabric.TAG;
            StringBuilder sb2 = sb;
            StringBuilder sb3 = new StringBuilder();
            logger.mo23832e(str2, sb2.append("Could not create hashing algorithm: ").append(algorithm).append(", returning empty string.").toString(), e2);
            return "";
        }
    }

    public static String createInstanceIdFrom(String... strArr) {
        ArrayList arrayList;
        StringBuilder sb;
        String[] sliceIds = strArr;
        if (sliceIds == null || sliceIds.length == 0) {
            return null;
        }
        ArrayList arrayList2 = arrayList;
        ArrayList arrayList3 = new ArrayList();
        ArrayList<String> arrayList4 = arrayList2;
        String[] strArr2 = sliceIds;
        int length = strArr2.length;
        for (int i = 0; i < length; i++) {
            String id = strArr2[i];
            if (id != null) {
                boolean add = arrayList4.add(id.replace("-", "").toLowerCase(Locale.US));
            }
        }
        Collections.sort(arrayList4);
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        StringBuilder sb4 = sb2;
        for (String id2 : arrayList4) {
            StringBuilder append = sb4.append(id2);
        }
        String concatValue = sb4.toString();
        return concatValue.length() > 0 ? sha1(concatValue) : null;
    }

    public static long calculateFreeRamInBytes(Context context) {
        MemoryInfo memoryInfo;
        Context context2 = context;
        MemoryInfo memoryInfo2 = memoryInfo;
        MemoryInfo memoryInfo3 = new MemoryInfo();
        MemoryInfo mi = memoryInfo2;
        ((ActivityManager) context2.getSystemService("activity")).getMemoryInfo(mi);
        return mi.availMem;
    }

    public static long calculateUsedDiskSpaceInBytes(String str) {
        StatFs statFs;
        StatFs statFs2 = statFs;
        StatFs statFs3 = new StatFs(str);
        StatFs statFs4 = statFs2;
        long blockSizeBytes = (long) statFs4.getBlockSize();
        return (blockSizeBytes * ((long) statFs4.getBlockCount())) - (blockSizeBytes * ((long) statFs4.getAvailableBlocks()));
    }

    public static Float getBatteryLevel(Context context) {
        IntentFilter intentFilter;
        Context context2 = context;
        IntentFilter intentFilter2 = intentFilter;
        IntentFilter intentFilter3 = new IntentFilter("android.intent.action.BATTERY_CHANGED");
        Intent battery = context2.registerReceiver(null, intentFilter2);
        if (battery == null) {
            return null;
        }
        return Float.valueOf(((float) battery.getIntExtra("level", -1)) / ((float) battery.getIntExtra("scale", -1)));
    }

    public static boolean getProximitySensorEnabled(Context context) {
        Context context2 = context;
        if (isEmulator(context2)) {
            return false;
        }
        return ((SensorManager) context2.getSystemService("sensor")).getDefaultSensor(8) != null;
    }

    public static void logControlled(Context context, String str) {
        String msg = str;
        if (isClsTrace(context)) {
            Fabric.getLogger().mo23829d(Fabric.TAG, msg);
        }
    }

    public static void logControlledError(Context context, String str, Throwable th) {
        String msg = str;
        Throwable th2 = th;
        if (isClsTrace(context)) {
            Fabric.getLogger().mo23831e(Fabric.TAG, msg);
        }
    }

    public static void logControlled(Context context, int i, String str, String str2) {
        int level = i;
        String str3 = str;
        String msg = str2;
        if (isClsTrace(context)) {
            Fabric.getLogger().log(level, Fabric.TAG, msg);
        }
    }

    @Deprecated
    public static boolean isLoggingEnabled(Context context) {
        Context context2 = context;
        return false;
    }

    public static boolean isClsTrace(Context context) {
        Context context2 = context;
        if (clsTrace == null) {
            clsTrace = Boolean.valueOf(getBooleanResourceValue(context2, CLS_TRACE_PREFERENCE_NAME, false));
        }
        return clsTrace.booleanValue();
    }

    public static boolean getBooleanResourceValue(Context context, String str, boolean z) {
        Context context2 = context;
        String key = str;
        boolean defaultValue = z;
        if (context2 != null) {
            Resources resources = context2.getResources();
            if (resources != null) {
                int id = getResourcesIdentifier(context2, key, "bool");
                if (id > 0) {
                    return resources.getBoolean(id);
                }
                int id2 = getResourcesIdentifier(context2, key, PropertyTypeConstants.PROPERTY_TYPE_STRING);
                if (id2 > 0) {
                    return Boolean.parseBoolean(context2.getString(id2));
                }
            }
        }
        return defaultValue;
    }

    public static int getResourcesIdentifier(Context context, String str, String str2) {
        Context context2 = context;
        return context2.getResources().getIdentifier(str, str2, getResourcePackageName(context2));
    }

    public static boolean isEmulator(Context context) {
        return SDK.equals(Build.PRODUCT) || GOOGLE_SDK.equals(Build.PRODUCT) || Secure.getString(context.getContentResolver(), "android_id") == null;
    }

    public static boolean isRooted(Context context) {
        File file;
        File file2;
        boolean isEmulator = isEmulator(context);
        String buildTags = Build.TAGS;
        if (!isEmulator && buildTags != null && buildTags.contains("test-keys")) {
            return true;
        }
        File file3 = file;
        File file4 = new File("/system/app/Superuser.apk");
        if (file3.exists()) {
            return true;
        }
        File file5 = file2;
        File file6 = new File("/system/xbin/su");
        File file7 = file5;
        if (isEmulator || !file7.exists()) {
            return false;
        }
        return true;
    }

    public static boolean isDebuggerAttached() {
        return Debug.isDebuggerConnected() || Debug.waitingForDebugger();
    }

    public static int getDeviceState(Context context) {
        Context context2 = context;
        int deviceState = 0;
        if (isEmulator(context2)) {
            deviceState = 0 | 1;
        }
        if (isRooted(context2)) {
            deviceState |= 2;
        }
        if (isDebuggerAttached()) {
            deviceState |= 4;
        }
        return deviceState;
    }

    public static int getBatteryVelocity(Context context, boolean z) {
        boolean powerConnected = z;
        Float batteryLevel = getBatteryLevel(context);
        if (!powerConnected || batteryLevel == null) {
            return 1;
        }
        if (((double) batteryLevel.floatValue()) >= 99.0d) {
            return 3;
        }
        if (((double) batteryLevel.floatValue()) < 99.0d) {
            return 2;
        }
        return 0;
    }

    @Deprecated
    public static Cipher createCipher(int i, String str) throws InvalidKeyException {
        InvalidKeyException invalidKeyException;
        int i2 = i;
        String str2 = str;
        InvalidKeyException invalidKeyException2 = invalidKeyException;
        InvalidKeyException invalidKeyException3 = new InvalidKeyException("This method is deprecated");
        throw invalidKeyException2;
    }

    public static String hexify(byte[] bArr) {
        String str;
        byte[] bytes = bArr;
        char[] hexChars = new char[(bytes.length * 2)];
        for (int i = 0; i < bytes.length; i++) {
            byte b = bytes[i] & Opcode.TST;
            hexChars[i * 2] = HEX_VALUES[b >>> 4];
            hexChars[(i * 2) + 1] = HEX_VALUES[b & 15];
        }
        String str2 = str;
        String str3 = new String(hexChars);
        return str2;
    }

    public static byte[] dehexify(String str) {
        String string = str;
        int len = string.length();
        byte[] data = new byte[(len / 2)];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(string.charAt(i), 16) << 4) + Character.digit(string.charAt(i + 1), 16));
        }
        return data;
    }

    public static boolean isAppDebuggable(Context context) {
        return (context.getApplicationInfo().flags & 2) != 0;
    }

    public static String getStringsFileValue(Context context, String str) {
        Context context2 = context;
        int id = getResourcesIdentifier(context2, str, PropertyTypeConstants.PROPERTY_TYPE_STRING);
        if (id > 0) {
            return context2.getString(id);
        }
        return "";
    }

    public static void closeOrLog(Closeable closeable, String str) {
        Closeable c = closeable;
        String message = str;
        if (c != null) {
            try {
                c.close();
            } catch (IOException e) {
                Fabric.getLogger().mo23832e(Fabric.TAG, message, e);
            }
        }
    }

    public static void flushOrLog(Flushable flushable, String str) {
        Flushable f = flushable;
        String message = str;
        if (f != null) {
            try {
                f.flush();
            } catch (IOException e) {
                Fabric.getLogger().mo23832e(Fabric.TAG, message, e);
            }
        }
    }

    public static boolean isNullOrEmpty(String str) {
        String s = str;
        return s == null || s.length() == 0;
    }

    public static String padWithZerosToMaxIntWidth(int i) {
        IllegalArgumentException illegalArgumentException;
        int value = i;
        if (value < 0) {
            IllegalArgumentException illegalArgumentException2 = illegalArgumentException;
            IllegalArgumentException illegalArgumentException3 = new IllegalArgumentException("value must be zero or greater");
            throw illegalArgumentException2;
        }
        Object[] objArr = new Object[1];
        Object[] objArr2 = objArr;
        objArr[0] = Integer.valueOf(value);
        return String.format(Locale.US, "%1$10s", objArr2).replace(' ', '0');
    }

    public static boolean stringsEqualIncludingNull(String str, String str2) {
        String s1 = str;
        String s2 = str2;
        if (s1 == s2) {
            return true;
        }
        if (s1 != null) {
            return s1.equals(s2);
        }
        return false;
    }

    public static String getResourcePackageName(Context context) {
        String resourcePackageName;
        Context context2 = context;
        int iconId = context2.getApplicationContext().getApplicationInfo().icon;
        if (iconId > 0) {
            try {
                resourcePackageName = context2.getResources().getResourcePackageName(iconId);
            } catch (NotFoundException e) {
                NotFoundException notFoundException = e;
                resourcePackageName = context2.getPackageName();
            }
        } else {
            resourcePackageName = context2.getPackageName();
        }
        return resourcePackageName;
    }

    public static void copyStream(InputStream inputStream, OutputStream outputStream, byte[] bArr) throws IOException {
        InputStream is = inputStream;
        OutputStream os = outputStream;
        byte[] buffer = bArr;
        while (true) {
            int read = is.read(buffer);
            int count = read;
            if (read != -1) {
                os.write(buffer, 0, count);
            } else {
                return;
            }
        }
    }

    public static String logPriorityToString(int i) {
        switch (i) {
            case 2:
                return LOG_PRIORITY_NAME_VERBOSE;
            case 3:
                return LOG_PRIORITY_NAME_DEBUG;
            case 4:
                return LOG_PRIORITY_NAME_INFO;
            case 5:
                return LOG_PRIORITY_NAME_WARN;
            case 6:
                return LOG_PRIORITY_NAME_ERROR;
            case 7:
                return LOG_PRIORITY_NAME_ASSERT;
            default:
                return LOG_PRIORITY_NAME_UNKNOWN;
        }
    }

    public static String getAppIconHashOrNull(Context context) {
        StringBuilder sb;
        Context context2 = context;
        InputStream is = null;
        try {
            is = context2.getResources().openRawResource(getAppIconResourceId(context2));
            String sha1 = sha1(is);
            String str = isNullOrEmpty(sha1) ? null : sha1;
            closeOrLog(is, "Failed to close icon input stream.");
            return str;
        } catch (Exception e) {
            Exception e2 = e;
            Logger logger = Fabric.getLogger();
            String str2 = Fabric.TAG;
            StringBuilder sb2 = sb;
            StringBuilder sb3 = new StringBuilder();
            logger.mo23842w(str2, sb2.append("Could not calculate hash for app icon:").append(e2.getMessage()).toString());
            closeOrLog(is, "Failed to close icon input stream.");
            return null;
        } catch (Throwable th) {
            Throwable th2 = th;
            closeOrLog(is, "Failed to close icon input stream.");
            throw th2;
        }
    }

    public static int getAppIconResourceId(Context context) {
        return context.getApplicationContext().getApplicationInfo().icon;
    }

    public static String resolveBuildId(Context context) {
        StringBuilder sb;
        Context context2 = context;
        String buildId = null;
        int id = getResourcesIdentifier(context2, FABRIC_BUILD_ID, PropertyTypeConstants.PROPERTY_TYPE_STRING);
        if (id == 0) {
            id = getResourcesIdentifier(context2, CRASHLYTICS_BUILD_ID, PropertyTypeConstants.PROPERTY_TYPE_STRING);
        }
        if (id != 0) {
            buildId = context2.getResources().getString(id);
            Logger logger = Fabric.getLogger();
            String str = Fabric.TAG;
            StringBuilder sb2 = sb;
            StringBuilder sb3 = new StringBuilder();
            logger.mo23829d(str, sb2.append("Build ID is: ").append(buildId).toString());
        }
        return buildId;
    }

    public static String resolveUnityEditorVersion(Context context) {
        StringBuilder sb;
        Context context2 = context;
        String version = null;
        int id = getResourcesIdentifier(context2, UNITY_EDITOR_VERSION, PropertyTypeConstants.PROPERTY_TYPE_STRING);
        if (id != 0) {
            version = context2.getResources().getString(id);
            Logger logger = Fabric.getLogger();
            String str = Fabric.TAG;
            StringBuilder sb2 = sb;
            StringBuilder sb3 = new StringBuilder();
            logger.mo23829d(str, sb2.append("Unity Editor version is: ").append(version).toString());
        }
        return version;
    }

    public static void closeQuietly(Closeable closeable) {
        Closeable closeable2 = closeable;
        if (closeable2 != null) {
            try {
                closeable2.close();
            } catch (RuntimeException e) {
                throw e;
            } catch (Exception e2) {
                Exception exc = e2;
            }
        }
    }

    public static boolean checkPermission(Context context, String str) {
        return context.checkCallingOrSelfPermission(str) == 0;
    }

    public static void hideKeyboard(Context context, View view) {
        View view2 = view;
        InputMethodManager imm = (InputMethodManager) context.getSystemService("input_method");
        if (imm != null) {
            boolean hideSoftInputFromWindow = imm.hideSoftInputFromWindow(view2.getWindowToken(), 0);
        }
    }

    public static void openKeyboard(Context context, View view) {
        View view2 = view;
        InputMethodManager imm = (InputMethodManager) context.getSystemService("input_method");
        if (imm != null) {
            imm.showSoftInputFromInputMethod(view2.getWindowToken(), 0);
        }
    }

    @TargetApi(16)
    public static void finishAffinity(Context context, int i) {
        Context context2 = context;
        int resultCode = i;
        if (context2 instanceof Activity) {
            finishAffinity((Activity) context2, resultCode);
        }
    }

    @TargetApi(16)
    public static void finishAffinity(Activity activity, int i) {
        Activity activity2 = activity;
        int resultCode = i;
        if (activity2 != null) {
            if (VERSION.SDK_INT >= 16) {
                activity2.finishAffinity();
                return;
            }
            activity2.setResult(resultCode);
            activity2.finish();
        }
    }

    @SuppressLint({"MissingPermission"})
    public static boolean canTryConnection(Context context) {
        Context context2 = context;
        if (!checkPermission(context2, "android.permission.ACCESS_NETWORK_STATE")) {
            return true;
        }
        NetworkInfo activeNetwork = ((ConnectivityManager) context2.getSystemService("connectivity")).getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isConnectedOrConnecting();
    }

    public static void logOrThrowIllegalStateException(String str, String str2) {
        IllegalStateException illegalStateException;
        String logTag = str;
        String errorMsg = str2;
        if (Fabric.isDebuggable()) {
            IllegalStateException illegalStateException2 = illegalStateException;
            IllegalStateException illegalStateException3 = new IllegalStateException(errorMsg);
            throw illegalStateException2;
        }
        Fabric.getLogger().mo23842w(logTag, errorMsg);
    }

    public static void logOrThrowIllegalArgumentException(String str, String str2) {
        IllegalArgumentException illegalArgumentException;
        String logTag = str;
        String errorMsg = str2;
        if (Fabric.isDebuggable()) {
            IllegalArgumentException illegalArgumentException2 = illegalArgumentException;
            IllegalArgumentException illegalArgumentException3 = new IllegalArgumentException(errorMsg);
            throw illegalArgumentException2;
        }
        Fabric.getLogger().mo23842w(logTag, errorMsg);
    }
}
