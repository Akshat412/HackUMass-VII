package p004io.fabric.sdk.android.services.common;

/* renamed from: io.fabric.sdk.android.services.common.AdvertisingInfo */
class AdvertisingInfo {
    public final String advertisingId;
    public final boolean limitAdTrackingEnabled;

    AdvertisingInfo(String str, boolean z) {
        boolean limitAdTrackingEnabled2 = z;
        this.advertisingId = str;
        this.limitAdTrackingEnabled = limitAdTrackingEnabled2;
    }

    public boolean equals(Object obj) {
        Object o = obj;
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        AdvertisingInfo infoToCompare = (AdvertisingInfo) o;
        if (this.limitAdTrackingEnabled != infoToCompare.limitAdTrackingEnabled) {
            return false;
        }
        if (this.advertisingId == null ? infoToCompare.advertisingId != null : !this.advertisingId.equals(infoToCompare.advertisingId)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return (31 * (this.advertisingId != null ? this.advertisingId.hashCode() : 0)) + (this.limitAdTrackingEnabled ? 1 : 0);
    }
}
