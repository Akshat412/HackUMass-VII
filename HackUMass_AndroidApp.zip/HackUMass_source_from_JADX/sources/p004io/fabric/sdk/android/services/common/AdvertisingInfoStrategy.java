package p004io.fabric.sdk.android.services.common;

/* renamed from: io.fabric.sdk.android.services.common.AdvertisingInfoStrategy */
public interface AdvertisingInfoStrategy {
    AdvertisingInfo getAdvertisingInfo();
}
