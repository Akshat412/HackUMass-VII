package p004io.fabric.sdk.android.services.network;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;

/* renamed from: io.fabric.sdk.android.services.network.NetworkUtils */
public final class NetworkUtils {
    private NetworkUtils() {
    }

    public static final SSLSocketFactory getSSLSocketFactory(PinningInfoProvider pinningInfoProvider) throws KeyManagementException, NoSuchAlgorithmException {
        SystemKeyStore systemKeyStore;
        PinningTrustManager pinningTrustManager;
        PinningInfoProvider provider = pinningInfoProvider;
        SSLContext sslContext = SSLContext.getInstance(org.shaded.apache.http.conn.ssl.SSLSocketFactory.TLS);
        SystemKeyStore systemKeyStore2 = systemKeyStore;
        SystemKeyStore systemKeyStore3 = new SystemKeyStore(provider.getKeyStoreStream(), provider.getKeyStorePassword());
        SystemKeyStore keystore = systemKeyStore2;
        PinningTrustManager pinningTrustManager2 = pinningTrustManager;
        PinningTrustManager pinningTrustManager3 = new PinningTrustManager(keystore, provider);
        PinningTrustManager pinningTrustManager4 = pinningTrustManager2;
        SSLContext sSLContext = sslContext;
        TrustManager[] trustManagerArr = new TrustManager[1];
        TrustManager[] trustManagerArr2 = trustManagerArr;
        trustManagerArr[0] = pinningTrustManager4;
        sSLContext.init(null, trustManagerArr2, null);
        return sslContext.getSocketFactory();
    }
}
