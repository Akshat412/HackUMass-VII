package p004io.fabric.sdk.android.services.common;

/* renamed from: io.fabric.sdk.android.services.common.CurrentTimeProvider */
public interface CurrentTimeProvider {
    long getCurrentTimeMillis();
}
