package p004io.fabric.sdk.android.services.common;

import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import p004io.fabric.sdk.android.Fabric;
import p004io.fabric.sdk.android.Logger;
import p004io.fabric.sdk.android.services.concurrency.internal.Backoff;
import p004io.fabric.sdk.android.services.concurrency.internal.RetryPolicy;
import p004io.fabric.sdk.android.services.concurrency.internal.RetryThreadPoolExecutor;

/* renamed from: io.fabric.sdk.android.services.common.ExecutorUtils */
public final class ExecutorUtils {
    private static final long DEFAULT_TERMINATION_TIMEOUT = 2;

    private ExecutorUtils() {
    }

    public static ExecutorService buildSingleThreadExecutorService(String str) {
        String name = str;
        ExecutorService executor = Executors.newSingleThreadExecutor(getNamedThreadFactory(name));
        addDelayedShutdownHook(name, executor);
        return executor;
    }

    public static RetryThreadPoolExecutor buildRetryThreadPoolExecutor(String str, int i, RetryPolicy retryPolicy, Backoff backoff) {
        RetryThreadPoolExecutor retryThreadPoolExecutor;
        String name = str;
        RetryPolicy retryPolicy2 = retryPolicy;
        Backoff backoff2 = backoff;
        RetryThreadPoolExecutor retryThreadPoolExecutor2 = retryThreadPoolExecutor;
        RetryThreadPoolExecutor retryThreadPoolExecutor3 = new RetryThreadPoolExecutor(i, getNamedThreadFactory(name), retryPolicy2, backoff2);
        RetryThreadPoolExecutor executor = retryThreadPoolExecutor2;
        addDelayedShutdownHook(name, executor);
        return executor;
    }

    public static ScheduledExecutorService buildSingleThreadScheduledExecutorService(String str) {
        String name = str;
        ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor(getNamedThreadFactory(name));
        addDelayedShutdownHook(name, executor);
        return executor;
    }

    public static final ThreadFactory getNamedThreadFactory(String str) {
        AtomicLong atomicLong;
        C14951 r6;
        String threadNameTemplate = str;
        AtomicLong atomicLong2 = atomicLong;
        AtomicLong atomicLong3 = new AtomicLong(1);
        AtomicLong count = atomicLong2;
        C14951 r2 = r6;
        final String str2 = threadNameTemplate;
        final AtomicLong atomicLong4 = count;
        C14951 r3 = new ThreadFactory() {
            {
                AtomicLong atomicLong = r7;
            }

            public Thread newThread(Runnable runnable) {
                C14961 r9;
                StringBuilder sb;
                Runnable runnable2 = runnable;
                ThreadFactory defaultThreadFactory = Executors.defaultThreadFactory();
                C14961 r5 = r9;
                final Runnable runnable3 = runnable2;
                C14961 r6 = new BackgroundPriorityRunnable(this) {
                    final /* synthetic */ C14951 this$0;

                    {
                        Runnable runnable = r7;
                        this.this$0 = r6;
                    }

                    public void onRun() {
                        runnable3.run();
                    }
                };
                Thread thread = defaultThreadFactory.newThread(r5);
                Thread thread2 = thread;
                StringBuilder sb2 = sb;
                StringBuilder sb3 = new StringBuilder();
                thread2.setName(sb2.append(str2).append(atomicLong4.getAndIncrement()).toString());
                return thread;
            }
        };
        return r2;
    }

    private static final void addDelayedShutdownHook(String str, ExecutorService executorService) {
        addDelayedShutdownHook(str, executorService, 2, TimeUnit.SECONDS);
    }

    public static final void addDelayedShutdownHook(String str, ExecutorService executorService, long j, TimeUnit timeUnit) {
        Thread thread;
        C14972 r15;
        StringBuilder sb;
        String serviceName = str;
        ExecutorService service = executorService;
        long terminationTimeout = j;
        TimeUnit timeUnit2 = timeUnit;
        Runtime runtime = Runtime.getRuntime();
        Thread thread2 = thread;
        C14972 r8 = r15;
        final String str2 = serviceName;
        final ExecutorService executorService2 = service;
        final long j2 = terminationTimeout;
        final TimeUnit timeUnit3 = timeUnit2;
        C14972 r9 = new BackgroundPriorityRunnable() {
            {
                ExecutorService executorService = r13;
                long j = r14;
                TimeUnit timeUnit = r16;
            }

            public void onRun() {
                StringBuilder sb;
                StringBuilder sb2;
                try {
                    Logger logger = Fabric.getLogger();
                    String str = Fabric.TAG;
                    StringBuilder sb3 = sb;
                    StringBuilder sb4 = new StringBuilder();
                    logger.mo23829d(str, sb3.append("Executing shutdown hook for ").append(str2).toString());
                    executorService2.shutdown();
                    if (!executorService2.awaitTermination(j2, timeUnit3)) {
                        Logger logger2 = Fabric.getLogger();
                        String str2 = Fabric.TAG;
                        StringBuilder sb5 = sb2;
                        StringBuilder sb6 = new StringBuilder();
                        logger2.mo23829d(str2, sb5.append(str2).append(" did not shut down in the allocated time. Requesting immediate shutdown.").toString());
                        List shutdownNow = executorService2.shutdownNow();
                    }
                } catch (InterruptedException e) {
                    InterruptedException interruptedException = e;
                    Logger logger3 = Fabric.getLogger();
                    String str3 = Fabric.TAG;
                    Object[] objArr = new Object[1];
                    Object[] objArr2 = objArr;
                    objArr[0] = str2;
                    logger3.mo23829d(str3, String.format(Locale.US, "Interrupted while waiting for %s to shut down. Requesting immediate shutdown.", objArr2));
                    List shutdownNow2 = executorService2.shutdownNow();
                }
            }
        };
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        Thread thread3 = new Thread(r8, sb2.append("Crashlytics Shutdown Hook for ").append(serviceName).toString());
        runtime.addShutdownHook(thread2);
    }
}
