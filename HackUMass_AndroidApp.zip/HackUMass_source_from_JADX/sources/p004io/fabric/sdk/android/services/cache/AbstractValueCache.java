package p004io.fabric.sdk.android.services.cache;

import android.content.Context;

/* renamed from: io.fabric.sdk.android.services.cache.AbstractValueCache */
public abstract class AbstractValueCache<T> implements ValueCache<T> {
    private final ValueCache<T> childCache;

    /* access modifiers changed from: protected */
    public abstract void cacheValue(Context context, T t);

    /* access modifiers changed from: protected */
    public abstract void doInvalidate(Context context);

    /* access modifiers changed from: protected */
    public abstract T getCached(Context context);

    public AbstractValueCache() {
        this(null);
    }

    public AbstractValueCache(ValueCache<T> valueCache) {
        this.childCache = valueCache;
    }

    public final synchronized T get(Context context, ValueLoader<T> valueLoader) throws Exception {
        Object obj;
        Context context2 = context;
        ValueLoader<T> loader = valueLoader;
        synchronized (this) {
            Object cached = getCached(context2);
            if (cached == null) {
                cached = this.childCache != null ? this.childCache.get(context2, loader) : loader.load(context2);
                cache(context2, cached);
            }
            obj = cached;
        }
        return obj;
    }

    public final synchronized void invalidate(Context context) {
        Context context2 = context;
        synchronized (this) {
            doInvalidate(context2);
        }
    }

    private void cache(Context context, T t) {
        NullPointerException nullPointerException;
        Context context2 = context;
        T value = t;
        if (value == null) {
            NullPointerException nullPointerException2 = nullPointerException;
            NullPointerException nullPointerException3 = new NullPointerException();
            throw nullPointerException2;
        }
        cacheValue(context2, value);
    }
}
