package p004io.fabric.sdk.android.services.common;

/* renamed from: io.fabric.sdk.android.services.common.FirebaseApp */
interface FirebaseApp {
    boolean isDataCollectionDefaultEnabled();
}
