package p004io.fabric.sdk.android.services.network;

import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;
import p004io.fabric.sdk.android.DefaultLogger;
import p004io.fabric.sdk.android.Fabric;
import p004io.fabric.sdk.android.Logger;

/* renamed from: io.fabric.sdk.android.services.network.DefaultHttpRequestFactory */
public class DefaultHttpRequestFactory implements HttpRequestFactory {
    private static final String HTTPS = "https";
    private boolean attemptedSslInit;
    private final Logger logger;
    private PinningInfoProvider pinningInfo;
    private SSLSocketFactory sslSocketFactory;

    public DefaultHttpRequestFactory() {
        DefaultLogger defaultLogger;
        DefaultLogger defaultLogger2 = defaultLogger;
        DefaultLogger defaultLogger3 = new DefaultLogger();
        this(defaultLogger2);
    }

    public DefaultHttpRequestFactory(Logger logger2) {
        this.logger = logger2;
    }

    public PinningInfoProvider getPinningInfoProvider() {
        return this.pinningInfo;
    }

    public void setPinningInfoProvider(PinningInfoProvider pinningInfoProvider) {
        PinningInfoProvider pinningInfo2 = pinningInfoProvider;
        if (this.pinningInfo != pinningInfo2) {
            this.pinningInfo = pinningInfo2;
            resetSSLSocketFactory();
        }
    }

    private synchronized void resetSSLSocketFactory() {
        synchronized (this) {
            this.attemptedSslInit = false;
            this.sslSocketFactory = null;
        }
    }

    public HttpRequest buildHttpRequest(HttpMethod httpMethod, String str) {
        return buildHttpRequest(httpMethod, str, Collections.emptyMap());
    }

    public HttpRequest buildHttpRequest(HttpMethod httpMethod, String str, Map<String, String> map) {
        HttpRequest httpRequest;
        IllegalArgumentException illegalArgumentException;
        String url = str;
        Map<String, String> queryParams = map;
        switch (httpMethod) {
            case GET:
                httpRequest = HttpRequest.get((CharSequence) url, queryParams, true);
                break;
            case POST:
                httpRequest = HttpRequest.post((CharSequence) url, queryParams, true);
                break;
            case PUT:
                httpRequest = HttpRequest.put((CharSequence) url);
                break;
            case DELETE:
                httpRequest = HttpRequest.delete((CharSequence) url);
                break;
            default:
                IllegalArgumentException illegalArgumentException2 = illegalArgumentException;
                IllegalArgumentException illegalArgumentException3 = new IllegalArgumentException("Unsupported HTTP method!");
                throw illegalArgumentException2;
        }
        if (isHttps(url) && this.pinningInfo != null) {
            SSLSocketFactory sslSocketFactory2 = getSSLSocketFactory();
            if (sslSocketFactory2 != null) {
                ((HttpsURLConnection) httpRequest.getConnection()).setSSLSocketFactory(sslSocketFactory2);
            }
        }
        return httpRequest;
    }

    private boolean isHttps(String str) {
        String url = str;
        return url != null && url.toLowerCase(Locale.US).startsWith(HTTPS);
    }

    private synchronized SSLSocketFactory getSSLSocketFactory() {
        SSLSocketFactory sSLSocketFactory;
        synchronized (this) {
            if (this.sslSocketFactory == null && !this.attemptedSslInit) {
                this.sslSocketFactory = initSSLSocketFactory();
            }
            sSLSocketFactory = this.sslSocketFactory;
        }
        return sSLSocketFactory;
    }

    private synchronized SSLSocketFactory initSSLSocketFactory() {
        SSLSocketFactory sSLSocketFactory;
        synchronized (this) {
            this.attemptedSslInit = true;
            try {
                SSLSocketFactory sslSocketFactory2 = NetworkUtils.getSSLSocketFactory(this.pinningInfo);
                this.logger.mo23829d(Fabric.TAG, "Custom SSL pinning enabled");
                sSLSocketFactory = sslSocketFactory2;
            } catch (Exception e) {
                this.logger.mo23832e(Fabric.TAG, "Exception while validating pinned certs", e);
                sSLSocketFactory = null;
            }
        }
        return sSLSocketFactory;
    }
}
