package p004io.fabric.sdk.android.services.concurrency.internal;

import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;

/* renamed from: io.fabric.sdk.android.services.concurrency.internal.RetryThreadPoolExecutor */
public class RetryThreadPoolExecutor extends ScheduledThreadPoolExecutor {
    private final Backoff backoff;
    private final RetryPolicy retryPolicy;

    public RetryThreadPoolExecutor(int i, RetryPolicy retryPolicy2, Backoff backoff2) {
        this(i, Executors.defaultThreadFactory(), retryPolicy2, backoff2);
    }

    public RetryThreadPoolExecutor(int i, ThreadFactory threadFactory, RetryPolicy retryPolicy2, Backoff backoff2) {
        NullPointerException nullPointerException;
        NullPointerException nullPointerException2;
        RetryPolicy retryPolicy3 = retryPolicy2;
        Backoff backoff3 = backoff2;
        super(i, threadFactory);
        if (retryPolicy3 == null) {
            NullPointerException nullPointerException3 = nullPointerException2;
            NullPointerException nullPointerException4 = new NullPointerException("retry policy must not be null");
            throw nullPointerException3;
        } else if (backoff3 == null) {
            NullPointerException nullPointerException5 = nullPointerException;
            NullPointerException nullPointerException6 = new NullPointerException("backoff must not be null");
            throw nullPointerException5;
        } else {
            this.retryPolicy = retryPolicy3;
            this.backoff = backoff3;
        }
    }

    public Future<?> scheduleWithRetry(Runnable runnable) {
        return scheduleWithRetryInternal(Executors.callable(runnable));
    }

    public <T> Future<T> scheduleWithRetry(Runnable runnable, T t) {
        return scheduleWithRetryInternal(Executors.callable(runnable, t));
    }

    public <T> Future<T> scheduleWithRetry(Callable<T> callable) {
        return scheduleWithRetryInternal(callable);
    }

    private <T> Future<T> scheduleWithRetryInternal(Callable<T> callable) {
        RetryState retryState;
        RetryFuture retryFuture;
        NullPointerException nullPointerException;
        Callable<T> task = callable;
        if (task == null) {
            NullPointerException nullPointerException2 = nullPointerException;
            NullPointerException nullPointerException3 = new NullPointerException();
            throw nullPointerException2;
        }
        RetryState retryState2 = retryState;
        RetryState retryState3 = new RetryState(this.backoff, this.retryPolicy);
        RetryState retryState4 = retryState2;
        RetryFuture retryFuture2 = retryFuture;
        RetryFuture retryFuture3 = new RetryFuture(task, retryState4, this);
        RetryFuture retryFuture4 = retryFuture2;
        execute(retryFuture4);
        return retryFuture4;
    }

    public RetryPolicy getRetryPolicy() {
        return this.retryPolicy;
    }

    public Backoff getBackoff() {
        return this.backoff;
    }
}
