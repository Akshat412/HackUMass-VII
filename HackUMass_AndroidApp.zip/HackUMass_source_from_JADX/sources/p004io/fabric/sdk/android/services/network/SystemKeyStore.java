package p004io.fabric.sdk.android.services.network;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.Principal;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Enumeration;
import java.util.HashMap;

/* renamed from: io.fabric.sdk.android.services.network.SystemKeyStore */
class SystemKeyStore {
    private final HashMap<Principal, X509Certificate> trustRoots;
    final KeyStore trustStore;

    public SystemKeyStore(InputStream inputStream, String str) {
        KeyStore trustStore2 = getTrustStore(inputStream, str);
        this.trustRoots = initializeTrustedRoots(trustStore2);
        this.trustStore = trustStore2;
    }

    public boolean isTrustRoot(X509Certificate x509Certificate) {
        X509Certificate certificate = x509Certificate;
        X509Certificate trustRoot = (X509Certificate) this.trustRoots.get(certificate.getSubjectX500Principal());
        return trustRoot != null && trustRoot.getPublicKey().equals(certificate.getPublicKey());
    }

    public X509Certificate getTrustRootFor(X509Certificate x509Certificate) {
        X509Certificate certificate = x509Certificate;
        X509Certificate trustRoot = (X509Certificate) this.trustRoots.get(certificate.getIssuerX500Principal());
        if (trustRoot == null) {
            return null;
        }
        if (trustRoot.getSubjectX500Principal().equals(certificate.getSubjectX500Principal())) {
            return null;
        }
        try {
            certificate.verify(trustRoot.getPublicKey());
            return trustRoot;
        } catch (GeneralSecurityException e) {
            GeneralSecurityException generalSecurityException = e;
            return null;
        }
    }

    private HashMap<Principal, X509Certificate> initializeTrustedRoots(KeyStore keyStore) {
        AssertionError assertionError;
        HashMap hashMap;
        KeyStore trustStore2 = keyStore;
        try {
            HashMap hashMap2 = hashMap;
            HashMap hashMap3 = new HashMap();
            HashMap hashMap4 = hashMap2;
            Enumeration aliases = trustStore2.aliases();
            while (aliases.hasMoreElements()) {
                X509Certificate cert = (X509Certificate) trustStore2.getCertificate((String) aliases.nextElement());
                if (cert != null) {
                    Object put = hashMap4.put(cert.getSubjectX500Principal(), cert);
                }
            }
            return hashMap4;
        } catch (KeyStoreException e) {
            KeyStoreException e2 = e;
            AssertionError assertionError2 = assertionError;
            AssertionError assertionError3 = new AssertionError(e2);
            throw assertionError2;
        }
    }

    private KeyStore getTrustStore(InputStream inputStream, String str) {
        AssertionError assertionError;
        AssertionError assertionError2;
        AssertionError assertionError3;
        AssertionError assertionError4;
        BufferedInputStream bufferedInputStream;
        BufferedInputStream bin;
        InputStream keystoreStream = inputStream;
        String passwd = str;
        try {
            KeyStore trustStore2 = KeyStore.getInstance("BKS");
            BufferedInputStream bufferedInputStream2 = bufferedInputStream;
            BufferedInputStream bufferedInputStream3 = new BufferedInputStream(keystoreStream);
            bin = bufferedInputStream2;
            trustStore2.load(bin, passwd.toCharArray());
            bin.close();
            return trustStore2;
        } catch (KeyStoreException e) {
            KeyStoreException kse = e;
            AssertionError assertionError5 = assertionError4;
            AssertionError assertionError6 = new AssertionError(kse);
            throw assertionError5;
        } catch (NoSuchAlgorithmException e2) {
            NoSuchAlgorithmException e3 = e2;
            AssertionError assertionError7 = assertionError3;
            AssertionError assertionError8 = new AssertionError(e3);
            throw assertionError7;
        } catch (CertificateException e4) {
            CertificateException e5 = e4;
            AssertionError assertionError9 = assertionError2;
            AssertionError assertionError10 = new AssertionError(e5);
            throw assertionError9;
        } catch (IOException e6) {
            IOException e7 = e6;
            AssertionError assertionError11 = assertionError;
            AssertionError assertionError12 = new AssertionError(e7);
            throw assertionError11;
        } catch (Throwable th) {
            Throwable th2 = th;
            bin.close();
            throw th2;
        }
    }
}
