package p004io.fabric.sdk.android.services.concurrency.internal;

/* renamed from: io.fabric.sdk.android.services.concurrency.internal.RetryState */
public class RetryState {
    private final Backoff backoff;
    private final int retryCount;
    private final RetryPolicy retryPolicy;

    public RetryState(Backoff backoff2, RetryPolicy retryPolicy2) {
        this(0, backoff2, retryPolicy2);
    }

    public RetryState(int i, Backoff backoff2, RetryPolicy retryPolicy2) {
        Backoff backoff3 = backoff2;
        RetryPolicy retryPolicy3 = retryPolicy2;
        this.retryCount = i;
        this.backoff = backoff3;
        this.retryPolicy = retryPolicy3;
    }

    public int getRetryCount() {
        return this.retryCount;
    }

    public long getRetryDelay() {
        return this.backoff.getDelayMillis(this.retryCount);
    }

    public Backoff getBackoff() {
        return this.backoff;
    }

    public RetryPolicy getRetryPolicy() {
        return this.retryPolicy;
    }

    public RetryState nextRetryState() {
        RetryState retryState;
        RetryState retryState2 = retryState;
        RetryState retryState3 = new RetryState(this.retryCount + 1, this.backoff, this.retryPolicy);
        return retryState2;
    }

    public RetryState initialRetryState() {
        RetryState retryState;
        RetryState retryState2 = retryState;
        RetryState retryState3 = new RetryState(this.backoff, this.retryPolicy);
        return retryState2;
    }
}
