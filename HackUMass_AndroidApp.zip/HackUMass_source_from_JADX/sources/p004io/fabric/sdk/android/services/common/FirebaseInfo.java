package p004io.fabric.sdk.android.services.common;

import android.content.Context;
import android.text.TextUtils;
import com.google.appinventor.components.common.PropertyTypeConstants;
import p004io.fabric.sdk.android.Fabric;

/* renamed from: io.fabric.sdk.android.services.common.FirebaseInfo */
public class FirebaseInfo {
    static final String AUTO_INITIALIZE = "io.fabric.auto_initialize";
    static final String FIREBASE_FEATURE_SWITCH = "com.crashlytics.useFirebaseAppId";
    static final String GOOGLE_APP_ID = "google_app_id";

    public FirebaseInfo() {
    }

    /* access modifiers changed from: 0000 */
    public String getApiKeyFromFirebaseAppId(Context context) {
        Context context2 = context;
        int id = CommonUtils.getResourcesIdentifier(context2, GOOGLE_APP_ID, PropertyTypeConstants.PROPERTY_TYPE_STRING);
        if (id == 0) {
            return null;
        }
        Fabric.getLogger().mo23829d(Fabric.TAG, "Generating Crashlytics ApiKey from google_app_id in Strings");
        return createApiKeyFromFirebaseAppId(context2.getResources().getString(id));
    }

    /* access modifiers changed from: 0000 */
    public String createApiKeyFromFirebaseAppId(String str) {
        return CommonUtils.sha256(str).substring(0, 40);
    }

    public boolean isFirebaseCrashlyticsEnabled(Context context) {
        Context context2 = context;
        if (CommonUtils.getBooleanResourceValue(context2, FIREBASE_FEATURE_SWITCH, false)) {
            return true;
        }
        return hasGoogleAppId(context2) && !hasApiKey(context2);
    }

    /* access modifiers changed from: 0000 */
    public boolean hasApiKey(Context context) {
        ApiKey apiKey;
        ApiKey apiKey2;
        Context context2 = context;
        ApiKey apiKey3 = apiKey;
        ApiKey apiKey4 = new ApiKey();
        if (!TextUtils.isEmpty(apiKey3.getApiKeyFromManifest(context2))) {
            return true;
        }
        ApiKey apiKey5 = apiKey2;
        ApiKey apiKey6 = new ApiKey();
        return !TextUtils.isEmpty(apiKey5.getApiKeyFromStrings(context2));
    }

    public boolean isAutoInitializeFlagEnabled(Context context) {
        Context context2 = context;
        int id = CommonUtils.getResourcesIdentifier(context2, AUTO_INITIALIZE, "bool");
        if (id == 0) {
            return false;
        }
        boolean autoInitialize = context2.getResources().getBoolean(id);
        if (autoInitialize) {
            Fabric.getLogger().mo23829d(Fabric.TAG, "Found Fabric auto-initialization flag for joint Firebase/Fabric customers");
        }
        return autoInitialize;
    }

    /* access modifiers changed from: 0000 */
    public boolean hasGoogleAppId(Context context) {
        Context context2 = context;
        int id = CommonUtils.getResourcesIdentifier(context2, GOOGLE_APP_ID, PropertyTypeConstants.PROPERTY_TYPE_STRING);
        if (id == 0) {
            return false;
        }
        return !TextUtils.isEmpty(context2.getResources().getString(id));
    }
}
