package p004io.fabric.sdk.android.services.persistence;

import android.annotation.SuppressLint;

/* renamed from: io.fabric.sdk.android.services.persistence.PreferenceStoreStrategy */
public class PreferenceStoreStrategy<T> implements PersistenceStrategy<T> {
    private final String key;
    private final SerializationStrategy<T> serializer;
    private final PreferenceStore store;

    public PreferenceStoreStrategy(PreferenceStore preferenceStore, SerializationStrategy<T> serializationStrategy, String str) {
        SerializationStrategy<T> serializer2 = serializationStrategy;
        String preferenceKey = str;
        this.store = preferenceStore;
        this.serializer = serializer2;
        this.key = preferenceKey;
    }

    @SuppressLint({"CommitPrefEdits"})
    public void save(T t) {
        boolean save = this.store.save(this.store.edit().putString(this.key, this.serializer.serialize(t)));
    }

    public T restore() {
        return this.serializer.deserialize(this.store.get().getString(this.key, null));
    }

    @SuppressLint({"CommitPrefEdits"})
    public void clear() {
        boolean commit = this.store.edit().remove(this.key).commit();
    }
}
