package p004io.fabric.sdk.android.services.common;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Parcel;
import android.os.RemoteException;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import p004io.fabric.sdk.android.Fabric;

/* renamed from: io.fabric.sdk.android.services.common.AdvertisingInfoServiceStrategy */
class AdvertisingInfoServiceStrategy implements AdvertisingInfoStrategy {
    public static final String GOOGLE_PLAY_SERVICES_INTENT = "com.google.android.gms.ads.identifier.service.START";
    public static final String GOOGLE_PLAY_SERVICES_INTENT_PACKAGE_NAME = "com.google.android.gms";
    private static final String GOOGLE_PLAY_SERVICE_PACKAGE_NAME = "com.android.vending";
    private final Context context;

    /* renamed from: io.fabric.sdk.android.services.common.AdvertisingInfoServiceStrategy$AdvertisingConnection */
    private static final class AdvertisingConnection implements ServiceConnection {
        private static final int QUEUE_TIMEOUT_IN_MS = 200;
        private final LinkedBlockingQueue<IBinder> queue;
        private boolean retrieved;

        private AdvertisingConnection() {
            LinkedBlockingQueue<IBinder> linkedBlockingQueue;
            this.retrieved = false;
            LinkedBlockingQueue<IBinder> linkedBlockingQueue2 = linkedBlockingQueue;
            LinkedBlockingQueue<IBinder> linkedBlockingQueue3 = new LinkedBlockingQueue<>(1);
            this.queue = linkedBlockingQueue2;
        }

        /* synthetic */ AdvertisingConnection(C14931 r4) {
            C14931 r1 = r4;
            this();
        }

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            ComponentName componentName2 = componentName;
            try {
                this.queue.put(iBinder);
            } catch (InterruptedException e) {
                InterruptedException interruptedException = e;
            }
        }

        public void onServiceDisconnected(ComponentName componentName) {
            ComponentName componentName2 = componentName;
            this.queue.clear();
        }

        public IBinder getBinder() {
            if (this.retrieved) {
                Fabric.getLogger().mo23831e(Fabric.TAG, "getBinder already called");
            }
            this.retrieved = true;
            try {
                return (IBinder) this.queue.poll(200, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                InterruptedException interruptedException = e;
                return null;
            }
        }
    }

    /* renamed from: io.fabric.sdk.android.services.common.AdvertisingInfoServiceStrategy$AdvertisingInterface */
    private static final class AdvertisingInterface implements IInterface {
        public static final String ADVERTISING_ID_SERVICE_INTERFACE_TOKEN = "com.google.android.gms.ads.identifier.internal.IAdvertisingIdService";
        private static final int AD_TRANSACTION_CODE_ID = 1;
        private static final int AD_TRANSACTION_CODE_LIMIT_AD_TRACKING = 2;
        private static final int FLAGS_NONE = 0;
        private final IBinder binder;

        public AdvertisingInterface(IBinder iBinder) {
            this.binder = iBinder;
        }

        public IBinder asBinder() {
            return this.binder;
        }

        public String getId() throws RemoteException {
            Parcel data = Parcel.obtain();
            Parcel reply = Parcel.obtain();
            String id = null;
            try {
                data.writeInterfaceToken(ADVERTISING_ID_SERVICE_INTERFACE_TOKEN);
                boolean transact = this.binder.transact(1, data, reply, 0);
                reply.readException();
                id = reply.readString();
                reply.recycle();
                data.recycle();
            } catch (Exception e) {
                Exception exc = e;
                Fabric.getLogger().mo23829d(Fabric.TAG, "Could not get parcel from Google Play Service to capture AdvertisingId");
                reply.recycle();
                data.recycle();
            } catch (Throwable th) {
                Throwable th2 = th;
                reply.recycle();
                data.recycle();
                throw th2;
            }
            return id;
        }

        public boolean isLimitAdTrackingEnabled() throws RemoteException {
            Parcel data = Parcel.obtain();
            Parcel reply = Parcel.obtain();
            boolean limitAdTracking = false;
            try {
                data.writeInterfaceToken(ADVERTISING_ID_SERVICE_INTERFACE_TOKEN);
                data.writeInt(1);
                boolean transact = this.binder.transact(2, data, reply, 0);
                reply.readException();
                limitAdTracking = 0 != reply.readInt();
                reply.recycle();
                data.recycle();
            } catch (Exception e) {
                Exception exc = e;
                Fabric.getLogger().mo23829d(Fabric.TAG, "Could not get parcel from Google Play Service to capture Advertising limitAdTracking");
                reply.recycle();
                data.recycle();
            } catch (Throwable th) {
                Throwable th2 = th;
                reply.recycle();
                data.recycle();
                throw th2;
            }
            return limitAdTracking;
        }
    }

    public AdvertisingInfoServiceStrategy(Context context2) {
        this.context = context2.getApplicationContext();
    }

    public AdvertisingInfo getAdvertisingInfo() {
        AdvertisingConnection advertisingConnection;
        Intent intent;
        AdvertisingInterface advertisingInterface;
        AdvertisingInfo advertisingInfo;
        if (Looper.myLooper() == Looper.getMainLooper()) {
            Fabric.getLogger().mo23829d(Fabric.TAG, "AdvertisingInfoServiceStrategy cannot be called on the main thread");
            return null;
        }
        try {
            PackageInfo packageInfo = this.context.getPackageManager().getPackageInfo(GOOGLE_PLAY_SERVICE_PACKAGE_NAME, 0);
            AdvertisingConnection advertisingConnection2 = advertisingConnection;
            AdvertisingConnection advertisingConnection3 = new AdvertisingConnection(null);
            AdvertisingConnection connection = advertisingConnection2;
            Intent intent2 = intent;
            Intent intent3 = new Intent(GOOGLE_PLAY_SERVICES_INTENT);
            Intent intent4 = intent2;
            Intent intent5 = intent4.setPackage(GOOGLE_PLAY_SERVICES_INTENT_PACKAGE_NAME);
            try {
                if (this.context.bindService(intent4, connection, 1)) {
                    AdvertisingInterface advertisingInterface2 = advertisingInterface;
                    AdvertisingInterface advertisingInterface3 = new AdvertisingInterface(connection.getBinder());
                    AdvertisingInterface adInterface = advertisingInterface2;
                    AdvertisingInfo advertisingInfo2 = advertisingInfo;
                    AdvertisingInfo advertisingInfo3 = new AdvertisingInfo(adInterface.getId(), adInterface.isLimitAdTrackingEnabled());
                    AdvertisingInfo advertisingInfo4 = advertisingInfo2;
                    this.context.unbindService(connection);
                    return advertisingInfo4;
                }
                Fabric.getLogger().mo23829d(Fabric.TAG, "Could not bind to Google Play Service to capture AdvertisingId");
                return null;
            } catch (Exception e) {
                Fabric.getLogger().mo23843w(Fabric.TAG, "Exception in binding to Google Play Service to capture AdvertisingId", e);
                this.context.unbindService(connection);
            } catch (Throwable th) {
                Fabric.getLogger().mo23830d(Fabric.TAG, "Could not bind to Google Play Service to capture AdvertisingId", th);
            }
        } catch (NameNotFoundException e2) {
            NameNotFoundException nameNotFoundException = e2;
            Fabric.getLogger().mo23829d(Fabric.TAG, "Unable to find Google Play Services package name");
            return null;
        } catch (Exception e3) {
            Fabric.getLogger().mo23830d(Fabric.TAG, "Unable to determine if Google Play Services is available", e3);
            return null;
        }
    }
}
