package p004io.fabric.sdk.android.services.common;

/* renamed from: io.fabric.sdk.android.services.common.DeliveryMechanism */
public enum DeliveryMechanism {
    ;
    
    public static final String BETA_APP_PACKAGE_NAME = "io.crash.air";

    /* renamed from: id */
    private final int f296id;

    private DeliveryMechanism(int i) {
        String str = r8;
        int i2 = r9;
        this.f296id = i;
    }

    public int getId() {
        return this.f296id;
    }

    public String toString() {
        return Integer.toString(this.f296id);
    }

    public static DeliveryMechanism determineFrom(String str) {
        String installerPackageName = str;
        if (BETA_APP_PACKAGE_NAME.equals(installerPackageName)) {
            return TEST_DISTRIBUTION;
        }
        if (installerPackageName != null) {
            return APP_STORE;
        }
        return DEVELOPER;
    }
}
