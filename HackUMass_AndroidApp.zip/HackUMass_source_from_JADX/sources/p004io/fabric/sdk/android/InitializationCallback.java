package p004io.fabric.sdk.android;

/* renamed from: io.fabric.sdk.android.InitializationCallback */
public interface InitializationCallback<T> {
    public static final InitializationCallback EMPTY;

    /* renamed from: io.fabric.sdk.android.InitializationCallback$Empty */
    public static class Empty implements InitializationCallback<Object> {
        /* synthetic */ Empty(C14911 r4) {
            C14911 r1 = r4;
            this();
        }

        private Empty() {
        }

        public void success(Object object) {
        }

        public void failure(Exception exception) {
        }
    }

    void failure(Exception exc);

    void success(T t);

    static {
        Empty empty;
        Empty empty2 = empty;
        Empty empty3 = new Empty(null);
        EMPTY = empty2;
    }
}
