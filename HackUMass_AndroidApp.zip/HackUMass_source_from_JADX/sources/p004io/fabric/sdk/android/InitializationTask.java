package p004io.fabric.sdk.android;

import p004io.fabric.sdk.android.services.common.TimingMetric;
import p004io.fabric.sdk.android.services.concurrency.Priority;
import p004io.fabric.sdk.android.services.concurrency.PriorityAsyncTask;
import p004io.fabric.sdk.android.services.concurrency.UnmetDependencyException;

/* renamed from: io.fabric.sdk.android.InitializationTask */
class InitializationTask<Result> extends PriorityAsyncTask<Void, Void, Result> {
    private static final String TIMING_METRIC_TAG = "KitInitialization";
    final Kit<Result> kit;

    public InitializationTask(Kit<Result> kit2) {
        this.kit = kit2;
    }

    /* access modifiers changed from: protected */
    public void onPreExecute() {
        super.onPreExecute();
        TimingMetric timingMetric = createAndStartTimingMetric("onPreExecute");
        try {
            boolean result = this.kit.onPreExecute();
            timingMetric.stopMeasuring();
            if (!result) {
                boolean cancel = cancel(true);
            }
        } catch (UnmetDependencyException e) {
            throw e;
        } catch (Exception e2) {
            Fabric.getLogger().mo23832e(Fabric.TAG, "Failure onPreExecute()", e2);
            timingMetric.stopMeasuring();
            if (0 == 0) {
                boolean cancel2 = cancel(true);
            }
        } catch (Throwable th) {
            Throwable th2 = th;
            timingMetric.stopMeasuring();
            if (0 == 0) {
                boolean cancel3 = cancel(true);
            }
            throw th2;
        }
    }

    /* access modifiers changed from: protected */
    public Result doInBackground(Void... voidArr) {
        Void[] voidArr2 = voidArr;
        TimingMetric timingMetric = createAndStartTimingMetric("doInBackground");
        Result result = null;
        if (!isCancelled()) {
            result = this.kit.doInBackground();
        }
        timingMetric.stopMeasuring();
        return result;
    }

    /* access modifiers changed from: protected */
    public void onPostExecute(Result result) {
        Result result2 = result;
        this.kit.onPostExecute(result2);
        this.kit.initializationCallback.success(result2);
    }

    /* access modifiers changed from: protected */
    public void onCancelled(Result result) {
        StringBuilder sb;
        InitializationException initializationException;
        this.kit.onCancelled(result);
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        String message = sb2.append(this.kit.getIdentifier()).append(" Initialization was cancelled").toString();
        InitializationException initializationException2 = initializationException;
        InitializationException initializationException3 = new InitializationException(message);
        this.kit.initializationCallback.failure(initializationException2);
    }

    public Priority getPriority() {
        return Priority.HIGH;
    }

    private TimingMetric createAndStartTimingMetric(String str) {
        TimingMetric timingMetric;
        StringBuilder sb;
        String event = str;
        TimingMetric timingMetric2 = timingMetric;
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        TimingMetric timingMetric3 = new TimingMetric(sb2.append(this.kit.getIdentifier()).append(".").append(event).toString(), TIMING_METRIC_TAG);
        TimingMetric timingMetric4 = timingMetric2;
        timingMetric4.startMeasuring();
        return timingMetric4;
    }
}
