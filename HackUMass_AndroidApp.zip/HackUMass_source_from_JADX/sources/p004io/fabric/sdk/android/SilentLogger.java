package p004io.fabric.sdk.android;

/* renamed from: io.fabric.sdk.android.SilentLogger */
public class SilentLogger implements Logger {
    private int logLevel = 7;

    public SilentLogger() {
    }

    public boolean isLoggable(String str, int i) {
        String str2 = str;
        int i2 = i;
        return false;
    }

    /* renamed from: d */
    public void mo23830d(String tag, String text, Throwable throwable) {
    }

    /* renamed from: v */
    public void mo23841v(String tag, String text, Throwable throwable) {
    }

    /* renamed from: i */
    public void mo23835i(String tag, String text, Throwable throwable) {
    }

    /* renamed from: w */
    public void mo23843w(String tag, String text, Throwable throwable) {
    }

    /* renamed from: e */
    public void mo23832e(String tag, String text, Throwable throwable) {
    }

    /* renamed from: d */
    public void mo23829d(String tag, String text) {
    }

    /* renamed from: v */
    public void mo23840v(String tag, String text) {
    }

    /* renamed from: i */
    public void mo23834i(String tag, String text) {
    }

    /* renamed from: w */
    public void mo23842w(String tag, String text) {
    }

    /* renamed from: e */
    public void mo23831e(String tag, String text) {
    }

    public void log(int priority, String tag, String msg) {
    }

    public void log(int priority, String tag, String msg, boolean forceLog) {
    }

    public int getLogLevel() {
        return this.logLevel;
    }

    public void setLogLevel(int logLevel2) {
    }
}
