package p004io.fabric.sdk.android;

import android.os.SystemClock;
import android.text.TextUtils;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Callable;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import p004io.fabric.sdk.android.services.common.CommonUtils;

/* renamed from: io.fabric.sdk.android.FabricKitsFinder */
class FabricKitsFinder implements Callable<Map<String, KitInfo>> {
    private static final String FABRIC_BUILD_TYPE_KEY = "fabric-build-type";
    static final String FABRIC_DIR = "fabric/";
    private static final String FABRIC_IDENTIFIER_KEY = "fabric-identifier";
    private static final String FABRIC_VERSION_KEY = "fabric-version";
    final String apkFileName;

    FabricKitsFinder(String str) {
        this.apkFileName = str;
    }

    public Map<String, KitInfo> call() throws Exception {
        HashMap hashMap;
        StringBuilder sb;
        HashMap hashMap2 = hashMap;
        HashMap hashMap3 = new HashMap();
        HashMap hashMap4 = hashMap2;
        long startScan = SystemClock.elapsedRealtime();
        hashMap4.putAll(findImplicitKits());
        hashMap4.putAll(findRegisteredKits());
        Logger logger = Fabric.getLogger();
        String str = Fabric.TAG;
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        logger.mo23840v(str, sb2.append("finish scanning in ").append(SystemClock.elapsedRealtime() - startScan).toString());
        return hashMap4;
    }

    private Map<String, KitInfo> findImplicitKits() {
        HashMap hashMap;
        KitInfo kitInfo;
        HashMap hashMap2 = hashMap;
        HashMap hashMap3 = new HashMap();
        HashMap hashMap4 = hashMap2;
        try {
            Class cls = Class.forName("com.google.android.gms.ads.AdView");
            KitInfo kitInfo2 = kitInfo;
            KitInfo kitInfo3 = new KitInfo("com.google.firebase.firebase-ads", "0.0.0", "binary");
            KitInfo admobKitInfo = kitInfo2;
            Object put = hashMap4.put(admobKitInfo.getIdentifier(), admobKitInfo);
            Fabric.getLogger().mo23840v(Fabric.TAG, "Found kit: com.google.firebase.firebase-ads");
        } catch (Exception e) {
            Exception exc = e;
        }
        return hashMap4;
    }

    private Map<String, KitInfo> findRegisteredKits() throws Exception {
        HashMap hashMap;
        HashMap hashMap2 = hashMap;
        HashMap hashMap3 = new HashMap();
        HashMap hashMap4 = hashMap2;
        ZipFile apkFile = loadApkFile();
        Enumeration entries = apkFile.entries();
        while (entries.hasMoreElements()) {
            ZipEntry entry = (ZipEntry) entries.nextElement();
            if (entry.getName().startsWith(FABRIC_DIR) && entry.getName().length() > FABRIC_DIR.length()) {
                KitInfo kitInfo = loadKitInfo(entry, apkFile);
                if (kitInfo != null) {
                    Object put = hashMap4.put(kitInfo.getIdentifier(), kitInfo);
                    Logger logger = Fabric.getLogger();
                    String str = Fabric.TAG;
                    Object[] objArr = new Object[2];
                    Object[] objArr2 = objArr;
                    objArr[0] = kitInfo.getIdentifier();
                    Object[] objArr3 = objArr2;
                    Object[] objArr4 = objArr3;
                    objArr3[1] = kitInfo.getVersion();
                    logger.mo23840v(str, String.format("Found kit:[%s] version:[%s]", objArr4));
                }
            }
        }
        if (apkFile != null) {
            try {
                apkFile.close();
            } catch (IOException e) {
                IOException iOException = e;
            }
        }
        return hashMap4;
    }

    private KitInfo loadKitInfo(ZipEntry zipEntry, ZipFile zipFile) {
        StringBuilder sb;
        Properties properties;
        IllegalStateException illegalStateException;
        StringBuilder sb2;
        KitInfo kitInfo;
        ZipEntry fabricFile = zipEntry;
        InputStream inputStream = null;
        try {
            inputStream = zipFile.getInputStream(fabricFile);
            Properties properties2 = properties;
            Properties properties3 = new Properties();
            Properties properties4 = properties2;
            properties4.load(inputStream);
            String id = properties4.getProperty(FABRIC_IDENTIFIER_KEY);
            String version = properties4.getProperty(FABRIC_VERSION_KEY);
            String buildType = properties4.getProperty(FABRIC_BUILD_TYPE_KEY);
            if (TextUtils.isEmpty(id) || TextUtils.isEmpty(version)) {
                IllegalStateException illegalStateException2 = illegalStateException;
                StringBuilder sb3 = sb2;
                StringBuilder sb4 = new StringBuilder();
                IllegalStateException illegalStateException3 = new IllegalStateException(sb3.append("Invalid format of fabric file,").append(fabricFile.getName()).toString());
                throw illegalStateException2;
            }
            KitInfo kitInfo2 = kitInfo;
            KitInfo kitInfo3 = new KitInfo(id, version, buildType);
            KitInfo kitInfo4 = kitInfo2;
            CommonUtils.closeQuietly(inputStream);
            return kitInfo4;
        } catch (IOException e) {
            IOException ie = e;
            Logger logger = Fabric.getLogger();
            String str = Fabric.TAG;
            StringBuilder sb5 = sb;
            StringBuilder sb6 = new StringBuilder();
            logger.mo23832e(str, sb5.append("Error when parsing fabric properties ").append(fabricFile.getName()).toString(), ie);
            CommonUtils.closeQuietly(inputStream);
            return null;
        } catch (Throwable th) {
            Throwable th2 = th;
            CommonUtils.closeQuietly(inputStream);
            throw th2;
        }
    }

    /* access modifiers changed from: protected */
    public ZipFile loadApkFile() throws IOException {
        ZipFile zipFile;
        ZipFile zipFile2 = zipFile;
        ZipFile zipFile3 = new ZipFile(this.apkFileName);
        return zipFile2;
    }
}
