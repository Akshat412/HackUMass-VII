package p004io.fabric.sdk.android;

import android.content.Context;
import java.io.File;
import java.util.Collection;
import java.util.concurrent.ExecutorService;
import p004io.fabric.sdk.android.services.common.IdManager;
import p004io.fabric.sdk.android.services.concurrency.DependsOn;
import p004io.fabric.sdk.android.services.concurrency.Task;

/* renamed from: io.fabric.sdk.android.Kit */
public abstract class Kit<Result> implements Comparable<Kit> {
    Context context;
    final DependsOn dependsOnAnnotation = ((DependsOn) getClass().getAnnotation(DependsOn.class));
    Fabric fabric;
    IdManager idManager;
    InitializationCallback<Result> initializationCallback;
    InitializationTask<Result> initializationTask;

    /* access modifiers changed from: protected */
    public abstract Result doInBackground();

    public abstract String getIdentifier();

    public abstract String getVersion();

    public Kit() {
        InitializationTask<Result> initializationTask2;
        InitializationTask<Result> initializationTask3 = initializationTask2;
        InitializationTask<Result> initializationTask4 = new InitializationTask<>(this);
        this.initializationTask = initializationTask3;
    }

    /* access modifiers changed from: 0000 */
    public void injectParameters(Context context2, Fabric fabric2, InitializationCallback<Result> initializationCallback2, IdManager idManager2) {
        FabricContext fabricContext;
        Context context3 = context2;
        InitializationCallback<Result> callback = initializationCallback2;
        IdManager idManager3 = idManager2;
        this.fabric = fabric2;
        FabricContext fabricContext2 = fabricContext;
        FabricContext fabricContext3 = new FabricContext(context3, getIdentifier(), getPath());
        this.context = fabricContext2;
        this.initializationCallback = callback;
        this.idManager = idManager3;
    }

    /* access modifiers changed from: 0000 */
    public final void initialize() {
        InitializationTask<Result> initializationTask2 = this.initializationTask;
        ExecutorService executorService = this.fabric.getExecutorService();
        Void[] voidArr = new Void[1];
        Void[] voidArr2 = voidArr;
        voidArr[0] = null;
        initializationTask2.executeOnExecutor(executorService, voidArr2);
    }

    /* access modifiers changed from: protected */
    public boolean onPreExecute() {
        return true;
    }

    /* access modifiers changed from: protected */
    public void onPostExecute(Result result) {
    }

    /* access modifiers changed from: protected */
    public void onCancelled(Result result) {
    }

    /* access modifiers changed from: protected */
    public IdManager getIdManager() {
        return this.idManager;
    }

    public Context getContext() {
        return this.context;
    }

    public Fabric getFabric() {
        return this.fabric;
    }

    public String getPath() {
        StringBuilder sb;
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        return sb2.append(".Fabric").append(File.separator).append(getIdentifier()).toString();
    }

    public int compareTo(Kit kit) {
        Kit another = kit;
        if (containsAnnotatedDependency(another)) {
            return 1;
        }
        if (another.containsAnnotatedDependency(this)) {
            return -1;
        }
        if (hasAnnotatedDependency() && !another.hasAnnotatedDependency()) {
            return 1;
        }
        if (hasAnnotatedDependency() || !another.hasAnnotatedDependency()) {
            return 0;
        }
        return -1;
    }

    /* access modifiers changed from: 0000 */
    public boolean containsAnnotatedDependency(Kit kit) {
        Kit target = kit;
        if (hasAnnotatedDependency()) {
            Class[] value = this.dependsOnAnnotation.value();
            int length = value.length;
            for (int i = 0; i < length; i++) {
                if (value[i].isAssignableFrom(target.getClass())) {
                    return true;
                }
            }
        }
        return false;
    }

    /* access modifiers changed from: 0000 */
    public boolean hasAnnotatedDependency() {
        return this.dependsOnAnnotation != null;
    }

    /* access modifiers changed from: protected */
    public Collection<Task> getDependencies() {
        return this.initializationTask.getDependencies();
    }
}
