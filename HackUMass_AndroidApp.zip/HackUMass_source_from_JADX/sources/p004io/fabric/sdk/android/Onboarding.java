package p004io.fabric.sdk.android;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.Future;
import p004io.fabric.sdk.android.services.common.ApiKey;
import p004io.fabric.sdk.android.services.common.CommonUtils;
import p004io.fabric.sdk.android.services.common.DataCollectionArbiter;
import p004io.fabric.sdk.android.services.common.DeliveryMechanism;
import p004io.fabric.sdk.android.services.common.IdManager;
import p004io.fabric.sdk.android.services.network.DefaultHttpRequestFactory;
import p004io.fabric.sdk.android.services.network.HttpRequestFactory;
import p004io.fabric.sdk.android.services.settings.AppRequestData;
import p004io.fabric.sdk.android.services.settings.AppSettingsData;
import p004io.fabric.sdk.android.services.settings.CreateAppSpiCall;
import p004io.fabric.sdk.android.services.settings.IconRequest;
import p004io.fabric.sdk.android.services.settings.Settings;
import p004io.fabric.sdk.android.services.settings.SettingsData;
import p004io.fabric.sdk.android.services.settings.UpdateAppSpiCall;

/* renamed from: io.fabric.sdk.android.Onboarding */
class Onboarding extends Kit<Boolean> {
    private static final String BINARY_BUILD_TYPE = "binary";
    static final String CRASHLYTICS_API_ENDPOINT = "com.crashlytics.ApiEndpoint";
    private String applicationLabel;
    private String installerPackageName;
    private final Future<Map<String, KitInfo>> kitsFinder;
    private PackageInfo packageInfo;
    private PackageManager packageManager;
    private String packageName;
    private final Collection<Kit> providedKits;
    private final HttpRequestFactory requestFactory;
    private String targetAndroidSdkVersion;
    private String versionCode;
    private String versionName;

    public Onboarding(Future<Map<String, KitInfo>> future, Collection<Kit> collection) {
        DefaultHttpRequestFactory defaultHttpRequestFactory;
        Future<Map<String, KitInfo>> kitsFinder2 = future;
        Collection<Kit> providedKits2 = collection;
        DefaultHttpRequestFactory defaultHttpRequestFactory2 = defaultHttpRequestFactory;
        DefaultHttpRequestFactory defaultHttpRequestFactory3 = new DefaultHttpRequestFactory();
        this.requestFactory = defaultHttpRequestFactory2;
        this.kitsFinder = kitsFinder2;
        this.providedKits = providedKits2;
    }

    public String getVersion() {
        return "1.4.8.32";
    }

    /* access modifiers changed from: protected */
    public boolean onPreExecute() {
        try {
            this.installerPackageName = getIdManager().getInstallerPackageName();
            this.packageManager = getContext().getPackageManager();
            this.packageName = getContext().getPackageName();
            this.packageInfo = this.packageManager.getPackageInfo(this.packageName, 0);
            this.versionCode = Integer.toString(this.packageInfo.versionCode);
            this.versionName = this.packageInfo.versionName == null ? IdManager.DEFAULT_VERSION_NAME : this.packageInfo.versionName;
            this.applicationLabel = this.packageManager.getApplicationLabel(getContext().getApplicationInfo()).toString();
            this.targetAndroidSdkVersion = Integer.toString(getContext().getApplicationInfo().targetSdkVersion);
            return true;
        } catch (NameNotFoundException e) {
            Fabric.getLogger().mo23832e(Fabric.TAG, "Failed init", e);
            return false;
        }
    }

    /* JADX WARNING: type inference failed for: r10v0 */
    /* JADX WARNING: type inference failed for: r6v14 */
    /* JADX WARNING: type inference failed for: r4v1 */
    /* JADX WARNING: type inference failed for: r4v2 */
    /* JADX WARNING: type inference failed for: r7v2, types: [java.util.Map] */
    /* JADX WARNING: type inference failed for: r6v22, types: [java.util.Map] */
    /* JADX WARNING: type inference failed for: r4v3 */
    /* access modifiers changed from: protected */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 5 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.Boolean doInBackground() {
        /*
            r11 = this;
            r0 = r11
            r6 = r0
            android.content.Context r6 = r6.getContext()
            java.lang.String r6 = p004io.fabric.sdk.android.services.common.CommonUtils.getAppIconHashOrNull(r6)
            r1 = r6
            r6 = 0
            r2 = r6
            r6 = r0
            io.fabric.sdk.android.services.settings.SettingsData r6 = r6.retrieveSettingsData()
            r3 = r6
            r6 = r3
            if (r6 == 0) goto L_0x003e
            r6 = r0
            java.util.concurrent.Future<java.util.Map<java.lang.String, io.fabric.sdk.android.KitInfo>> r6 = r6.kitsFinder     // Catch:{ Exception -> 0x004f }
            if (r6 == 0) goto L_0x0045
            r6 = r0
            java.util.concurrent.Future<java.util.Map<java.lang.String, io.fabric.sdk.android.KitInfo>> r6 = r6.kitsFinder     // Catch:{ Exception -> 0x004f }
            java.lang.Object r6 = r6.get()     // Catch:{ Exception -> 0x004f }
            java.util.Map r6 = (java.util.Map) r6     // Catch:{ Exception -> 0x004f }
            r4 = r6
        L_0x0025:
            r6 = r0
            r7 = r4
            r8 = r0
            java.util.Collection<io.fabric.sdk.android.Kit> r8 = r8.providedKits     // Catch:{ Exception -> 0x004f }
            java.util.Map r6 = r6.mergeKits(r7, r8)     // Catch:{ Exception -> 0x004f }
            r5 = r6
            r6 = r0
            r7 = r1
            r8 = r3
            io.fabric.sdk.android.services.settings.AppSettingsData r8 = r8.appData     // Catch:{ Exception -> 0x004f }
            r9 = r5
            java.util.Collection r9 = r9.values()     // Catch:{ Exception -> 0x004f }
            boolean r6 = r6.performAutoConfigure(r7, r8, r9)     // Catch:{ Exception -> 0x004f }
            r2 = r6
        L_0x003e:
            r6 = r2
            java.lang.Boolean r6 = java.lang.Boolean.valueOf(r6)
            r0 = r6
            return r0
        L_0x0045:
            java.util.HashMap r6 = new java.util.HashMap     // Catch:{ Exception -> 0x004f }
            r10 = r6
            r6 = r10
            r7 = r10
            r7.<init>()     // Catch:{ Exception -> 0x004f }
            r4 = r6
            goto L_0x0025
        L_0x004f:
            r6 = move-exception
            r4 = r6
            io.fabric.sdk.android.Logger r6 = p004io.fabric.sdk.android.Fabric.getLogger()
            java.lang.String r7 = "Fabric"
            java.lang.String r8 = "Error performing auto configuration."
            r9 = r4
            r6.mo23832e(r7, r8, r9)
            goto L_0x003e
        */
        throw new UnsupportedOperationException("Method not decompiled: p004io.fabric.sdk.android.Onboarding.doInBackground():java.lang.Boolean");
    }

    private SettingsData retrieveSettingsData() {
        try {
            boolean loadSettingsData = Settings.getInstance().initialize(this, this.idManager, this.requestFactory, this.versionCode, this.versionName, getOverridenSpiEndpoint(), DataCollectionArbiter.getInstance(getContext())).loadSettingsData();
            return Settings.getInstance().awaitSettingsData();
        } catch (Exception e) {
            Fabric.getLogger().mo23832e(Fabric.TAG, "Error dealing with settings", e);
            return null;
        }
    }

    /* access modifiers changed from: 0000 */
    public Map<String, KitInfo> mergeKits(Map<String, KitInfo> map, Collection<Kit> collection) {
        KitInfo kitInfo;
        Map<String, KitInfo> scannedKits = map;
        for (Kit kit : collection) {
            if (!scannedKits.containsKey(kit.getIdentifier())) {
                Map<String, KitInfo> map2 = scannedKits;
                String identifier = kit.getIdentifier();
                KitInfo kitInfo2 = kitInfo;
                KitInfo kitInfo3 = new KitInfo(kit.getIdentifier(), kit.getVersion(), BINARY_BUILD_TYPE);
                Object put = map2.put(identifier, kitInfo2);
            }
        }
        return scannedKits;
    }

    public String getIdentifier() {
        return "io.fabric.sdk.android:fabric";
    }

    private boolean performAutoConfigure(String str, AppSettingsData appSettingsData, Collection<KitInfo> collection) {
        String iconHash = str;
        AppSettingsData appSettings = appSettingsData;
        Collection<KitInfo> sdkKits = collection;
        boolean properlyConfigured = true;
        if (AppSettingsData.STATUS_NEW.equals(appSettings.status)) {
            if (performCreateApp(iconHash, appSettings, sdkKits)) {
                properlyConfigured = Settings.getInstance().loadSettingsSkippingCache();
            } else {
                Fabric.getLogger().mo23832e(Fabric.TAG, "Failed to create app with Crashlytics service.", null);
                properlyConfigured = false;
            }
        } else if (AppSettingsData.STATUS_CONFIGURED.equals(appSettings.status)) {
            properlyConfigured = Settings.getInstance().loadSettingsSkippingCache();
        } else if (appSettings.updateRequired) {
            Fabric.getLogger().mo23829d(Fabric.TAG, "Server says an update is required - forcing a full App update.");
            boolean performUpdateApp = performUpdateApp(iconHash, appSettings, sdkKits);
        }
        return properlyConfigured;
    }

    private boolean performCreateApp(String str, AppSettingsData appSettingsData, Collection<KitInfo> collection) {
        CreateAppSpiCall createAppSpiCall;
        AppSettingsData appSettings = appSettingsData;
        Collection<KitInfo> sdkKits = collection;
        AppRequestData requestData = buildAppRequest(IconRequest.build(getContext(), str), sdkKits);
        CreateAppSpiCall createAppSpiCall2 = createAppSpiCall;
        CreateAppSpiCall createAppSpiCall3 = new CreateAppSpiCall(this, getOverridenSpiEndpoint(), appSettings.url, this.requestFactory);
        return createAppSpiCall2.invoke(requestData);
    }

    private boolean performUpdateApp(String str, AppSettingsData appSettingsData, Collection<KitInfo> collection) {
        return performUpdateApp(appSettingsData, IconRequest.build(getContext(), str), collection);
    }

    private boolean performUpdateApp(AppSettingsData appSettingsData, IconRequest iconRequest, Collection<KitInfo> collection) {
        UpdateAppSpiCall updateAppSpiCall;
        AppSettingsData appSettings = appSettingsData;
        AppRequestData requestData = buildAppRequest(iconRequest, collection);
        UpdateAppSpiCall updateAppSpiCall2 = updateAppSpiCall;
        UpdateAppSpiCall updateAppSpiCall3 = new UpdateAppSpiCall(this, getOverridenSpiEndpoint(), appSettings.url, this.requestFactory);
        return updateAppSpiCall2.invoke(requestData);
    }

    private AppRequestData buildAppRequest(IconRequest iconRequest, Collection<KitInfo> collection) {
        ApiKey apiKey;
        AppRequestData appRequestData;
        IconRequest iconRequest2 = iconRequest;
        Collection<KitInfo> sdkKits = collection;
        Context context = getContext();
        ApiKey apiKey2 = apiKey;
        ApiKey apiKey3 = new ApiKey();
        String apiKey4 = apiKey2.getValue(context);
        String[] strArr = new String[1];
        String[] strArr2 = strArr;
        strArr[0] = CommonUtils.resolveBuildId(context);
        String instanceId = CommonUtils.createInstanceIdFrom(strArr2);
        int source = DeliveryMechanism.determineFrom(this.installerPackageName).getId();
        AppRequestData appRequestData2 = appRequestData;
        AppRequestData appRequestData3 = new AppRequestData(apiKey4, getIdManager().getAppIdentifier(), this.versionName, this.versionCode, instanceId, this.applicationLabel, source, this.targetAndroidSdkVersion, "0", iconRequest2, sdkKits);
        return appRequestData2;
    }

    /* access modifiers changed from: 0000 */
    public String getOverridenSpiEndpoint() {
        return CommonUtils.getStringsFileValue(getContext(), CRASHLYTICS_API_ENDPOINT);
    }
}
