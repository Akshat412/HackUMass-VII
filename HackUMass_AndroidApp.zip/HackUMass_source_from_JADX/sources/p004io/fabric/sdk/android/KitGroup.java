package p004io.fabric.sdk.android;

import java.util.Collection;

/* renamed from: io.fabric.sdk.android.KitGroup */
public interface KitGroup {
    Collection<? extends Kit> getKits();
}
