package p004io.kodular.poddarrupak2808.HackUMass;

import android.support.p000v4.app.FragmentTransaction;
import com.google.appinventor.components.common.PropertyTypeConstants;
import com.google.appinventor.components.runtime.BluetoothClient;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Clock;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.FirebaseDB;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.ListPicker;
import com.google.appinventor.components.runtime.MakeroidSnackbar;
import com.google.appinventor.components.runtime.SpaceView;
import com.google.appinventor.components.runtime.TextBox;
import com.google.appinventor.components.runtime.errors.PermissionException;
import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import com.google.appinventor.components.runtime.util.RetValManager;
import com.google.appinventor.components.runtime.util.RuntimeErrorAlert;
import com.google.youngandroid.C1158runtime;
import gnu.expr.ModuleBody;
import gnu.expr.ModuleInfo;
import gnu.expr.ModuleMethod;
import gnu.kawa.functions.Apply;
import gnu.kawa.functions.Format;
import gnu.kawa.functions.GetNamedPart;
import gnu.kawa.functions.IsEqual;
import gnu.lists.Consumer;
import gnu.lists.FString;
import gnu.lists.LList;
import gnu.lists.Pair;
import gnu.lists.PairWithPosition;
import gnu.lists.VoidConsumer;
import gnu.mapping.CallContext;
import gnu.mapping.Environment;
import gnu.mapping.SimpleSymbol;
import gnu.mapping.Symbol;
import gnu.mapping.Values;
import gnu.mapping.WrongType;
import gnu.math.IntNum;
import kawa.lang.Promise;
import kawa.lib.C1175lists;
import kawa.lib.misc;
import kawa.lib.strings;
import kawa.standard.Scheme;
import kawa.standard.require;

/* renamed from: io.kodular.poddarrupak2808.HackUMass.Screen1 */
/* compiled from: Screen1.yail */
public class Screen1 extends Form implements Runnable {
    static final SimpleSymbol Lit0;
    static final SimpleSymbol Lit1;
    static final SimpleSymbol Lit10;
    static final PairWithPosition Lit100 = PairWithPosition.make(Lit204, PairWithPosition.make(Lit204, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 558459), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 558454);
    static final PairWithPosition Lit101 = PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 558556);
    static final PairWithPosition Lit102 = PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 558714);
    static final SimpleSymbol Lit103;
    static final SimpleSymbol Lit104;
    static final SimpleSymbol Lit105;
    static final SimpleSymbol Lit106;
    static final SimpleSymbol Lit107;
    static final FString Lit108;
    static final SimpleSymbol Lit109;
    static final SimpleSymbol Lit11;
    static final IntNum Lit110;
    static final FString Lit111;
    static final FString Lit112;
    static final IntNum Lit113 = IntNum.make(16777215);
    static final FString Lit114;
    static final FString Lit115;
    static final SimpleSymbol Lit116;
    static final IntNum Lit117 = IntNum.make(16777215);
    static final FString Lit118;
    static final FString Lit119;
    static final IntNum Lit12 = IntNum.make(28);
    static final SimpleSymbol Lit120;
    static final IntNum Lit121;
    static final IntNum Lit122;
    static final FString Lit123;
    static final PairWithPosition Lit124 = PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 803043);
    static final SimpleSymbol Lit125;
    static final FString Lit126;
    static final SimpleSymbol Lit127;
    static final FString Lit128;
    static final FString Lit129;
    static final SimpleSymbol Lit13;
    static final SimpleSymbol Lit130;
    static final FString Lit131;
    static final FString Lit132;
    static final IntNum Lit133;
    static final FString Lit134;
    static final FString Lit135;
    static final IntNum Lit136;
    static final FString Lit137;
    static final FString Lit138;
    static final SimpleSymbol Lit139;
    static final IntNum Lit14;
    static final FString Lit140;
    static final FString Lit141;
    static final SimpleSymbol Lit142;
    static final SimpleSymbol Lit143;
    static final SimpleSymbol Lit144;
    static final SimpleSymbol Lit145;
    static final SimpleSymbol Lit146;
    static final SimpleSymbol Lit147;
    static final FString Lit148;
    static final FString Lit149;
    static final SimpleSymbol Lit15;
    static final FString Lit150;
    static final FString Lit151;
    static final IntNum Lit152;
    static final FString Lit153;
    static final FString Lit154;
    static final SimpleSymbol Lit155;
    static final SimpleSymbol Lit156;
    static final FString Lit157;
    static final SimpleSymbol Lit158;
    static final SimpleSymbol Lit159;
    static final IntNum Lit16;
    static final SimpleSymbol Lit160;
    static final PairWithPosition Lit161;
    static final PairWithPosition Lit162 = PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1216890), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1216884);
    static final SimpleSymbol Lit163;
    static final SimpleSymbol Lit164;
    static final FString Lit165;
    static final SimpleSymbol Lit166;
    static final FString Lit167;
    static final PairWithPosition Lit168 = PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1245301), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1245295);
    static final PairWithPosition Lit169 = PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1245413), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1245407);
    static final SimpleSymbol Lit17;
    static final SimpleSymbol Lit170;
    static final PairWithPosition Lit171 = PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1245652), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1245647), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1245641);
    static final PairWithPosition Lit172 = PairWithPosition.make(Lit7, PairWithPosition.make(Lit204, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1245675), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1245669);
    static final PairWithPosition Lit173 = PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1245795), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1245789);
    static final PairWithPosition Lit174 = PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1245907), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1245901);
    static final PairWithPosition Lit175 = PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1246146), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1246141), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1246135);
    static final PairWithPosition Lit176 = PairWithPosition.make(Lit7, PairWithPosition.make(Lit204, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1246169), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1246163);
    static final PairWithPosition Lit177 = PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1246292), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1246286);
    static final PairWithPosition Lit178 = PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1246404), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1246398);
    static final PairWithPosition Lit179 = PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1246643), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1246638), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1246632);
    static final SimpleSymbol Lit18;
    static final PairWithPosition Lit180 = PairWithPosition.make(Lit7, PairWithPosition.make(Lit204, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1246666), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1246660);
    static final PairWithPosition Lit181 = PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1246787), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1246781);
    static final PairWithPosition Lit182 = PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1246899), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1246893);
    static final PairWithPosition Lit183 = PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1247138), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1247133), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1247127);
    static final PairWithPosition Lit184 = PairWithPosition.make(Lit7, PairWithPosition.make(Lit204, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1247161), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1247155);
    static final PairWithPosition Lit185 = PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1247282), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1247276);
    static final PairWithPosition Lit186 = PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1247394), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1247388);
    static final PairWithPosition Lit187 = PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1247633), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1247628), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1247622);
    static final PairWithPosition Lit188;
    static final SimpleSymbol Lit189;
    static final SimpleSymbol Lit19;
    static final SimpleSymbol Lit190;
    static final SimpleSymbol Lit191;
    static final SimpleSymbol Lit192;
    static final SimpleSymbol Lit193;
    static final SimpleSymbol Lit194;
    static final SimpleSymbol Lit195;
    static final SimpleSymbol Lit196;
    static final SimpleSymbol Lit197;
    static final SimpleSymbol Lit198;
    static final SimpleSymbol Lit199;
    static final SimpleSymbol Lit2;
    static final SimpleSymbol Lit20;
    static final SimpleSymbol Lit200;
    static final SimpleSymbol Lit201;
    static final SimpleSymbol Lit202;
    static final SimpleSymbol Lit203;
    static final SimpleSymbol Lit204;
    static final SimpleSymbol Lit21;
    static final PairWithPosition Lit22 = PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 94301);
    static final SimpleSymbol Lit23;
    static final SimpleSymbol Lit24;
    static final FString Lit25;
    static final SimpleSymbol Lit26;
    static final SimpleSymbol Lit27;
    static final IntNum Lit28;
    static final SimpleSymbol Lit29;
    static final SimpleSymbol Lit3;
    static final SimpleSymbol Lit30;
    static final IntNum Lit31 = IntNum.make(25);
    static final SimpleSymbol Lit32;
    static final IntNum Lit33 = IntNum.make(75);
    static final SimpleSymbol Lit34;
    static final IntNum Lit35 = IntNum.make(-2);
    static final SimpleSymbol Lit36;
    static final IntNum Lit37 = IntNum.make(2);
    static final SimpleSymbol Lit38;
    static final FString Lit39;
    static final IntNum Lit4;
    static final SimpleSymbol Lit40;
    static final SimpleSymbol Lit41;
    static final SimpleSymbol Lit42;
    static final SimpleSymbol Lit43;
    static final SimpleSymbol Lit44;
    static final SimpleSymbol Lit45;
    static final SimpleSymbol Lit46;
    static final SimpleSymbol Lit47;
    static final PairWithPosition Lit48 = PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 196777);
    static final SimpleSymbol Lit49;
    static final SimpleSymbol Lit5;
    static final SimpleSymbol Lit50;
    static final FString Lit51;
    static final SimpleSymbol Lit52;
    static final IntNum Lit53 = IntNum.make(100);
    static final FString Lit54;
    static final FString Lit55;
    static final SimpleSymbol Lit56;
    static final SimpleSymbol Lit57;
    static final IntNum Lit58 = IntNum.make(5);
    static final IntNum Lit59 = IntNum.make(50);
    static final SimpleSymbol Lit6;
    static final SimpleSymbol Lit60;
    static final SimpleSymbol Lit61;
    static final IntNum Lit62;
    static final SimpleSymbol Lit63;
    static final SimpleSymbol Lit64;
    static final IntNum Lit65 = IntNum.make(1);
    static final SimpleSymbol Lit66;
    static final IntNum Lit67;
    static final FString Lit68;
    static final FString Lit69;
    static final SimpleSymbol Lit7;
    static final SimpleSymbol Lit70;
    static final FString Lit71;
    static final FString Lit72;
    static final SimpleSymbol Lit73;
    static final IntNum Lit74 = IntNum.make(16777215);
    static final IntNum Lit75 = IntNum.make(155);
    static final FString Lit76;
    static final FString Lit77;
    static final SimpleSymbol Lit78;
    static final IntNum Lit79;
    static final SimpleSymbol Lit8;
    static final FString Lit80;
    static final FString Lit81;
    static final SimpleSymbol Lit82;
    static final IntNum Lit83;
    static final IntNum Lit84 = IntNum.make(150);
    static final IntNum Lit85 = IntNum.make(3);
    static final IntNum Lit86;
    static final FString Lit87;
    static final PairWithPosition Lit88 = PairWithPosition.make(Lit204, PairWithPosition.make(Lit204, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 557160), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 557155);
    static final PairWithPosition Lit89 = PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 557260);
    static final SimpleSymbol Lit9;
    static final PairWithPosition Lit90 = PairWithPosition.make(Lit204, PairWithPosition.make(Lit204, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 557372), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 557367);
    static final SimpleSymbol Lit91;
    static final PairWithPosition Lit92 = PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 557469);
    static final SimpleSymbol Lit93;
    static final PairWithPosition Lit94 = PairWithPosition.make(Lit204, PairWithPosition.make(Lit204, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 557642), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 557637);
    static final PairWithPosition Lit95 = PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 557739);
    static final PairWithPosition Lit96 = PairWithPosition.make(Lit204, PairWithPosition.make(Lit204, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 557913), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 557908);
    static final PairWithPosition Lit97 = PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 558010);
    static final PairWithPosition Lit98 = PairWithPosition.make(Lit204, PairWithPosition.make(Lit204, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 558187), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 558182);
    static final PairWithPosition Lit99 = PairWithPosition.make(Lit7, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 558284);
    public static Screen1 Screen1;
    static final ModuleMethod lambda$Fn1 = null;
    static final ModuleMethod lambda$Fn10 = null;
    static final ModuleMethod lambda$Fn11 = null;
    static final ModuleMethod lambda$Fn12 = null;
    static final ModuleMethod lambda$Fn13 = null;
    static final ModuleMethod lambda$Fn14 = null;
    static final ModuleMethod lambda$Fn15 = null;
    static final ModuleMethod lambda$Fn16 = null;
    static final ModuleMethod lambda$Fn17 = null;
    static final ModuleMethod lambda$Fn18 = null;
    static final ModuleMethod lambda$Fn19 = null;
    static final ModuleMethod lambda$Fn2 = null;
    static final ModuleMethod lambda$Fn20 = null;
    static final ModuleMethod lambda$Fn21 = null;
    static final ModuleMethod lambda$Fn22 = null;
    static final ModuleMethod lambda$Fn23 = null;
    static final ModuleMethod lambda$Fn24 = null;
    static final ModuleMethod lambda$Fn25 = null;
    static final ModuleMethod lambda$Fn26 = null;
    static final ModuleMethod lambda$Fn27 = null;
    static final ModuleMethod lambda$Fn28 = null;
    static final ModuleMethod lambda$Fn29 = null;
    static final ModuleMethod lambda$Fn3 = null;
    static final ModuleMethod lambda$Fn30 = null;
    static final ModuleMethod lambda$Fn31 = null;
    static final ModuleMethod lambda$Fn32 = null;
    static final ModuleMethod lambda$Fn33 = null;
    static final ModuleMethod lambda$Fn34 = null;
    static final ModuleMethod lambda$Fn35 = null;
    static final ModuleMethod lambda$Fn36 = null;
    static final ModuleMethod lambda$Fn37 = null;
    static final ModuleMethod lambda$Fn38 = null;
    static final ModuleMethod lambda$Fn39 = null;
    static final ModuleMethod lambda$Fn4 = null;
    static final ModuleMethod lambda$Fn40 = null;
    static final ModuleMethod lambda$Fn41 = null;
    static final ModuleMethod lambda$Fn42 = null;
    static final ModuleMethod lambda$Fn43 = null;
    static final ModuleMethod lambda$Fn44 = null;
    static final ModuleMethod lambda$Fn45 = null;
    static final ModuleMethod lambda$Fn46 = null;
    static final ModuleMethod lambda$Fn47 = null;
    static final ModuleMethod lambda$Fn48 = null;
    static final ModuleMethod lambda$Fn49 = null;
    static final ModuleMethod lambda$Fn5 = null;
    static final ModuleMethod lambda$Fn50 = null;
    static final ModuleMethod lambda$Fn6 = null;
    static final ModuleMethod lambda$Fn7 = null;
    static final ModuleMethod lambda$Fn8 = null;
    static final ModuleMethod lambda$Fn9 = null;
    public Boolean $Stdebug$Mnform$St;
    public final ModuleMethod $define;
    public BluetoothClient Bluetooth_Client1;
    public Button Button1;
    public final ModuleMethod Button1$Click;
    public Button Button2;
    public final ModuleMethod Button2$Click;
    public Clock Clock1;
    public final ModuleMethod Clock1$Timer;
    public Clock Clock2;
    public final ModuleMethod Clock2$Timer;
    public FirebaseDB Firebase_Database1;
    public HorizontalArrangement Horizontal_Arrangement3;
    public HorizontalArrangement Horizontal_Arrangement4;
    public HorizontalArrangement Horizontal_Arrangement5;
    public HorizontalArrangement Horizontal_Arrangement6;
    public HorizontalArrangement Horizontal_Arrangement7;
    public HorizontalArrangement Horizontal_Arrangement8;
    public Label Label1;
    public Label Label3;
    public ListPicker List_Picker1;
    public final ModuleMethod List_Picker1$AfterPicking;
    public final ModuleMethod List_Picker1$BeforePicking;
    public final ModuleMethod Screen1$ErrorOccurred;
    public MakeroidSnackbar Snackbar1;
    public SpaceView Space2;
    public SpaceView Space3;
    public SpaceView Space4;
    public SpaceView Space5;
    public TextBox Text_Box1;
    public final ModuleMethod add$Mnto$Mncomponents;
    public final ModuleMethod add$Mnto$Mnevents;
    public final ModuleMethod add$Mnto$Mnform$Mndo$Mnafter$Mncreation;
    public final ModuleMethod add$Mnto$Mnform$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvar$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvars;
    public final ModuleMethod android$Mnlog$Mnform;
    public LList components$Mnto$Mncreate;
    public final ModuleMethod dispatchEvent;
    public final ModuleMethod dispatchGenericEvent;
    public LList events$Mnto$Mnregister;
    public LList form$Mndo$Mnafter$Mncreation;
    public Environment form$Mnenvironment;
    public Symbol form$Mnname$Mnsymbol;
    public final ModuleMethod get$Mnsimple$Mnname;
    public Environment global$Mnvar$Mnenvironment;
    public LList global$Mnvars$Mnto$Mncreate;
    public final ModuleMethod is$Mnbound$Mnin$Mnform$Mnenvironment;
    public final ModuleMethod lookup$Mnhandler;
    public final ModuleMethod lookup$Mnin$Mnform$Mnenvironment;
    public final ModuleMethod process$Mnexception;
    public final ModuleMethod send$Mnerror;

    /* renamed from: io.kodular.poddarrupak2808.HackUMass.Screen1$frame */
    /* compiled from: Screen1.yail */
    public class frame extends ModuleBody {
        Screen1 $main = this;

        public frame() {
        }

        public int match1(ModuleMethod moduleMethod, Object obj, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj2 = obj;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 1:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 1;
                    return 0;
                case 2:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 1;
                    return 0;
                case 4:
                    CallContext callContext3 = callContext2;
                    Object obj3 = obj2;
                    Object obj4 = obj3;
                    if (!(obj3 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext3.value1 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 1;
                    return 0;
                case 6:
                    CallContext callContext4 = callContext2;
                    Object obj5 = obj2;
                    Object obj6 = obj5;
                    if (!(obj5 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext4.value1 = obj6;
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 1;
                    return 0;
                case 11:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 1;
                    return 0;
                case 12:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 1;
                    return 0;
                case 13:
                    CallContext callContext5 = callContext2;
                    Object obj7 = obj2;
                    Object obj8 = obj7;
                    if (!(obj7 instanceof Screen1)) {
                        return -786431;
                    }
                    callContext5.value1 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 1;
                    return 0;
                case 24:
                    callContext2.value1 = obj2;
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 1;
                    return 0;
                default:
                    return super.match1(moduleMethod2, obj2, callContext2);
            }
        }

        public int match2(ModuleMethod moduleMethod, Object obj, Object obj2, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj3 = obj;
            Object obj4 = obj2;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 3:
                    CallContext callContext3 = callContext2;
                    Object obj5 = obj3;
                    Object obj6 = obj5;
                    if (!(obj5 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext3.value1 = obj6;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 2;
                    return 0;
                case 4:
                    CallContext callContext4 = callContext2;
                    Object obj7 = obj3;
                    Object obj8 = obj7;
                    if (!(obj7 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext4.value1 = obj8;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 2;
                    return 0;
                case 7:
                    CallContext callContext5 = callContext2;
                    Object obj9 = obj3;
                    Object obj10 = obj9;
                    if (!(obj9 instanceof Symbol)) {
                        return -786431;
                    }
                    callContext5.value1 = obj10;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 2;
                    return 0;
                case 8:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 2;
                    return 0;
                case 10:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 2;
                    return 0;
                case 16:
                    callContext2.value1 = obj3;
                    callContext2.value2 = obj4;
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 2;
                    return 0;
                default:
                    return super.match2(moduleMethod2, obj3, obj4, callContext2);
            }
        }

        public int match4(ModuleMethod moduleMethod, Object obj, Object obj2, Object obj3, Object obj4, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj5 = obj;
            Object obj6 = obj2;
            Object obj7 = obj3;
            Object obj8 = obj4;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 9:
                    callContext2.value1 = obj5;
                    callContext2.value2 = obj6;
                    callContext2.value3 = obj7;
                    callContext2.value4 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 4;
                    return 0;
                case 14:
                    CallContext callContext3 = callContext2;
                    Object obj9 = obj5;
                    Object obj10 = obj9;
                    if (!(obj9 instanceof Screen1)) {
                        return -786431;
                    }
                    callContext3.value1 = obj10;
                    CallContext callContext4 = callContext2;
                    Object obj11 = obj6;
                    Object obj12 = obj11;
                    if (!(obj11 instanceof Component)) {
                        return -786430;
                    }
                    callContext4.value2 = obj12;
                    CallContext callContext5 = callContext2;
                    Object obj13 = obj7;
                    Object obj14 = obj13;
                    if (!(obj13 instanceof String)) {
                        return -786429;
                    }
                    callContext5.value3 = obj14;
                    CallContext callContext6 = callContext2;
                    Object obj15 = obj8;
                    Object obj16 = obj15;
                    if (!(obj15 instanceof String)) {
                        return -786428;
                    }
                    callContext6.value4 = obj16;
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 4;
                    return 0;
                case 15:
                    CallContext callContext7 = callContext2;
                    Object obj17 = obj5;
                    Object obj18 = obj17;
                    if (!(obj17 instanceof Screen1)) {
                        return -786431;
                    }
                    callContext7.value1 = obj18;
                    CallContext callContext8 = callContext2;
                    Object obj19 = obj6;
                    Object obj20 = obj19;
                    if (!(obj19 instanceof Component)) {
                        return -786430;
                    }
                    callContext8.value2 = obj20;
                    CallContext callContext9 = callContext2;
                    Object obj21 = obj7;
                    Object obj22 = obj21;
                    if (!(obj21 instanceof String)) {
                        return -786429;
                    }
                    callContext9.value3 = obj22;
                    CallContext callContext10 = callContext2;
                    Object obj23 = obj8;
                    Object obj24 = obj23;
                    Object obj25 = obj23;
                    if (1 == 0) {
                        return -786428;
                    }
                    callContext10.value4 = obj24;
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 4;
                    return 0;
                case 20:
                    callContext2.value1 = obj5;
                    callContext2.value2 = obj6;
                    callContext2.value3 = obj7;
                    callContext2.value4 = obj8;
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 4;
                    return 0;
                default:
                    return super.match4(moduleMethod2, obj5, obj6, obj7, obj8, callContext2);
            }
        }

        public Object apply1(ModuleMethod moduleMethod, Object obj) {
            WrongType wrongType;
            WrongType wrongType2;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj2 = obj;
            switch (moduleMethod2.selector) {
                case 1:
                    return this.$main.getSimpleName(obj2);
                case 2:
                    this.$main.androidLogForm(obj2);
                    return Values.empty;
                case 4:
                    try {
                        return this.$main.lookupInFormEnvironment((Symbol) obj2);
                    } catch (ClassCastException e) {
                        ClassCastException classCastException = e;
                        WrongType wrongType3 = wrongType2;
                        WrongType wrongType4 = new WrongType(classCastException, "lookup-in-form-environment", 1, obj2);
                        throw wrongType3;
                    }
                case 6:
                    try {
                        return this.$main.isBoundInFormEnvironment((Symbol) obj2) ? Boolean.TRUE : Boolean.FALSE;
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        WrongType wrongType5 = wrongType;
                        WrongType wrongType6 = new WrongType(classCastException2, "is-bound-in-form-environment", 1, obj2);
                        throw wrongType5;
                    }
                case 11:
                    this.$main.addToFormDoAfterCreation(obj2);
                    return Values.empty;
                case 12:
                    this.$main.sendError(obj2);
                    return Values.empty;
                case 13:
                    this.$main.processException(obj2);
                    return Values.empty;
                case 24:
                    return this.$main.List_Picker1$AfterPicking(obj2);
                default:
                    return super.apply1(moduleMethod2, obj2);
            }
        }

        public Object apply4(ModuleMethod moduleMethod, Object obj, Object obj2, Object obj3, Object obj4) {
            WrongType wrongType;
            WrongType wrongType2;
            WrongType wrongType3;
            WrongType wrongType4;
            WrongType wrongType5;
            WrongType wrongType6;
            WrongType wrongType7;
            WrongType wrongType8;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj5 = obj;
            Object obj6 = obj2;
            Object obj7 = obj3;
            Object obj8 = obj4;
            switch (moduleMethod2.selector) {
                case 9:
                    this.$main.addToComponents(obj5, obj6, obj7, obj8);
                    return Values.empty;
                case 14:
                    try {
                        try {
                            try {
                                try {
                                    return this.$main.dispatchEvent((Component) obj5, (String) obj6, (String) obj7, (Object[]) obj8) ? Boolean.TRUE : Boolean.FALSE;
                                } catch (ClassCastException e) {
                                    ClassCastException classCastException = e;
                                    WrongType wrongType9 = wrongType8;
                                    WrongType wrongType10 = new WrongType(classCastException, "dispatchEvent", 4, obj8);
                                    throw wrongType9;
                                }
                            } catch (ClassCastException e2) {
                                ClassCastException classCastException2 = e2;
                                WrongType wrongType11 = wrongType7;
                                WrongType wrongType12 = new WrongType(classCastException2, "dispatchEvent", 3, obj7);
                                throw wrongType11;
                            }
                        } catch (ClassCastException e3) {
                            ClassCastException classCastException3 = e3;
                            WrongType wrongType13 = wrongType6;
                            WrongType wrongType14 = new WrongType(classCastException3, "dispatchEvent", 2, obj6);
                            throw wrongType13;
                        }
                    } catch (ClassCastException e4) {
                        ClassCastException classCastException4 = e4;
                        WrongType wrongType15 = wrongType5;
                        WrongType wrongType16 = new WrongType(classCastException4, "dispatchEvent", 1, obj5);
                        throw wrongType15;
                    }
                case 15:
                    try {
                        try {
                            try {
                                try {
                                    this.$main.dispatchGenericEvent((Component) obj5, (String) obj6, obj7 != Boolean.FALSE, (Object[]) obj8);
                                    return Values.empty;
                                } catch (ClassCastException e5) {
                                    ClassCastException classCastException5 = e5;
                                    WrongType wrongType17 = wrongType4;
                                    WrongType wrongType18 = new WrongType(classCastException5, "dispatchGenericEvent", 4, obj8);
                                    throw wrongType17;
                                }
                            } catch (ClassCastException e6) {
                                ClassCastException classCastException6 = e6;
                                WrongType wrongType19 = wrongType3;
                                WrongType wrongType20 = new WrongType(classCastException6, "dispatchGenericEvent", 3, obj7);
                                throw wrongType19;
                            }
                        } catch (ClassCastException e7) {
                            ClassCastException classCastException7 = e7;
                            WrongType wrongType21 = wrongType2;
                            WrongType wrongType22 = new WrongType(classCastException7, "dispatchGenericEvent", 2, obj6);
                            throw wrongType21;
                        }
                    } catch (ClassCastException e8) {
                        ClassCastException classCastException8 = e8;
                        WrongType wrongType23 = wrongType;
                        WrongType wrongType24 = new WrongType(classCastException8, "dispatchGenericEvent", 1, obj5);
                        throw wrongType23;
                    }
                case 20:
                    return this.$main.Screen1$ErrorOccurred(obj5, obj6, obj7, obj8);
                default:
                    return super.apply4(moduleMethod2, obj5, obj6, obj7, obj8);
            }
        }

        public Object apply2(ModuleMethod moduleMethod, Object obj, Object obj2) {
            WrongType wrongType;
            WrongType wrongType2;
            WrongType wrongType3;
            ModuleMethod moduleMethod2 = moduleMethod;
            Object obj3 = obj;
            Object obj4 = obj2;
            switch (moduleMethod2.selector) {
                case 3:
                    try {
                        this.$main.addToFormEnvironment((Symbol) obj3, obj4);
                        return Values.empty;
                    } catch (ClassCastException e) {
                        ClassCastException classCastException = e;
                        WrongType wrongType4 = wrongType3;
                        WrongType wrongType5 = new WrongType(classCastException, "add-to-form-environment", 1, obj3);
                        throw wrongType4;
                    }
                case 4:
                    try {
                        return this.$main.lookupInFormEnvironment((Symbol) obj3, obj4);
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        WrongType wrongType6 = wrongType2;
                        WrongType wrongType7 = new WrongType(classCastException2, "lookup-in-form-environment", 1, obj3);
                        throw wrongType6;
                    }
                case 7:
                    try {
                        this.$main.addToGlobalVarEnvironment((Symbol) obj3, obj4);
                        return Values.empty;
                    } catch (ClassCastException e3) {
                        ClassCastException classCastException3 = e3;
                        WrongType wrongType8 = wrongType;
                        WrongType wrongType9 = new WrongType(classCastException3, "add-to-global-var-environment", 1, obj3);
                        throw wrongType8;
                    }
                case 8:
                    this.$main.addToEvents(obj3, obj4);
                    return Values.empty;
                case 10:
                    this.$main.addToGlobalVars(obj3, obj4);
                    return Values.empty;
                case 16:
                    return this.$main.lookupHandler(obj3, obj4);
                default:
                    return super.apply2(moduleMethod2, obj3, obj4);
            }
        }

        public Object apply0(ModuleMethod moduleMethod) {
            ModuleMethod moduleMethod2 = moduleMethod;
            switch (moduleMethod2.selector) {
                case 17:
                    return Screen1.lambda2();
                case 18:
                    this.$main.$define();
                    return Values.empty;
                case 19:
                    return Screen1.lambda3();
                case 21:
                    return Screen1.lambda4();
                case 22:
                    return Screen1.lambda5();
                case 23:
                    return this.$main.List_Picker1$BeforePicking();
                case 25:
                    return Screen1.lambda6();
                case 26:
                    return Screen1.lambda7();
                case 27:
                    return Screen1.lambda8();
                case 28:
                    return Screen1.lambda9();
                case 29:
                    return Screen1.lambda10();
                case 30:
                    return Screen1.lambda11();
                case 31:
                    return Screen1.lambda12();
                case 32:
                    return Screen1.lambda13();
                case 33:
                    return Screen1.lambda14();
                case 34:
                    return Screen1.lambda15();
                case 35:
                    return Screen1.lambda16();
                case 36:
                    return Screen1.lambda17();
                case 37:
                    return this.$main.Button1$Click();
                case 38:
                    return Screen1.lambda18();
                case 39:
                    return Screen1.lambda19();
                case 40:
                    return Screen1.lambda20();
                case 41:
                    return Screen1.lambda21();
                case 42:
                    return Screen1.lambda22();
                case 43:
                    return Screen1.lambda23();
                case 44:
                    return Screen1.lambda24();
                case 45:
                    return Screen1.lambda25();
                case 46:
                    return this.$main.Button2$Click();
                case 47:
                    return Screen1.lambda26();
                case 48:
                    return Screen1.lambda27();
                case 49:
                    return Screen1.lambda28();
                case 50:
                    return Screen1.lambda29();
                case 51:
                    return Screen1.lambda30();
                case 52:
                    return Screen1.lambda31();
                case 53:
                    return Screen1.lambda32();
                case 54:
                    return Screen1.lambda33();
                case 55:
                    return Screen1.lambda34();
                case 56:
                    return Screen1.lambda35();
                case 57:
                    return Screen1.lambda36();
                case 58:
                    return Screen1.lambda37();
                case 59:
                    return Screen1.lambda38();
                case 60:
                    return Screen1.lambda39();
                case 61:
                    return Screen1.lambda40();
                case 62:
                    return Screen1.lambda41();
                case 63:
                    return this.$main.Clock1$Timer();
                case 64:
                    return Screen1.lambda42();
                case 65:
                    return Screen1.lambda43();
                case 66:
                    return Screen1.lambda44();
                case 67:
                    return Screen1.lambda45();
                case 68:
                    return Screen1.lambda46();
                case 69:
                    return Screen1.lambda47();
                case 70:
                    return Screen1.lambda48();
                case 71:
                    return Screen1.lambda49();
                case 72:
                    return Screen1.lambda50();
                case 73:
                    return Screen1.lambda51();
                case 74:
                    return this.$main.Clock2$Timer();
                default:
                    return super.apply0(moduleMethod2);
            }
        }

        public int match0(ModuleMethod moduleMethod, CallContext callContext) {
            ModuleMethod moduleMethod2 = moduleMethod;
            CallContext callContext2 = callContext;
            switch (moduleMethod2.selector) {
                case 17:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 18:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 19:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 21:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 22:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 23:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 25:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 26:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 27:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 28:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 29:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 30:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 31:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 32:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 33:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 34:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 35:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 36:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 37:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 38:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 39:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 40:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 41:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 42:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 43:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 44:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 45:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 46:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 47:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 48:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 49:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 50:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 51:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 52:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 53:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 54:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 55:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 56:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 57:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 58:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 59:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 60:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 61:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 62:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 63:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 64:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 65:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 66:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 67:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 68:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 69:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 70:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 71:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 72:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 73:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                case 74:
                    callContext2.proc = moduleMethod2;
                    callContext2.f239pc = 0;
                    return 0;
                default:
                    return super.match0(moduleMethod2, callContext2);
            }
        }
    }

    static {
        SimpleSymbol simpleSymbol;
        SimpleSymbol simpleSymbol2;
        SimpleSymbol simpleSymbol3;
        SimpleSymbol simpleSymbol4;
        SimpleSymbol simpleSymbol5;
        SimpleSymbol simpleSymbol6;
        SimpleSymbol simpleSymbol7;
        SimpleSymbol simpleSymbol8;
        SimpleSymbol simpleSymbol9;
        SimpleSymbol simpleSymbol10;
        SimpleSymbol simpleSymbol11;
        SimpleSymbol simpleSymbol12;
        SimpleSymbol simpleSymbol13;
        SimpleSymbol simpleSymbol14;
        SimpleSymbol simpleSymbol15;
        SimpleSymbol simpleSymbol16;
        SimpleSymbol simpleSymbol17;
        SimpleSymbol simpleSymbol18;
        FString fString;
        SimpleSymbol simpleSymbol19;
        FString fString2;
        SimpleSymbol simpleSymbol20;
        SimpleSymbol simpleSymbol21;
        SimpleSymbol simpleSymbol22;
        SimpleSymbol simpleSymbol23;
        SimpleSymbol simpleSymbol24;
        SimpleSymbol simpleSymbol25;
        FString fString3;
        SimpleSymbol simpleSymbol26;
        SimpleSymbol simpleSymbol27;
        FString fString4;
        FString fString5;
        FString fString6;
        FString fString7;
        FString fString8;
        FString fString9;
        SimpleSymbol simpleSymbol28;
        SimpleSymbol simpleSymbol29;
        SimpleSymbol simpleSymbol30;
        SimpleSymbol simpleSymbol31;
        SimpleSymbol simpleSymbol32;
        SimpleSymbol simpleSymbol33;
        FString fString10;
        FString fString11;
        SimpleSymbol simpleSymbol34;
        FString fString12;
        FString fString13;
        FString fString14;
        FString fString15;
        FString fString16;
        FString fString17;
        SimpleSymbol simpleSymbol35;
        FString fString18;
        FString fString19;
        SimpleSymbol simpleSymbol36;
        FString fString20;
        SimpleSymbol simpleSymbol37;
        FString fString21;
        SimpleSymbol simpleSymbol38;
        FString fString22;
        FString fString23;
        SimpleSymbol simpleSymbol39;
        FString fString24;
        FString fString25;
        FString fString26;
        FString fString27;
        SimpleSymbol simpleSymbol40;
        FString fString28;
        SimpleSymbol simpleSymbol41;
        SimpleSymbol simpleSymbol42;
        SimpleSymbol simpleSymbol43;
        SimpleSymbol simpleSymbol44;
        SimpleSymbol simpleSymbol45;
        SimpleSymbol simpleSymbol46;
        SimpleSymbol simpleSymbol47;
        FString fString29;
        SimpleSymbol simpleSymbol48;
        FString fString30;
        FString fString31;
        SimpleSymbol simpleSymbol49;
        FString fString32;
        FString fString33;
        SimpleSymbol simpleSymbol50;
        FString fString34;
        FString fString35;
        SimpleSymbol simpleSymbol51;
        FString fString36;
        FString fString37;
        SimpleSymbol simpleSymbol52;
        SimpleSymbol simpleSymbol53;
        SimpleSymbol simpleSymbol54;
        SimpleSymbol simpleSymbol55;
        SimpleSymbol simpleSymbol56;
        SimpleSymbol simpleSymbol57;
        SimpleSymbol simpleSymbol58;
        FString fString38;
        FString fString39;
        SimpleSymbol simpleSymbol59;
        FString fString40;
        SimpleSymbol simpleSymbol60;
        SimpleSymbol simpleSymbol61;
        SimpleSymbol simpleSymbol62;
        SimpleSymbol simpleSymbol63;
        SimpleSymbol simpleSymbol64;
        SimpleSymbol simpleSymbol65;
        SimpleSymbol simpleSymbol66;
        SimpleSymbol simpleSymbol67;
        SimpleSymbol simpleSymbol68;
        SimpleSymbol simpleSymbol69;
        FString fString41;
        SimpleSymbol simpleSymbol70;
        SimpleSymbol simpleSymbol71;
        SimpleSymbol simpleSymbol72;
        SimpleSymbol simpleSymbol73;
        SimpleSymbol simpleSymbol74;
        SimpleSymbol simpleSymbol75;
        SimpleSymbol simpleSymbol76;
        SimpleSymbol simpleSymbol77;
        FString fString42;
        SimpleSymbol simpleSymbol78;
        SimpleSymbol simpleSymbol79;
        SimpleSymbol simpleSymbol80;
        SimpleSymbol simpleSymbol81;
        SimpleSymbol simpleSymbol82;
        SimpleSymbol simpleSymbol83;
        SimpleSymbol simpleSymbol84;
        SimpleSymbol simpleSymbol85;
        SimpleSymbol simpleSymbol86;
        SimpleSymbol simpleSymbol87;
        SimpleSymbol simpleSymbol88;
        SimpleSymbol simpleSymbol89;
        SimpleSymbol simpleSymbol90;
        SimpleSymbol simpleSymbol91;
        SimpleSymbol simpleSymbol92;
        SimpleSymbol simpleSymbol93;
        SimpleSymbol simpleSymbol94;
        SimpleSymbol simpleSymbol95;
        SimpleSymbol simpleSymbol96 = simpleSymbol;
        SimpleSymbol simpleSymbol97 = new SimpleSymbol("any");
        Lit204 = (SimpleSymbol) simpleSymbol96.readResolve();
        SimpleSymbol simpleSymbol98 = simpleSymbol2;
        SimpleSymbol simpleSymbol99 = new SimpleSymbol("lookup-handler");
        Lit203 = (SimpleSymbol) simpleSymbol98.readResolve();
        SimpleSymbol simpleSymbol100 = simpleSymbol3;
        SimpleSymbol simpleSymbol101 = new SimpleSymbol("dispatchGenericEvent");
        Lit202 = (SimpleSymbol) simpleSymbol100.readResolve();
        SimpleSymbol simpleSymbol102 = simpleSymbol4;
        SimpleSymbol simpleSymbol103 = new SimpleSymbol("dispatchEvent");
        Lit201 = (SimpleSymbol) simpleSymbol102.readResolve();
        SimpleSymbol simpleSymbol104 = simpleSymbol5;
        SimpleSymbol simpleSymbol105 = new SimpleSymbol("send-error");
        Lit200 = (SimpleSymbol) simpleSymbol104.readResolve();
        SimpleSymbol simpleSymbol106 = simpleSymbol6;
        SimpleSymbol simpleSymbol107 = new SimpleSymbol("add-to-form-do-after-creation");
        Lit199 = (SimpleSymbol) simpleSymbol106.readResolve();
        SimpleSymbol simpleSymbol108 = simpleSymbol7;
        SimpleSymbol simpleSymbol109 = new SimpleSymbol("add-to-global-vars");
        Lit198 = (SimpleSymbol) simpleSymbol108.readResolve();
        SimpleSymbol simpleSymbol110 = simpleSymbol8;
        SimpleSymbol simpleSymbol111 = new SimpleSymbol("add-to-components");
        Lit197 = (SimpleSymbol) simpleSymbol110.readResolve();
        SimpleSymbol simpleSymbol112 = simpleSymbol9;
        SimpleSymbol simpleSymbol113 = new SimpleSymbol("add-to-events");
        Lit196 = (SimpleSymbol) simpleSymbol112.readResolve();
        SimpleSymbol simpleSymbol114 = simpleSymbol10;
        SimpleSymbol simpleSymbol115 = new SimpleSymbol("add-to-global-var-environment");
        Lit195 = (SimpleSymbol) simpleSymbol114.readResolve();
        SimpleSymbol simpleSymbol116 = simpleSymbol11;
        SimpleSymbol simpleSymbol117 = new SimpleSymbol("is-bound-in-form-environment");
        Lit194 = (SimpleSymbol) simpleSymbol116.readResolve();
        SimpleSymbol simpleSymbol118 = simpleSymbol12;
        SimpleSymbol simpleSymbol119 = new SimpleSymbol("lookup-in-form-environment");
        Lit193 = (SimpleSymbol) simpleSymbol118.readResolve();
        SimpleSymbol simpleSymbol120 = simpleSymbol13;
        SimpleSymbol simpleSymbol121 = new SimpleSymbol("add-to-form-environment");
        Lit192 = (SimpleSymbol) simpleSymbol120.readResolve();
        SimpleSymbol simpleSymbol122 = simpleSymbol14;
        SimpleSymbol simpleSymbol123 = new SimpleSymbol("android-log-form");
        Lit191 = (SimpleSymbol) simpleSymbol122.readResolve();
        SimpleSymbol simpleSymbol124 = simpleSymbol15;
        SimpleSymbol simpleSymbol125 = new SimpleSymbol("get-simple-name");
        Lit190 = (SimpleSymbol) simpleSymbol124.readResolve();
        SimpleSymbol simpleSymbol126 = simpleSymbol16;
        SimpleSymbol simpleSymbol127 = new SimpleSymbol("Clock2$Timer");
        Lit189 = (SimpleSymbol) simpleSymbol126.readResolve();
        SimpleSymbol simpleSymbol128 = simpleSymbol17;
        SimpleSymbol simpleSymbol129 = new SimpleSymbol(PropertyTypeConstants.PROPERTY_TYPE_TEXT);
        SimpleSymbol simpleSymbol130 = (SimpleSymbol) simpleSymbol128.readResolve();
        SimpleSymbol simpleSymbol131 = simpleSymbol130;
        Lit7 = simpleSymbol130;
        Lit188 = PairWithPosition.make(simpleSymbol131, PairWithPosition.make(Lit204, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1247656), "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1247650);
        SimpleSymbol simpleSymbol132 = simpleSymbol18;
        SimpleSymbol simpleSymbol133 = new SimpleSymbol("StoreValue");
        Lit170 = (SimpleSymbol) simpleSymbol132.readResolve();
        FString fString43 = fString;
        FString fString44 = new FString("com.google.appinventor.components.runtime.Clock");
        Lit167 = fString43;
        SimpleSymbol simpleSymbol134 = simpleSymbol19;
        SimpleSymbol simpleSymbol135 = new SimpleSymbol("Clock2");
        Lit166 = (SimpleSymbol) simpleSymbol134.readResolve();
        FString fString45 = fString2;
        FString fString46 = new FString("com.google.appinventor.components.runtime.Clock");
        Lit165 = fString45;
        SimpleSymbol simpleSymbol136 = simpleSymbol20;
        SimpleSymbol simpleSymbol137 = new SimpleSymbol("Timer");
        Lit164 = (SimpleSymbol) simpleSymbol136.readResolve();
        SimpleSymbol simpleSymbol138 = simpleSymbol21;
        SimpleSymbol simpleSymbol139 = new SimpleSymbol("Clock1$Timer");
        Lit163 = (SimpleSymbol) simpleSymbol138.readResolve();
        SimpleSymbol simpleSymbol140 = simpleSymbol22;
        SimpleSymbol simpleSymbol141 = new SimpleSymbol("number");
        SimpleSymbol simpleSymbol142 = (SimpleSymbol) simpleSymbol140.readResolve();
        SimpleSymbol simpleSymbol143 = simpleSymbol142;
        Lit5 = simpleSymbol142;
        Lit161 = PairWithPosition.make(simpleSymbol143, LList.Empty, "/tmp/1571549306848_0.9154310174162688-0/youngandroidproject/../src/io/kodular/poddarrupak2808/HackUMass/Screen1.yail", 1216871);
        SimpleSymbol simpleSymbol144 = simpleSymbol23;
        SimpleSymbol simpleSymbol145 = new SimpleSymbol("BytesAvailableToReceive");
        Lit160 = (SimpleSymbol) simpleSymbol144.readResolve();
        SimpleSymbol simpleSymbol146 = simpleSymbol24;
        SimpleSymbol simpleSymbol147 = new SimpleSymbol("ReceiveText");
        Lit159 = (SimpleSymbol) simpleSymbol146.readResolve();
        SimpleSymbol simpleSymbol148 = simpleSymbol25;
        SimpleSymbol simpleSymbol149 = new SimpleSymbol("IsConnected");
        Lit158 = (SimpleSymbol) simpleSymbol148.readResolve();
        FString fString47 = fString3;
        FString fString48 = new FString("com.google.appinventor.components.runtime.Clock");
        Lit157 = fString47;
        SimpleSymbol simpleSymbol150 = simpleSymbol26;
        SimpleSymbol simpleSymbol151 = new SimpleSymbol("TimerInterval");
        Lit156 = (SimpleSymbol) simpleSymbol150.readResolve();
        SimpleSymbol simpleSymbol152 = simpleSymbol27;
        SimpleSymbol simpleSymbol153 = new SimpleSymbol("Clock1");
        Lit155 = (SimpleSymbol) simpleSymbol152.readResolve();
        FString fString49 = fString4;
        FString fString50 = new FString("com.google.appinventor.components.runtime.Clock");
        Lit154 = fString49;
        FString fString51 = fString5;
        FString fString52 = new FString("com.google.appinventor.components.runtime.MakeroidSnackbar");
        Lit153 = fString51;
        int[] iArr = new int[2];
        int[] iArr2 = iArr;
        iArr[0] = -769226;
        Lit152 = IntNum.make(iArr2);
        FString fString53 = fString6;
        FString fString54 = new FString("com.google.appinventor.components.runtime.MakeroidSnackbar");
        Lit151 = fString53;
        FString fString55 = fString7;
        FString fString56 = new FString("com.google.appinventor.components.runtime.BluetoothClient");
        Lit150 = fString55;
        FString fString57 = fString8;
        FString fString58 = new FString("com.google.appinventor.components.runtime.BluetoothClient");
        Lit149 = fString57;
        FString fString59 = fString9;
        FString fString60 = new FString("com.google.appinventor.components.runtime.FirebaseDB");
        Lit148 = fString59;
        SimpleSymbol simpleSymbol154 = simpleSymbol28;
        SimpleSymbol simpleSymbol155 = new SimpleSymbol("ProjectBucket");
        Lit147 = (SimpleSymbol) simpleSymbol154.readResolve();
        SimpleSymbol simpleSymbol156 = simpleSymbol29;
        SimpleSymbol simpleSymbol157 = new SimpleSymbol("FirebaseURL");
        Lit146 = (SimpleSymbol) simpleSymbol156.readResolve();
        SimpleSymbol simpleSymbol158 = simpleSymbol30;
        SimpleSymbol simpleSymbol159 = new SimpleSymbol("FirebaseToken");
        Lit145 = (SimpleSymbol) simpleSymbol158.readResolve();
        SimpleSymbol simpleSymbol160 = simpleSymbol31;
        SimpleSymbol simpleSymbol161 = new SimpleSymbol("DeveloperBucket");
        Lit144 = (SimpleSymbol) simpleSymbol160.readResolve();
        SimpleSymbol simpleSymbol162 = simpleSymbol32;
        SimpleSymbol simpleSymbol163 = new SimpleSymbol("DefaultURL");
        Lit143 = (SimpleSymbol) simpleSymbol162.readResolve();
        SimpleSymbol simpleSymbol164 = simpleSymbol33;
        SimpleSymbol simpleSymbol165 = new SimpleSymbol("Firebase_Database1");
        Lit142 = (SimpleSymbol) simpleSymbol164.readResolve();
        FString fString61 = fString10;
        FString fString62 = new FString("com.google.appinventor.components.runtime.FirebaseDB");
        Lit141 = fString61;
        FString fString63 = fString11;
        FString fString64 = new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit140 = fString63;
        SimpleSymbol simpleSymbol166 = simpleSymbol34;
        SimpleSymbol simpleSymbol167 = new SimpleSymbol("Space5");
        Lit139 = (SimpleSymbol) simpleSymbol166.readResolve();
        FString fString65 = fString12;
        FString fString66 = new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit138 = fString65;
        FString fString67 = fString13;
        FString fString68 = new FString("com.google.appinventor.components.runtime.Label");
        Lit137 = fString67;
        int[] iArr3 = new int[2];
        int[] iArr4 = iArr3;
        iArr3[0] = -10395295;
        Lit136 = IntNum.make(iArr4);
        FString fString69 = fString14;
        FString fString70 = new FString("com.google.appinventor.components.runtime.Label");
        Lit135 = fString69;
        FString fString71 = fString15;
        FString fString72 = new FString("com.google.appinventor.components.runtime.Label");
        Lit134 = fString71;
        int[] iArr5 = new int[2];
        int[] iArr6 = iArr5;
        iArr5[0] = -10395295;
        Lit133 = IntNum.make(iArr6);
        FString fString73 = fString16;
        FString fString74 = new FString("com.google.appinventor.components.runtime.Label");
        Lit132 = fString73;
        FString fString75 = fString17;
        FString fString76 = new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit131 = fString75;
        SimpleSymbol simpleSymbol168 = simpleSymbol35;
        SimpleSymbol simpleSymbol169 = new SimpleSymbol("Space4");
        Lit130 = (SimpleSymbol) simpleSymbol168.readResolve();
        FString fString77 = fString18;
        FString fString78 = new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit129 = fString77;
        FString fString79 = fString19;
        FString fString80 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit128 = fString79;
        SimpleSymbol simpleSymbol170 = simpleSymbol36;
        SimpleSymbol simpleSymbol171 = new SimpleSymbol("Horizontal_Arrangement8");
        Lit127 = (SimpleSymbol) simpleSymbol170.readResolve();
        FString fString81 = fString20;
        FString fString82 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit126 = fString81;
        SimpleSymbol simpleSymbol172 = simpleSymbol37;
        SimpleSymbol simpleSymbol173 = new SimpleSymbol("Button2$Click");
        Lit125 = (SimpleSymbol) simpleSymbol172.readResolve();
        FString fString83 = fString21;
        FString fString84 = new FString("com.google.appinventor.components.runtime.Button");
        Lit123 = fString83;
        int[] iArr7 = new int[2];
        int[] iArr8 = iArr7;
        iArr7[0] = -10395295;
        Lit122 = IntNum.make(iArr8);
        int[] iArr9 = new int[2];
        int[] iArr10 = iArr9;
        iArr9[0] = -1118482;
        Lit121 = IntNum.make(iArr10);
        SimpleSymbol simpleSymbol174 = simpleSymbol38;
        SimpleSymbol simpleSymbol175 = new SimpleSymbol("Button2");
        Lit120 = (SimpleSymbol) simpleSymbol174.readResolve();
        FString fString85 = fString22;
        FString fString86 = new FString("com.google.appinventor.components.runtime.Button");
        Lit119 = fString85;
        FString fString87 = fString23;
        FString fString88 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit118 = fString87;
        SimpleSymbol simpleSymbol176 = simpleSymbol39;
        SimpleSymbol simpleSymbol177 = new SimpleSymbol("Horizontal_Arrangement7");
        Lit116 = (SimpleSymbol) simpleSymbol176.readResolve();
        FString fString89 = fString24;
        FString fString90 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit115 = fString89;
        FString fString91 = fString25;
        FString fString92 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit114 = fString91;
        FString fString93 = fString26;
        FString fString94 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit112 = fString93;
        FString fString95 = fString27;
        FString fString96 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit111 = fString95;
        int[] iArr11 = new int[2];
        int[] iArr12 = iArr11;
        iArr11[0] = -1;
        Lit110 = IntNum.make(iArr12);
        SimpleSymbol simpleSymbol178 = simpleSymbol40;
        SimpleSymbol simpleSymbol179 = new SimpleSymbol("Horizontal_Arrangement5");
        Lit109 = (SimpleSymbol) simpleSymbol178.readResolve();
        FString fString97 = fString28;
        FString fString98 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit108 = fString97;
        SimpleSymbol simpleSymbol180 = simpleSymbol41;
        SimpleSymbol simpleSymbol181 = new SimpleSymbol("Click");
        Lit107 = (SimpleSymbol) simpleSymbol180.readResolve();
        SimpleSymbol simpleSymbol182 = simpleSymbol42;
        SimpleSymbol simpleSymbol183 = new SimpleSymbol("Button1$Click");
        Lit106 = (SimpleSymbol) simpleSymbol182.readResolve();
        SimpleSymbol simpleSymbol184 = simpleSymbol43;
        SimpleSymbol simpleSymbol185 = new SimpleSymbol("Label3");
        Lit105 = (SimpleSymbol) simpleSymbol184.readResolve();
        SimpleSymbol simpleSymbol186 = simpleSymbol44;
        SimpleSymbol simpleSymbol187 = new SimpleSymbol("Visible");
        Lit104 = (SimpleSymbol) simpleSymbol186.readResolve();
        SimpleSymbol simpleSymbol188 = simpleSymbol45;
        SimpleSymbol simpleSymbol189 = new SimpleSymbol("Horizontal_Arrangement6");
        Lit103 = (SimpleSymbol) simpleSymbol188.readResolve();
        SimpleSymbol simpleSymbol190 = simpleSymbol46;
        SimpleSymbol simpleSymbol191 = new SimpleSymbol("Label1");
        Lit93 = (SimpleSymbol) simpleSymbol190.readResolve();
        SimpleSymbol simpleSymbol192 = simpleSymbol47;
        SimpleSymbol simpleSymbol193 = new SimpleSymbol("SendText");
        Lit91 = (SimpleSymbol) simpleSymbol192.readResolve();
        FString fString99 = fString29;
        FString fString100 = new FString("com.google.appinventor.components.runtime.Button");
        Lit87 = fString99;
        int[] iArr13 = new int[2];
        int[] iArr14 = iArr13;
        iArr13[0] = -10395295;
        Lit86 = IntNum.make(iArr14);
        int[] iArr15 = new int[2];
        int[] iArr16 = iArr15;
        iArr15[0] = -1118482;
        Lit83 = IntNum.make(iArr16);
        SimpleSymbol simpleSymbol194 = simpleSymbol48;
        SimpleSymbol simpleSymbol195 = new SimpleSymbol("Button1");
        Lit82 = (SimpleSymbol) simpleSymbol194.readResolve();
        FString fString101 = fString30;
        FString fString102 = new FString("com.google.appinventor.components.runtime.Button");
        Lit81 = fString101;
        FString fString103 = fString31;
        FString fString104 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit80 = fString103;
        int[] iArr17 = new int[2];
        int[] iArr18 = iArr17;
        iArr17[0] = -1;
        Lit79 = IntNum.make(iArr18);
        SimpleSymbol simpleSymbol196 = simpleSymbol49;
        SimpleSymbol simpleSymbol197 = new SimpleSymbol("Horizontal_Arrangement4");
        Lit78 = (SimpleSymbol) simpleSymbol196.readResolve();
        FString fString105 = fString32;
        FString fString106 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit77 = fString105;
        FString fString107 = fString33;
        FString fString108 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit76 = fString107;
        SimpleSymbol simpleSymbol198 = simpleSymbol50;
        SimpleSymbol simpleSymbol199 = new SimpleSymbol("Horizontal_Arrangement3");
        Lit73 = (SimpleSymbol) simpleSymbol198.readResolve();
        FString fString109 = fString34;
        FString fString110 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit72 = fString109;
        FString fString111 = fString35;
        FString fString112 = new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit71 = fString111;
        SimpleSymbol simpleSymbol200 = simpleSymbol51;
        SimpleSymbol simpleSymbol201 = new SimpleSymbol("Space3");
        Lit70 = (SimpleSymbol) simpleSymbol200.readResolve();
        FString fString113 = fString36;
        FString fString114 = new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit69 = fString113;
        FString fString115 = fString37;
        FString fString116 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit68 = fString115;
        int[] iArr19 = new int[2];
        int[] iArr20 = iArr19;
        iArr19[0] = -10395295;
        Lit67 = IntNum.make(iArr20);
        SimpleSymbol simpleSymbol202 = simpleSymbol52;
        SimpleSymbol simpleSymbol203 = new SimpleSymbol("TextColor");
        Lit66 = (SimpleSymbol) simpleSymbol202.readResolve();
        SimpleSymbol simpleSymbol204 = simpleSymbol53;
        SimpleSymbol simpleSymbol205 = new SimpleSymbol("TextAlignment");
        Lit64 = (SimpleSymbol) simpleSymbol204.readResolve();
        SimpleSymbol simpleSymbol206 = simpleSymbol54;
        SimpleSymbol simpleSymbol207 = new SimpleSymbol("InputType");
        Lit63 = (SimpleSymbol) simpleSymbol206.readResolve();
        int[] iArr21 = new int[2];
        int[] iArr22 = iArr21;
        iArr21[0] = -6381922;
        Lit62 = IntNum.make(iArr22);
        SimpleSymbol simpleSymbol208 = simpleSymbol55;
        SimpleSymbol simpleSymbol209 = new SimpleSymbol("HintColor");
        Lit61 = (SimpleSymbol) simpleSymbol208.readResolve();
        SimpleSymbol simpleSymbol210 = simpleSymbol56;
        SimpleSymbol simpleSymbol211 = new SimpleSymbol("Hint");
        Lit60 = (SimpleSymbol) simpleSymbol210.readResolve();
        SimpleSymbol simpleSymbol212 = simpleSymbol57;
        SimpleSymbol simpleSymbol213 = new SimpleSymbol("FontTypeface");
        Lit57 = (SimpleSymbol) simpleSymbol212.readResolve();
        SimpleSymbol simpleSymbol214 = simpleSymbol58;
        SimpleSymbol simpleSymbol215 = new SimpleSymbol("Text_Box1");
        Lit56 = (SimpleSymbol) simpleSymbol214.readResolve();
        FString fString117 = fString38;
        FString fString118 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit55 = fString117;
        FString fString119 = fString39;
        FString fString120 = new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit54 = fString119;
        SimpleSymbol simpleSymbol216 = simpleSymbol59;
        SimpleSymbol simpleSymbol217 = new SimpleSymbol("Space2");
        Lit52 = (SimpleSymbol) simpleSymbol216.readResolve();
        FString fString121 = fString40;
        FString fString122 = new FString("com.google.appinventor.components.runtime.SpaceView");
        Lit51 = fString121;
        SimpleSymbol simpleSymbol218 = simpleSymbol60;
        SimpleSymbol simpleSymbol219 = new SimpleSymbol("AfterPicking");
        Lit50 = (SimpleSymbol) simpleSymbol218.readResolve();
        SimpleSymbol simpleSymbol220 = simpleSymbol61;
        SimpleSymbol simpleSymbol221 = new SimpleSymbol("List_Picker1$AfterPicking");
        Lit49 = (SimpleSymbol) simpleSymbol220.readResolve();
        SimpleSymbol simpleSymbol222 = simpleSymbol62;
        SimpleSymbol simpleSymbol223 = new SimpleSymbol("Connect");
        Lit47 = (SimpleSymbol) simpleSymbol222.readResolve();
        SimpleSymbol simpleSymbol224 = simpleSymbol63;
        SimpleSymbol simpleSymbol225 = new SimpleSymbol("Selection");
        Lit46 = (SimpleSymbol) simpleSymbol224.readResolve();
        SimpleSymbol simpleSymbol226 = simpleSymbol64;
        SimpleSymbol simpleSymbol227 = new SimpleSymbol("BeforePicking");
        Lit45 = (SimpleSymbol) simpleSymbol226.readResolve();
        SimpleSymbol simpleSymbol228 = simpleSymbol65;
        SimpleSymbol simpleSymbol229 = new SimpleSymbol("List_Picker1$BeforePicking");
        Lit44 = (SimpleSymbol) simpleSymbol228.readResolve();
        SimpleSymbol simpleSymbol230 = simpleSymbol66;
        SimpleSymbol simpleSymbol231 = new SimpleSymbol("list");
        Lit43 = (SimpleSymbol) simpleSymbol230.readResolve();
        SimpleSymbol simpleSymbol232 = simpleSymbol67;
        SimpleSymbol simpleSymbol233 = new SimpleSymbol("AddressesAndNames");
        Lit42 = (SimpleSymbol) simpleSymbol232.readResolve();
        SimpleSymbol simpleSymbol234 = simpleSymbol68;
        SimpleSymbol simpleSymbol235 = new SimpleSymbol("Bluetooth_Client1");
        Lit41 = (SimpleSymbol) simpleSymbol234.readResolve();
        SimpleSymbol simpleSymbol236 = simpleSymbol69;
        SimpleSymbol simpleSymbol237 = new SimpleSymbol("Elements");
        Lit40 = (SimpleSymbol) simpleSymbol236.readResolve();
        FString fString123 = fString41;
        FString fString124 = new FString("com.google.appinventor.components.runtime.ListPicker");
        Lit39 = fString123;
        SimpleSymbol simpleSymbol238 = simpleSymbol70;
        SimpleSymbol simpleSymbol239 = new SimpleSymbol("Text");
        Lit38 = (SimpleSymbol) simpleSymbol238.readResolve();
        SimpleSymbol simpleSymbol240 = simpleSymbol71;
        SimpleSymbol simpleSymbol241 = new SimpleSymbol("Shape");
        Lit36 = (SimpleSymbol) simpleSymbol240.readResolve();
        SimpleSymbol simpleSymbol242 = simpleSymbol72;
        SimpleSymbol simpleSymbol243 = new SimpleSymbol("Width");
        Lit34 = (SimpleSymbol) simpleSymbol242.readResolve();
        SimpleSymbol simpleSymbol244 = simpleSymbol73;
        SimpleSymbol simpleSymbol245 = new SimpleSymbol("Height");
        Lit32 = (SimpleSymbol) simpleSymbol244.readResolve();
        SimpleSymbol simpleSymbol246 = simpleSymbol74;
        SimpleSymbol simpleSymbol247 = new SimpleSymbol("FontSize");
        Lit30 = (SimpleSymbol) simpleSymbol246.readResolve();
        SimpleSymbol simpleSymbol248 = simpleSymbol75;
        SimpleSymbol simpleSymbol249 = new SimpleSymbol("FontBold");
        Lit29 = (SimpleSymbol) simpleSymbol248.readResolve();
        int[] iArr23 = new int[2];
        int[] iArr24 = iArr23;
        iArr23[0] = -102051604;
        Lit28 = IntNum.make(iArr24);
        SimpleSymbol simpleSymbol250 = simpleSymbol76;
        SimpleSymbol simpleSymbol251 = new SimpleSymbol("BackgroundColor");
        Lit27 = (SimpleSymbol) simpleSymbol250.readResolve();
        SimpleSymbol simpleSymbol252 = simpleSymbol77;
        SimpleSymbol simpleSymbol253 = new SimpleSymbol("List_Picker1");
        Lit26 = (SimpleSymbol) simpleSymbol252.readResolve();
        FString fString125 = fString42;
        FString fString126 = new FString("com.google.appinventor.components.runtime.ListPicker");
        Lit25 = fString125;
        SimpleSymbol simpleSymbol254 = simpleSymbol78;
        SimpleSymbol simpleSymbol255 = new SimpleSymbol("ErrorOccurred");
        Lit24 = (SimpleSymbol) simpleSymbol254.readResolve();
        SimpleSymbol simpleSymbol256 = simpleSymbol79;
        SimpleSymbol simpleSymbol257 = new SimpleSymbol("Screen1$ErrorOccurred");
        Lit23 = (SimpleSymbol) simpleSymbol256.readResolve();
        SimpleSymbol simpleSymbol258 = simpleSymbol80;
        SimpleSymbol simpleSymbol259 = new SimpleSymbol("Show");
        Lit21 = (SimpleSymbol) simpleSymbol258.readResolve();
        SimpleSymbol simpleSymbol260 = simpleSymbol81;
        SimpleSymbol simpleSymbol261 = new SimpleSymbol("Snackbar1");
        Lit20 = (SimpleSymbol) simpleSymbol260.readResolve();
        SimpleSymbol simpleSymbol262 = simpleSymbol82;
        SimpleSymbol simpleSymbol263 = new SimpleSymbol("Title");
        Lit19 = (SimpleSymbol) simpleSymbol262.readResolve();
        SimpleSymbol simpleSymbol264 = simpleSymbol83;
        SimpleSymbol simpleSymbol265 = new SimpleSymbol("Scrollable");
        Lit18 = (SimpleSymbol) simpleSymbol264.readResolve();
        SimpleSymbol simpleSymbol266 = simpleSymbol84;
        SimpleSymbol simpleSymbol267 = new SimpleSymbol("ScreenOrientation");
        Lit17 = (SimpleSymbol) simpleSymbol266.readResolve();
        int[] iArr25 = new int[2];
        int[] iArr26 = iArr25;
        iArr25[0] = -104178986;
        Lit16 = IntNum.make(iArr26);
        SimpleSymbol simpleSymbol268 = simpleSymbol85;
        SimpleSymbol simpleSymbol269 = new SimpleSymbol("PrimaryColorDark");
        Lit15 = (SimpleSymbol) simpleSymbol268.readResolve();
        int[] iArr27 = new int[2];
        int[] iArr28 = iArr27;
        iArr27[0] = -102332698;
        Lit14 = IntNum.make(iArr28);
        SimpleSymbol simpleSymbol270 = simpleSymbol86;
        SimpleSymbol simpleSymbol271 = new SimpleSymbol("PrimaryColor");
        Lit13 = (SimpleSymbol) simpleSymbol270.readResolve();
        SimpleSymbol simpleSymbol272 = simpleSymbol87;
        SimpleSymbol simpleSymbol273 = new SimpleSymbol("MinSdk");
        Lit11 = (SimpleSymbol) simpleSymbol272.readResolve();
        SimpleSymbol simpleSymbol274 = simpleSymbol88;
        SimpleSymbol simpleSymbol275 = new SimpleSymbol(PropertyTypeConstants.PROPERTY_TYPE_BOOLEAN);
        Lit10 = (SimpleSymbol) simpleSymbol274.readResolve();
        SimpleSymbol simpleSymbol276 = simpleSymbol89;
        SimpleSymbol simpleSymbol277 = new SimpleSymbol("KeepScreenOn");
        Lit9 = (SimpleSymbol) simpleSymbol276.readResolve();
        SimpleSymbol simpleSymbol278 = simpleSymbol90;
        SimpleSymbol simpleSymbol279 = new SimpleSymbol("AppName");
        Lit8 = (SimpleSymbol) simpleSymbol278.readResolve();
        SimpleSymbol simpleSymbol280 = simpleSymbol91;
        SimpleSymbol simpleSymbol281 = new SimpleSymbol("AppId");
        Lit6 = (SimpleSymbol) simpleSymbol280.readResolve();
        int[] iArr29 = new int[2];
        int[] iArr30 = iArr29;
        iArr29[0] = -16728877;
        Lit4 = IntNum.make(iArr30);
        SimpleSymbol simpleSymbol282 = simpleSymbol92;
        SimpleSymbol simpleSymbol283 = new SimpleSymbol("AccentColor");
        Lit3 = (SimpleSymbol) simpleSymbol282.readResolve();
        SimpleSymbol simpleSymbol284 = simpleSymbol93;
        SimpleSymbol simpleSymbol285 = new SimpleSymbol("*the-null-value*");
        Lit2 = (SimpleSymbol) simpleSymbol284.readResolve();
        SimpleSymbol simpleSymbol286 = simpleSymbol94;
        SimpleSymbol simpleSymbol287 = new SimpleSymbol("getMessage");
        Lit1 = (SimpleSymbol) simpleSymbol286.readResolve();
        SimpleSymbol simpleSymbol288 = simpleSymbol95;
        SimpleSymbol simpleSymbol289 = new SimpleSymbol("Screen1");
        Lit0 = (SimpleSymbol) simpleSymbol288.readResolve();
    }

    public Screen1() {
        ModuleMethod moduleMethod;
        frame frame2;
        ModuleMethod moduleMethod2;
        ModuleMethod moduleMethod3;
        ModuleMethod moduleMethod4;
        ModuleMethod moduleMethod5;
        ModuleMethod moduleMethod6;
        ModuleMethod moduleMethod7;
        ModuleMethod moduleMethod8;
        ModuleMethod moduleMethod9;
        ModuleMethod moduleMethod10;
        ModuleMethod moduleMethod11;
        ModuleMethod moduleMethod12;
        ModuleMethod moduleMethod13;
        ModuleMethod moduleMethod14;
        ModuleMethod moduleMethod15;
        ModuleMethod moduleMethod16;
        ModuleMethod moduleMethod17;
        ModuleMethod moduleMethod18;
        ModuleMethod moduleMethod19;
        ModuleMethod moduleMethod20;
        ModuleMethod moduleMethod21;
        ModuleMethod moduleMethod22;
        ModuleMethod moduleMethod23;
        ModuleMethod moduleMethod24;
        ModuleMethod moduleMethod25;
        ModuleMethod moduleMethod26;
        ModuleMethod moduleMethod27;
        ModuleMethod moduleMethod28;
        ModuleMethod moduleMethod29;
        ModuleMethod moduleMethod30;
        ModuleMethod moduleMethod31;
        ModuleMethod moduleMethod32;
        ModuleMethod moduleMethod33;
        ModuleMethod moduleMethod34;
        ModuleMethod moduleMethod35;
        ModuleMethod moduleMethod36;
        ModuleMethod moduleMethod37;
        ModuleMethod moduleMethod38;
        ModuleMethod moduleMethod39;
        ModuleMethod moduleMethod40;
        ModuleMethod moduleMethod41;
        ModuleMethod moduleMethod42;
        ModuleMethod moduleMethod43;
        ModuleMethod moduleMethod44;
        ModuleMethod moduleMethod45;
        ModuleMethod moduleMethod46;
        ModuleMethod moduleMethod47;
        ModuleMethod moduleMethod48;
        ModuleMethod moduleMethod49;
        ModuleMethod moduleMethod50;
        ModuleMethod moduleMethod51;
        ModuleMethod moduleMethod52;
        ModuleMethod moduleMethod53;
        ModuleMethod moduleMethod54;
        ModuleMethod moduleMethod55;
        ModuleMethod moduleMethod56;
        ModuleMethod moduleMethod57;
        ModuleMethod moduleMethod58;
        ModuleMethod moduleMethod59;
        ModuleMethod moduleMethod60;
        ModuleMethod moduleMethod61;
        ModuleMethod moduleMethod62;
        ModuleMethod moduleMethod63;
        ModuleMethod moduleMethod64;
        ModuleMethod moduleMethod65;
        ModuleMethod moduleMethod66;
        ModuleMethod moduleMethod67;
        ModuleMethod moduleMethod68;
        ModuleMethod moduleMethod69;
        ModuleMethod moduleMethod70;
        ModuleMethod moduleMethod71;
        ModuleMethod moduleMethod72;
        ModuleMethod moduleMethod73;
        ModuleInfo.register(this);
        ModuleMethod moduleMethod74 = moduleMethod;
        frame frame3 = frame2;
        frame frame4 = new frame();
        frame frame5 = frame3;
        frame frame6 = frame5;
        frame frame7 = frame6;
        ModuleMethod moduleMethod75 = new ModuleMethod(frame7, 1, Lit190, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.get$Mnsimple$Mnname = moduleMethod74;
        ModuleMethod moduleMethod76 = moduleMethod2;
        ModuleMethod moduleMethod77 = new ModuleMethod(frame7, 2, Lit191, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.android$Mnlog$Mnform = moduleMethod76;
        ModuleMethod moduleMethod78 = moduleMethod3;
        ModuleMethod moduleMethod79 = new ModuleMethod(frame7, 3, Lit192, 8194);
        this.add$Mnto$Mnform$Mnenvironment = moduleMethod78;
        ModuleMethod moduleMethod80 = moduleMethod4;
        ModuleMethod moduleMethod81 = new ModuleMethod(frame7, 4, Lit193, 8193);
        this.lookup$Mnin$Mnform$Mnenvironment = moduleMethod80;
        ModuleMethod moduleMethod82 = moduleMethod5;
        ModuleMethod moduleMethod83 = new ModuleMethod(frame7, 6, Lit194, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.is$Mnbound$Mnin$Mnform$Mnenvironment = moduleMethod82;
        ModuleMethod moduleMethod84 = moduleMethod6;
        ModuleMethod moduleMethod85 = new ModuleMethod(frame7, 7, Lit195, 8194);
        this.add$Mnto$Mnglobal$Mnvar$Mnenvironment = moduleMethod84;
        ModuleMethod moduleMethod86 = moduleMethod7;
        ModuleMethod moduleMethod87 = new ModuleMethod(frame7, 8, Lit196, 8194);
        this.add$Mnto$Mnevents = moduleMethod86;
        ModuleMethod moduleMethod88 = moduleMethod8;
        ModuleMethod moduleMethod89 = new ModuleMethod(frame7, 9, Lit197, 16388);
        this.add$Mnto$Mncomponents = moduleMethod88;
        ModuleMethod moduleMethod90 = moduleMethod9;
        ModuleMethod moduleMethod91 = new ModuleMethod(frame7, 10, Lit198, 8194);
        this.add$Mnto$Mnglobal$Mnvars = moduleMethod90;
        ModuleMethod moduleMethod92 = moduleMethod10;
        ModuleMethod moduleMethod93 = new ModuleMethod(frame7, 11, Lit199, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.add$Mnto$Mnform$Mndo$Mnafter$Mncreation = moduleMethod92;
        ModuleMethod moduleMethod94 = moduleMethod11;
        ModuleMethod moduleMethod95 = new ModuleMethod(frame7, 12, Lit200, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.send$Mnerror = moduleMethod94;
        ModuleMethod moduleMethod96 = moduleMethod12;
        ModuleMethod moduleMethod97 = new ModuleMethod(frame7, 13, "process-exception", FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.process$Mnexception = moduleMethod96;
        ModuleMethod moduleMethod98 = moduleMethod13;
        ModuleMethod moduleMethod99 = new ModuleMethod(frame7, 14, Lit201, 16388);
        this.dispatchEvent = moduleMethod98;
        ModuleMethod moduleMethod100 = moduleMethod14;
        ModuleMethod moduleMethod101 = new ModuleMethod(frame7, 15, Lit202, 16388);
        this.dispatchGenericEvent = moduleMethod100;
        ModuleMethod moduleMethod102 = moduleMethod15;
        ModuleMethod moduleMethod103 = new ModuleMethod(frame7, 16, Lit203, 8194);
        this.lookup$Mnhandler = moduleMethod102;
        ModuleMethod moduleMethod104 = moduleMethod16;
        ModuleMethod moduleMethod105 = new ModuleMethod(frame7, 17, null, 0);
        ModuleMethod moduleMethod106 = moduleMethod104;
        ModuleMethod moduleMethod107 = moduleMethod106;
        moduleMethod106.setProperty("source-location", "/tmp/runtime4954007513301323857.scm:615");
        lambda$Fn1 = moduleMethod107;
        ModuleMethod moduleMethod108 = moduleMethod17;
        ModuleMethod moduleMethod109 = new ModuleMethod(frame7, 18, "$define", 0);
        this.$define = moduleMethod108;
        ModuleMethod moduleMethod110 = moduleMethod18;
        ModuleMethod moduleMethod111 = new ModuleMethod(frame7, 19, null, 0);
        lambda$Fn2 = moduleMethod110;
        ModuleMethod moduleMethod112 = moduleMethod19;
        ModuleMethod moduleMethod113 = new ModuleMethod(frame7, 20, Lit23, 16388);
        this.Screen1$ErrorOccurred = moduleMethod112;
        ModuleMethod moduleMethod114 = moduleMethod20;
        ModuleMethod moduleMethod115 = new ModuleMethod(frame7, 21, null, 0);
        lambda$Fn3 = moduleMethod114;
        ModuleMethod moduleMethod116 = moduleMethod21;
        ModuleMethod moduleMethod117 = new ModuleMethod(frame7, 22, null, 0);
        lambda$Fn4 = moduleMethod116;
        ModuleMethod moduleMethod118 = moduleMethod22;
        ModuleMethod moduleMethod119 = new ModuleMethod(frame7, 23, Lit44, 0);
        this.List_Picker1$BeforePicking = moduleMethod118;
        ModuleMethod moduleMethod120 = moduleMethod23;
        ModuleMethod moduleMethod121 = new ModuleMethod(frame7, 24, Lit49, FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        this.List_Picker1$AfterPicking = moduleMethod120;
        ModuleMethod moduleMethod122 = moduleMethod24;
        ModuleMethod moduleMethod123 = new ModuleMethod(frame7, 25, null, 0);
        lambda$Fn5 = moduleMethod122;
        ModuleMethod moduleMethod124 = moduleMethod25;
        ModuleMethod moduleMethod125 = new ModuleMethod(frame7, 26, null, 0);
        lambda$Fn6 = moduleMethod124;
        ModuleMethod moduleMethod126 = moduleMethod26;
        ModuleMethod moduleMethod127 = new ModuleMethod(frame7, 27, null, 0);
        lambda$Fn7 = moduleMethod126;
        ModuleMethod moduleMethod128 = moduleMethod27;
        ModuleMethod moduleMethod129 = new ModuleMethod(frame7, 28, null, 0);
        lambda$Fn8 = moduleMethod128;
        ModuleMethod moduleMethod130 = moduleMethod28;
        ModuleMethod moduleMethod131 = new ModuleMethod(frame7, 29, null, 0);
        lambda$Fn9 = moduleMethod130;
        ModuleMethod moduleMethod132 = moduleMethod29;
        ModuleMethod moduleMethod133 = new ModuleMethod(frame7, 30, null, 0);
        lambda$Fn10 = moduleMethod132;
        ModuleMethod moduleMethod134 = moduleMethod30;
        ModuleMethod moduleMethod135 = new ModuleMethod(frame7, 31, null, 0);
        lambda$Fn11 = moduleMethod134;
        ModuleMethod moduleMethod136 = moduleMethod31;
        ModuleMethod moduleMethod137 = new ModuleMethod(frame7, 32, null, 0);
        lambda$Fn12 = moduleMethod136;
        ModuleMethod moduleMethod138 = moduleMethod32;
        ModuleMethod moduleMethod139 = new ModuleMethod(frame7, 33, null, 0);
        lambda$Fn13 = moduleMethod138;
        ModuleMethod moduleMethod140 = moduleMethod33;
        ModuleMethod moduleMethod141 = new ModuleMethod(frame7, 34, null, 0);
        lambda$Fn14 = moduleMethod140;
        ModuleMethod moduleMethod142 = moduleMethod34;
        ModuleMethod moduleMethod143 = new ModuleMethod(frame7, 35, null, 0);
        lambda$Fn15 = moduleMethod142;
        ModuleMethod moduleMethod144 = moduleMethod35;
        ModuleMethod moduleMethod145 = new ModuleMethod(frame7, 36, null, 0);
        lambda$Fn16 = moduleMethod144;
        ModuleMethod moduleMethod146 = moduleMethod36;
        ModuleMethod moduleMethod147 = new ModuleMethod(frame7, 37, Lit106, 0);
        this.Button1$Click = moduleMethod146;
        ModuleMethod moduleMethod148 = moduleMethod37;
        ModuleMethod moduleMethod149 = new ModuleMethod(frame7, 38, null, 0);
        lambda$Fn17 = moduleMethod148;
        ModuleMethod moduleMethod150 = moduleMethod38;
        ModuleMethod moduleMethod151 = new ModuleMethod(frame7, 39, null, 0);
        lambda$Fn18 = moduleMethod150;
        ModuleMethod moduleMethod152 = moduleMethod39;
        ModuleMethod moduleMethod153 = new ModuleMethod(frame7, 40, null, 0);
        lambda$Fn19 = moduleMethod152;
        ModuleMethod moduleMethod154 = moduleMethod40;
        ModuleMethod moduleMethod155 = new ModuleMethod(frame7, 41, null, 0);
        lambda$Fn20 = moduleMethod154;
        ModuleMethod moduleMethod156 = moduleMethod41;
        ModuleMethod moduleMethod157 = new ModuleMethod(frame7, 42, null, 0);
        lambda$Fn21 = moduleMethod156;
        ModuleMethod moduleMethod158 = moduleMethod42;
        ModuleMethod moduleMethod159 = new ModuleMethod(frame7, 43, null, 0);
        lambda$Fn22 = moduleMethod158;
        ModuleMethod moduleMethod160 = moduleMethod43;
        ModuleMethod moduleMethod161 = new ModuleMethod(frame7, 44, null, 0);
        lambda$Fn23 = moduleMethod160;
        ModuleMethod moduleMethod162 = moduleMethod44;
        ModuleMethod moduleMethod163 = new ModuleMethod(frame7, 45, null, 0);
        lambda$Fn24 = moduleMethod162;
        ModuleMethod moduleMethod164 = moduleMethod45;
        ModuleMethod moduleMethod165 = new ModuleMethod(frame7, 46, Lit125, 0);
        this.Button2$Click = moduleMethod164;
        ModuleMethod moduleMethod166 = moduleMethod46;
        ModuleMethod moduleMethod167 = new ModuleMethod(frame7, 47, null, 0);
        lambda$Fn25 = moduleMethod166;
        ModuleMethod moduleMethod168 = moduleMethod47;
        ModuleMethod moduleMethod169 = new ModuleMethod(frame7, 48, null, 0);
        lambda$Fn26 = moduleMethod168;
        ModuleMethod moduleMethod170 = moduleMethod48;
        ModuleMethod moduleMethod171 = new ModuleMethod(frame7, 49, null, 0);
        lambda$Fn27 = moduleMethod170;
        ModuleMethod moduleMethod172 = moduleMethod49;
        ModuleMethod moduleMethod173 = new ModuleMethod(frame7, 50, null, 0);
        lambda$Fn28 = moduleMethod172;
        ModuleMethod moduleMethod174 = moduleMethod50;
        ModuleMethod moduleMethod175 = new ModuleMethod(frame7, 51, null, 0);
        lambda$Fn29 = moduleMethod174;
        ModuleMethod moduleMethod176 = moduleMethod51;
        ModuleMethod moduleMethod177 = new ModuleMethod(frame7, 52, null, 0);
        lambda$Fn30 = moduleMethod176;
        ModuleMethod moduleMethod178 = moduleMethod52;
        ModuleMethod moduleMethod179 = new ModuleMethod(frame7, 53, null, 0);
        lambda$Fn31 = moduleMethod178;
        ModuleMethod moduleMethod180 = moduleMethod53;
        ModuleMethod moduleMethod181 = new ModuleMethod(frame7, 54, null, 0);
        lambda$Fn32 = moduleMethod180;
        ModuleMethod moduleMethod182 = moduleMethod54;
        ModuleMethod moduleMethod183 = new ModuleMethod(frame7, 55, null, 0);
        lambda$Fn33 = moduleMethod182;
        ModuleMethod moduleMethod184 = moduleMethod55;
        ModuleMethod moduleMethod185 = new ModuleMethod(frame7, 56, null, 0);
        lambda$Fn34 = moduleMethod184;
        ModuleMethod moduleMethod186 = moduleMethod56;
        ModuleMethod moduleMethod187 = new ModuleMethod(frame7, 57, null, 0);
        lambda$Fn35 = moduleMethod186;
        ModuleMethod moduleMethod188 = moduleMethod57;
        ModuleMethod moduleMethod189 = new ModuleMethod(frame7, 58, null, 0);
        lambda$Fn36 = moduleMethod188;
        ModuleMethod moduleMethod190 = moduleMethod58;
        ModuleMethod moduleMethod191 = new ModuleMethod(frame7, 59, null, 0);
        lambda$Fn37 = moduleMethod190;
        ModuleMethod moduleMethod192 = moduleMethod59;
        ModuleMethod moduleMethod193 = new ModuleMethod(frame7, 60, null, 0);
        lambda$Fn38 = moduleMethod192;
        ModuleMethod moduleMethod194 = moduleMethod60;
        ModuleMethod moduleMethod195 = new ModuleMethod(frame7, 61, null, 0);
        lambda$Fn39 = moduleMethod194;
        ModuleMethod moduleMethod196 = moduleMethod61;
        ModuleMethod moduleMethod197 = new ModuleMethod(frame7, 62, null, 0);
        lambda$Fn40 = moduleMethod196;
        ModuleMethod moduleMethod198 = moduleMethod62;
        ModuleMethod moduleMethod199 = new ModuleMethod(frame7, 63, Lit163, 0);
        this.Clock1$Timer = moduleMethod198;
        ModuleMethod moduleMethod200 = moduleMethod63;
        ModuleMethod moduleMethod201 = new ModuleMethod(frame7, 64, null, 0);
        lambda$Fn41 = moduleMethod200;
        ModuleMethod moduleMethod202 = moduleMethod64;
        ModuleMethod moduleMethod203 = new ModuleMethod(frame7, 65, null, 0);
        lambda$Fn42 = moduleMethod202;
        ModuleMethod moduleMethod204 = moduleMethod65;
        ModuleMethod moduleMethod205 = new ModuleMethod(frame7, 66, null, 0);
        lambda$Fn43 = moduleMethod204;
        ModuleMethod moduleMethod206 = moduleMethod66;
        ModuleMethod moduleMethod207 = new ModuleMethod(frame7, 67, null, 0);
        lambda$Fn44 = moduleMethod206;
        ModuleMethod moduleMethod208 = moduleMethod67;
        ModuleMethod moduleMethod209 = new ModuleMethod(frame7, 68, null, 0);
        lambda$Fn45 = moduleMethod208;
        ModuleMethod moduleMethod210 = moduleMethod68;
        ModuleMethod moduleMethod211 = new ModuleMethod(frame7, 69, null, 0);
        lambda$Fn46 = moduleMethod210;
        ModuleMethod moduleMethod212 = moduleMethod69;
        ModuleMethod moduleMethod213 = new ModuleMethod(frame7, 70, null, 0);
        lambda$Fn47 = moduleMethod212;
        ModuleMethod moduleMethod214 = moduleMethod70;
        ModuleMethod moduleMethod215 = new ModuleMethod(frame7, 71, null, 0);
        lambda$Fn48 = moduleMethod214;
        ModuleMethod moduleMethod216 = moduleMethod71;
        ModuleMethod moduleMethod217 = new ModuleMethod(frame7, 72, null, 0);
        lambda$Fn49 = moduleMethod216;
        ModuleMethod moduleMethod218 = moduleMethod72;
        ModuleMethod moduleMethod219 = new ModuleMethod(frame7, 73, null, 0);
        lambda$Fn50 = moduleMethod218;
        ModuleMethod moduleMethod220 = moduleMethod73;
        ModuleMethod moduleMethod221 = new ModuleMethod(frame7, 74, Lit189, 0);
        this.Clock2$Timer = moduleMethod220;
    }

    public Object lookupInFormEnvironment(Symbol symbol) {
        return lookupInFormEnvironment(symbol, Boolean.FALSE);
    }

    public void run() {
        Throwable th;
        CallContext instance = CallContext.getInstance();
        Consumer consumer = instance.consumer;
        instance.consumer = VoidConsumer.instance;
        try {
            run(instance);
            th = null;
        } catch (Throwable th2) {
            th = th2;
        }
        ModuleBody.runCleanup(instance, th, consumer);
    }

    public final void run(CallContext callContext) {
        WrongType wrongType;
        String obj;
        WrongType wrongType2;
        Promise promise;
        Consumer $result = callContext.consumer;
        Object find = require.find("com.google.youngandroid.runtime");
        Object obj2 = find;
        try {
            ((Runnable) find).run();
            this.$Stdebug$Mnform$St = Boolean.FALSE;
            this.form$Mnenvironment = Environment.make(misc.symbol$To$String(Lit0));
            Object[] objArr = new Object[2];
            Object[] objArr2 = objArr;
            objArr[0] = misc.symbol$To$String(Lit0);
            Object[] objArr3 = objArr2;
            Object[] objArr4 = objArr3;
            objArr3[1] = "-global-vars";
            FString stringAppend = strings.stringAppend(objArr4);
            FString fString = stringAppend;
            if (stringAppend == null) {
                obj = null;
            } else {
                obj = fString.toString();
            }
            this.global$Mnvar$Mnenvironment = Environment.make(obj);
            Screen1 = null;
            this.form$Mnname$Mnsymbol = Lit0;
            this.events$Mnto$Mnregister = LList.Empty;
            this.components$Mnto$Mncreate = LList.Empty;
            this.global$Mnvars$Mnto$Mncreate = LList.Empty;
            this.form$Mndo$Mnafter$Mncreation = LList.Empty;
            Object find2 = require.find("com.google.youngandroid.runtime");
            Object obj3 = find2;
            try {
                ((Runnable) find2).run();
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit0, Lit3, Lit4, Lit5);
                    Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit0, Lit6, "4676648777547776", Lit7);
                    Object andCoerceProperty$Ex3 = C1158runtime.setAndCoerceProperty$Ex(Lit0, Lit8, "HackUMass", Lit7);
                    Object andCoerceProperty$Ex4 = C1158runtime.setAndCoerceProperty$Ex(Lit0, Lit9, Boolean.TRUE, Lit10);
                    Object andCoerceProperty$Ex5 = C1158runtime.setAndCoerceProperty$Ex(Lit0, Lit11, Lit12, Lit5);
                    Object andCoerceProperty$Ex6 = C1158runtime.setAndCoerceProperty$Ex(Lit0, Lit13, Lit14, Lit5);
                    Object andCoerceProperty$Ex7 = C1158runtime.setAndCoerceProperty$Ex(Lit0, Lit15, Lit16, Lit5);
                    Object andCoerceProperty$Ex8 = C1158runtime.setAndCoerceProperty$Ex(Lit0, Lit17, "portrait", Lit7);
                    Object andCoerceProperty$Ex9 = C1158runtime.setAndCoerceProperty$Ex(Lit0, Lit18, Boolean.TRUE, Lit10);
                    Values.writeValues(C1158runtime.setAndCoerceProperty$Ex(Lit0, Lit19, "HackUmass VII", Lit7), $result);
                } else {
                    Promise promise2 = promise;
                    Promise promise3 = new Promise(lambda$Fn2);
                    addToFormDoAfterCreation(promise2);
                }
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Object addToCurrentFormEnvironment = C1158runtime.addToCurrentFormEnvironment(Lit23, this.Screen1$ErrorOccurred);
                } else {
                    addToFormEnvironment(Lit23, this.Screen1$ErrorOccurred);
                }
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1158runtime.$Stthis$Mnform$St, "Screen1", "ErrorOccurred");
                } else {
                    addToEvents(Lit0, Lit24);
                }
                this.List_Picker1 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit0, Lit25, Lit26, lambda$Fn3), $result);
                } else {
                    addToComponents(Lit0, Lit39, Lit26, lambda$Fn4);
                }
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Object addToCurrentFormEnvironment2 = C1158runtime.addToCurrentFormEnvironment(Lit44, this.List_Picker1$BeforePicking);
                } else {
                    addToFormEnvironment(Lit44, this.List_Picker1$BeforePicking);
                }
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1158runtime.$Stthis$Mnform$St, "List_Picker1", "BeforePicking");
                } else {
                    addToEvents(Lit26, Lit45);
                }
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Object addToCurrentFormEnvironment3 = C1158runtime.addToCurrentFormEnvironment(Lit49, this.List_Picker1$AfterPicking);
                } else {
                    addToFormEnvironment(Lit49, this.List_Picker1$AfterPicking);
                }
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1158runtime.$Stthis$Mnform$St, "List_Picker1", "AfterPicking");
                } else {
                    addToEvents(Lit26, Lit50);
                }
                this.Space2 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit0, Lit51, Lit52, lambda$Fn5), $result);
                } else {
                    addToComponents(Lit0, Lit54, Lit52, lambda$Fn6);
                }
                this.Text_Box1 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit0, Lit55, Lit56, lambda$Fn7), $result);
                } else {
                    addToComponents(Lit0, Lit68, Lit56, lambda$Fn8);
                }
                this.Space3 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit0, Lit69, Lit70, lambda$Fn9), $result);
                } else {
                    addToComponents(Lit0, Lit71, Lit70, lambda$Fn10);
                }
                this.Horizontal_Arrangement3 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit0, Lit72, Lit73, lambda$Fn11), $result);
                } else {
                    addToComponents(Lit0, Lit76, Lit73, lambda$Fn12);
                }
                this.Horizontal_Arrangement4 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit73, Lit77, Lit78, lambda$Fn13), $result);
                } else {
                    addToComponents(Lit73, Lit80, Lit78, lambda$Fn14);
                }
                this.Button1 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit73, Lit81, Lit82, lambda$Fn15), $result);
                } else {
                    addToComponents(Lit73, Lit87, Lit82, lambda$Fn16);
                }
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Object addToCurrentFormEnvironment4 = C1158runtime.addToCurrentFormEnvironment(Lit106, this.Button1$Click);
                } else {
                    addToFormEnvironment(Lit106, this.Button1$Click);
                }
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1158runtime.$Stthis$Mnform$St, "Button1", "Click");
                } else {
                    addToEvents(Lit82, Lit107);
                }
                this.Horizontal_Arrangement5 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit73, Lit108, Lit109, lambda$Fn17), $result);
                } else {
                    addToComponents(Lit73, Lit111, Lit109, lambda$Fn18);
                }
                this.Horizontal_Arrangement6 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit0, Lit112, Lit103, lambda$Fn19), $result);
                } else {
                    addToComponents(Lit0, Lit114, Lit103, lambda$Fn20);
                }
                this.Horizontal_Arrangement7 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit103, Lit115, Lit116, lambda$Fn21), $result);
                } else {
                    addToComponents(Lit103, Lit118, Lit116, lambda$Fn22);
                }
                this.Button2 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit103, Lit119, Lit120, lambda$Fn23), $result);
                } else {
                    addToComponents(Lit103, Lit123, Lit120, lambda$Fn24);
                }
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Object addToCurrentFormEnvironment5 = C1158runtime.addToCurrentFormEnvironment(Lit125, this.Button2$Click);
                } else {
                    addToFormEnvironment(Lit125, this.Button2$Click);
                }
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1158runtime.$Stthis$Mnform$St, "Button2", "Click");
                } else {
                    addToEvents(Lit120, Lit107);
                }
                this.Horizontal_Arrangement8 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit103, Lit126, Lit127, lambda$Fn25), $result);
                } else {
                    addToComponents(Lit103, Lit128, Lit127, lambda$Fn26);
                }
                this.Space4 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit0, Lit129, Lit130, lambda$Fn27), $result);
                } else {
                    addToComponents(Lit0, Lit131, Lit130, lambda$Fn28);
                }
                this.Label1 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit0, Lit132, Lit93, lambda$Fn29), $result);
                } else {
                    addToComponents(Lit0, Lit134, Lit93, lambda$Fn30);
                }
                this.Label3 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit0, Lit135, Lit105, lambda$Fn31), $result);
                } else {
                    addToComponents(Lit0, Lit137, Lit105, lambda$Fn32);
                }
                this.Space5 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit0, Lit138, Lit139, lambda$Fn33), $result);
                } else {
                    addToComponents(Lit0, Lit140, Lit139, lambda$Fn34);
                }
                this.Firebase_Database1 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit0, Lit141, Lit142, lambda$Fn35), $result);
                } else {
                    addToComponents(Lit0, Lit148, Lit142, lambda$Fn36);
                }
                this.Bluetooth_Client1 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit0, Lit149, Lit41, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit150, Lit41, Boolean.FALSE);
                }
                this.Snackbar1 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit0, Lit151, Lit20, lambda$Fn37), $result);
                } else {
                    addToComponents(Lit0, Lit153, Lit20, lambda$Fn38);
                }
                this.Clock1 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit0, Lit154, Lit155, lambda$Fn39), $result);
                } else {
                    addToComponents(Lit0, Lit157, Lit155, lambda$Fn40);
                }
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Object addToCurrentFormEnvironment6 = C1158runtime.addToCurrentFormEnvironment(Lit163, this.Clock1$Timer);
                } else {
                    addToFormEnvironment(Lit163, this.Clock1$Timer);
                }
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1158runtime.$Stthis$Mnform$St, "Clock1", "Timer");
                } else {
                    addToEvents(Lit155, Lit164);
                }
                this.Clock2 = null;
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Values.writeValues(C1158runtime.addComponentWithinRepl(Lit0, Lit165, Lit166, Boolean.FALSE), $result);
                } else {
                    addToComponents(Lit0, Lit167, Lit166, Boolean.FALSE);
                }
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    Object addToCurrentFormEnvironment7 = C1158runtime.addToCurrentFormEnvironment(Lit189, this.Clock2$Timer);
                } else {
                    addToFormEnvironment(Lit189, this.Clock2$Timer);
                }
                if (C1158runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
                    EventDispatcher.registerEventForDelegation((HandlesEventDispatching) C1158runtime.$Stthis$Mnform$St, "Clock2", "Timer");
                } else {
                    addToEvents(Lit166, Lit164);
                }
                C1158runtime.initRuntime();
            } catch (ClassCastException e) {
                ClassCastException classCastException = e;
                WrongType wrongType3 = wrongType2;
                WrongType wrongType4 = new WrongType(classCastException, "java.lang.Runnable.run()", 1, obj3);
                throw wrongType3;
            }
        } catch (ClassCastException e2) {
            ClassCastException classCastException2 = e2;
            WrongType wrongType5 = wrongType;
            WrongType wrongType6 = new WrongType(classCastException2, "java.lang.Runnable.run()", 1, obj2);
            throw wrongType5;
        }
    }

    static Object lambda3() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit0, Lit3, Lit4, Lit5);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit0, Lit6, "4676648777547776", Lit7);
        Object andCoerceProperty$Ex3 = C1158runtime.setAndCoerceProperty$Ex(Lit0, Lit8, "HackUMass", Lit7);
        Object andCoerceProperty$Ex4 = C1158runtime.setAndCoerceProperty$Ex(Lit0, Lit9, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex5 = C1158runtime.setAndCoerceProperty$Ex(Lit0, Lit11, Lit12, Lit5);
        Object andCoerceProperty$Ex6 = C1158runtime.setAndCoerceProperty$Ex(Lit0, Lit13, Lit14, Lit5);
        Object andCoerceProperty$Ex7 = C1158runtime.setAndCoerceProperty$Ex(Lit0, Lit15, Lit16, Lit5);
        Object andCoerceProperty$Ex8 = C1158runtime.setAndCoerceProperty$Ex(Lit0, Lit17, "portrait", Lit7);
        Object andCoerceProperty$Ex9 = C1158runtime.setAndCoerceProperty$Ex(Lit0, Lit18, Boolean.TRUE, Lit10);
        return C1158runtime.setAndCoerceProperty$Ex(Lit0, Lit19, "HackUmass VII", Lit7);
    }

    public Object Screen1$ErrorOccurred(Object obj, Object obj2, Object obj3, Object obj4) {
        Object $functionName = obj2;
        Object $errorNumber = obj3;
        Object $message = obj4;
        Object sanitizeComponentData = C1158runtime.sanitizeComponentData(obj);
        Object sanitizeComponentData2 = C1158runtime.sanitizeComponentData($functionName);
        Object sanitizeComponentData3 = C1158runtime.sanitizeComponentData($errorNumber);
        Object sanitizeComponentData4 = C1158runtime.sanitizeComponentData($message);
        C1158runtime.setThisForm();
        return C1158runtime.callComponentMethod(Lit20, Lit21, LList.list1("Bluetooth Not Connected"), Lit22);
    }

    static Object lambda4() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit26, Lit27, Lit28, Lit5);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit26, Lit29, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1158runtime.setAndCoerceProperty$Ex(Lit26, Lit30, Lit31, Lit5);
        Object andCoerceProperty$Ex4 = C1158runtime.setAndCoerceProperty$Ex(Lit26, Lit32, Lit33, Lit5);
        Object andCoerceProperty$Ex5 = C1158runtime.setAndCoerceProperty$Ex(Lit26, Lit34, Lit35, Lit5);
        Object andCoerceProperty$Ex6 = C1158runtime.setAndCoerceProperty$Ex(Lit26, Lit36, Lit37, Lit5);
        Object andCoerceProperty$Ex7 = C1158runtime.setAndCoerceProperty$Ex(Lit26, Lit38, "Connect", Lit7);
        return C1158runtime.setAndCoerceProperty$Ex(Lit26, Lit19, "Select Your Bluetooth Module", Lit7);
    }

    static Object lambda5() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit26, Lit27, Lit28, Lit5);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit26, Lit29, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1158runtime.setAndCoerceProperty$Ex(Lit26, Lit30, Lit31, Lit5);
        Object andCoerceProperty$Ex4 = C1158runtime.setAndCoerceProperty$Ex(Lit26, Lit32, Lit33, Lit5);
        Object andCoerceProperty$Ex5 = C1158runtime.setAndCoerceProperty$Ex(Lit26, Lit34, Lit35, Lit5);
        Object andCoerceProperty$Ex6 = C1158runtime.setAndCoerceProperty$Ex(Lit26, Lit36, Lit37, Lit5);
        Object andCoerceProperty$Ex7 = C1158runtime.setAndCoerceProperty$Ex(Lit26, Lit38, "Connect", Lit7);
        return C1158runtime.setAndCoerceProperty$Ex(Lit26, Lit19, "Select Your Bluetooth Module", Lit7);
    }

    public Object List_Picker1$BeforePicking() {
        C1158runtime.setThisForm();
        return C1158runtime.setAndCoerceProperty$Ex(Lit26, Lit40, C1158runtime.getProperty$1(Lit41, Lit42), Lit43);
    }

    public Object List_Picker1$AfterPicking(Object obj) {
        Object sanitizeComponentData = C1158runtime.sanitizeComponentData(obj);
        C1158runtime.setThisForm();
        return C1158runtime.setAndCoerceProperty$Ex(Lit26, Lit46, C1158runtime.callComponentMethod(Lit41, Lit47, LList.list1(C1158runtime.getProperty$1(Lit26, Lit46)), Lit48), Lit7);
    }

    static Object lambda6() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit52, Lit32, Lit53, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit52, Lit34, Lit35, Lit5);
    }

    static Object lambda7() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit52, Lit32, Lit53, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit52, Lit34, Lit35, Lit5);
    }

    static Object lambda8() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit56, Lit30, Lit31, Lit5);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit56, Lit57, Lit58, Lit5);
        Object andCoerceProperty$Ex3 = C1158runtime.setAndCoerceProperty$Ex(Lit56, Lit32, Lit59, Lit5);
        Object andCoerceProperty$Ex4 = C1158runtime.setAndCoerceProperty$Ex(Lit56, Lit34, Lit35, Lit5);
        Object andCoerceProperty$Ex5 = C1158runtime.setAndCoerceProperty$Ex(Lit56, Lit60, "Enter your unique ID", Lit7);
        Object andCoerceProperty$Ex6 = C1158runtime.setAndCoerceProperty$Ex(Lit56, Lit61, Lit62, Lit5);
        Object andCoerceProperty$Ex7 = C1158runtime.setAndCoerceProperty$Ex(Lit56, Lit63, Lit58, Lit5);
        Object andCoerceProperty$Ex8 = C1158runtime.setAndCoerceProperty$Ex(Lit56, Lit64, Lit65, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit56, Lit66, Lit67, Lit5);
    }

    static Object lambda9() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit56, Lit30, Lit31, Lit5);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit56, Lit57, Lit58, Lit5);
        Object andCoerceProperty$Ex3 = C1158runtime.setAndCoerceProperty$Ex(Lit56, Lit32, Lit59, Lit5);
        Object andCoerceProperty$Ex4 = C1158runtime.setAndCoerceProperty$Ex(Lit56, Lit34, Lit35, Lit5);
        Object andCoerceProperty$Ex5 = C1158runtime.setAndCoerceProperty$Ex(Lit56, Lit60, "Enter your unique ID", Lit7);
        Object andCoerceProperty$Ex6 = C1158runtime.setAndCoerceProperty$Ex(Lit56, Lit61, Lit62, Lit5);
        Object andCoerceProperty$Ex7 = C1158runtime.setAndCoerceProperty$Ex(Lit56, Lit63, Lit58, Lit5);
        Object andCoerceProperty$Ex8 = C1158runtime.setAndCoerceProperty$Ex(Lit56, Lit64, Lit65, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit56, Lit66, Lit67, Lit5);
    }

    static Object lambda10() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit70, Lit32, Lit59, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit70, Lit34, Lit35, Lit5);
    }

    static Object lambda11() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit70, Lit32, Lit59, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit70, Lit34, Lit35, Lit5);
    }

    static Object lambda12() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit73, Lit27, Lit74, Lit5);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit73, Lit32, Lit75, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit73, Lit34, Lit35, Lit5);
    }

    static Object lambda13() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit73, Lit27, Lit74, Lit5);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit73, Lit32, Lit75, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit73, Lit34, Lit35, Lit5);
    }

    static Object lambda14() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit78, Lit27, Lit79, Lit5);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit78, Lit32, Lit35, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit78, Lit34, Lit35, Lit5);
    }

    static Object lambda15() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit78, Lit27, Lit79, Lit5);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit78, Lit32, Lit35, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit78, Lit34, Lit35, Lit5);
    }

    static Object lambda16() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit82, Lit27, Lit83, Lit5);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit82, Lit29, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1158runtime.setAndCoerceProperty$Ex(Lit82, Lit30, Lit31, Lit5);
        Object andCoerceProperty$Ex4 = C1158runtime.setAndCoerceProperty$Ex(Lit82, Lit57, Lit58, Lit5);
        Object andCoerceProperty$Ex5 = C1158runtime.setAndCoerceProperty$Ex(Lit82, Lit32, Lit84, Lit5);
        Object andCoerceProperty$Ex6 = C1158runtime.setAndCoerceProperty$Ex(Lit82, Lit34, Lit84, Lit5);
        Object andCoerceProperty$Ex7 = C1158runtime.setAndCoerceProperty$Ex(Lit82, Lit36, Lit85, Lit5);
        Object andCoerceProperty$Ex8 = C1158runtime.setAndCoerceProperty$Ex(Lit82, Lit38, "Start", Lit7);
        return C1158runtime.setAndCoerceProperty$Ex(Lit82, Lit66, Lit86, Lit5);
    }

    static Object lambda17() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit82, Lit27, Lit83, Lit5);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit82, Lit29, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1158runtime.setAndCoerceProperty$Ex(Lit82, Lit30, Lit31, Lit5);
        Object andCoerceProperty$Ex4 = C1158runtime.setAndCoerceProperty$Ex(Lit82, Lit57, Lit58, Lit5);
        Object andCoerceProperty$Ex5 = C1158runtime.setAndCoerceProperty$Ex(Lit82, Lit32, Lit84, Lit5);
        Object andCoerceProperty$Ex6 = C1158runtime.setAndCoerceProperty$Ex(Lit82, Lit34, Lit84, Lit5);
        Object andCoerceProperty$Ex7 = C1158runtime.setAndCoerceProperty$Ex(Lit82, Lit36, Lit85, Lit5);
        Object andCoerceProperty$Ex8 = C1158runtime.setAndCoerceProperty$Ex(Lit82, Lit38, "Start", Lit7);
        return C1158runtime.setAndCoerceProperty$Ex(Lit82, Lit66, Lit86, Lit5);
    }

    public Object Button1$Click() {
        C1158runtime.setThisForm();
        if (C1158runtime.callYailPrimitive(C1158runtime.yail$Mnequal$Qu, LList.list2(C1158runtime.getProperty$1(Lit56, Lit38), ""), Lit88, "=") != Boolean.FALSE) {
            Object callComponentMethod = C1158runtime.callComponentMethod(Lit20, Lit21, LList.list1("Enter a valid ID"), Lit89);
        }
        if (C1158runtime.callYailPrimitive(C1158runtime.yail$Mnequal$Qu, LList.list2(C1158runtime.getProperty$1(Lit56, Lit38), "0001"), Lit90, "=") != Boolean.FALSE) {
            Object callComponentMethod2 = C1158runtime.callComponentMethod(Lit41, Lit91, LList.list1("1"), Lit92);
            Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit93, Lit38, "Rupak", Lit7);
        } else if (C1158runtime.callYailPrimitive(C1158runtime.yail$Mnequal$Qu, LList.list2(C1158runtime.getProperty$1(Lit56, Lit38), "0002"), Lit94, "=") != Boolean.FALSE) {
            Object callComponentMethod3 = C1158runtime.callComponentMethod(Lit41, Lit91, LList.list1("1"), Lit95);
            Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit93, Lit38, "Akshat", Lit7);
        } else if (C1158runtime.callYailPrimitive(C1158runtime.yail$Mnequal$Qu, LList.list2(C1158runtime.getProperty$1(Lit56, Lit38), "0003"), Lit96, "=") != Boolean.FALSE) {
            Object callComponentMethod4 = C1158runtime.callComponentMethod(Lit41, Lit91, LList.list1("1"), Lit97);
            Object andCoerceProperty$Ex3 = C1158runtime.setAndCoerceProperty$Ex(Lit93, Lit38, "Siddhanth", Lit7);
        } else if (C1158runtime.callYailPrimitive(C1158runtime.yail$Mnequal$Qu, LList.list2(C1158runtime.getProperty$1(Lit56, Lit38), "0004"), Lit98, "=") != Boolean.FALSE) {
            Object callComponentMethod5 = C1158runtime.callComponentMethod(Lit41, Lit91, LList.list1("1"), Lit99);
            Object andCoerceProperty$Ex4 = C1158runtime.setAndCoerceProperty$Ex(Lit93, Lit38, "Saiyyam", Lit7);
        } else if (C1158runtime.callYailPrimitive(C1158runtime.yail$Mnequal$Qu, LList.list2(C1158runtime.getProperty$1(Lit56, Lit38), "0005"), Lit100, "=") != Boolean.FALSE) {
            Object callComponentMethod6 = C1158runtime.callComponentMethod(Lit41, Lit91, LList.list1("1"), Lit101);
            Object andCoerceProperty$Ex5 = C1158runtime.setAndCoerceProperty$Ex(Lit93, Lit38, "Prakhar", Lit7);
        } else {
            Object callComponentMethod7 = C1158runtime.callComponentMethod(Lit20, Lit21, LList.list1("User Not Recognised"), Lit102);
        }
        Object andCoerceProperty$Ex6 = C1158runtime.setAndCoerceProperty$Ex(Lit56, Lit38, "", Lit7);
        Object andCoerceProperty$Ex7 = C1158runtime.setAndCoerceProperty$Ex(Lit103, Lit104, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex8 = C1158runtime.setAndCoerceProperty$Ex(Lit73, Lit104, Boolean.FALSE, Lit10);
        return C1158runtime.setAndCoerceProperty$Ex(Lit105, Lit38, "", Lit7);
    }

    static Object lambda18() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit109, Lit27, Lit110, Lit5);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit109, Lit32, Lit35, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit109, Lit34, Lit35, Lit5);
    }

    static Object lambda19() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit109, Lit27, Lit110, Lit5);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit109, Lit32, Lit35, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit109, Lit34, Lit35, Lit5);
    }

    static Object lambda20() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit103, Lit27, Lit113, Lit5);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit103, Lit32, Lit75, Lit5);
        Object andCoerceProperty$Ex3 = C1158runtime.setAndCoerceProperty$Ex(Lit103, Lit34, Lit35, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit103, Lit104, Boolean.FALSE, Lit10);
    }

    static Object lambda21() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit103, Lit27, Lit113, Lit5);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit103, Lit32, Lit75, Lit5);
        Object andCoerceProperty$Ex3 = C1158runtime.setAndCoerceProperty$Ex(Lit103, Lit34, Lit35, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit103, Lit104, Boolean.FALSE, Lit10);
    }

    static Object lambda22() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit116, Lit27, Lit117, Lit5);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit116, Lit32, Lit35, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit116, Lit34, Lit35, Lit5);
    }

    static Object lambda23() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit116, Lit27, Lit117, Lit5);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit116, Lit32, Lit35, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit116, Lit34, Lit35, Lit5);
    }

    static Object lambda24() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit120, Lit27, Lit121, Lit5);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit120, Lit29, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1158runtime.setAndCoerceProperty$Ex(Lit120, Lit30, Lit31, Lit5);
        Object andCoerceProperty$Ex4 = C1158runtime.setAndCoerceProperty$Ex(Lit120, Lit57, Lit58, Lit5);
        Object andCoerceProperty$Ex5 = C1158runtime.setAndCoerceProperty$Ex(Lit120, Lit32, Lit84, Lit5);
        Object andCoerceProperty$Ex6 = C1158runtime.setAndCoerceProperty$Ex(Lit120, Lit34, Lit84, Lit5);
        Object andCoerceProperty$Ex7 = C1158runtime.setAndCoerceProperty$Ex(Lit120, Lit36, Lit85, Lit5);
        Object andCoerceProperty$Ex8 = C1158runtime.setAndCoerceProperty$Ex(Lit120, Lit38, "Stop", Lit7);
        return C1158runtime.setAndCoerceProperty$Ex(Lit120, Lit66, Lit122, Lit5);
    }

    static Object lambda25() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit120, Lit27, Lit121, Lit5);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit120, Lit29, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex3 = C1158runtime.setAndCoerceProperty$Ex(Lit120, Lit30, Lit31, Lit5);
        Object andCoerceProperty$Ex4 = C1158runtime.setAndCoerceProperty$Ex(Lit120, Lit57, Lit58, Lit5);
        Object andCoerceProperty$Ex5 = C1158runtime.setAndCoerceProperty$Ex(Lit120, Lit32, Lit84, Lit5);
        Object andCoerceProperty$Ex6 = C1158runtime.setAndCoerceProperty$Ex(Lit120, Lit34, Lit84, Lit5);
        Object andCoerceProperty$Ex7 = C1158runtime.setAndCoerceProperty$Ex(Lit120, Lit36, Lit85, Lit5);
        Object andCoerceProperty$Ex8 = C1158runtime.setAndCoerceProperty$Ex(Lit120, Lit38, "Stop", Lit7);
        return C1158runtime.setAndCoerceProperty$Ex(Lit120, Lit66, Lit122, Lit5);
    }

    public Object Button2$Click() {
        C1158runtime.setThisForm();
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit73, Lit104, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit103, Lit104, Boolean.FALSE, Lit10);
        return C1158runtime.callComponentMethod(Lit41, Lit91, LList.list1("0"), Lit124);
    }

    static Object lambda26() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit127, Lit32, Lit35, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit127, Lit34, Lit35, Lit5);
    }

    static Object lambda27() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit127, Lit32, Lit35, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit127, Lit34, Lit35, Lit5);
    }

    static Object lambda28() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit130, Lit32, Lit35, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit130, Lit34, Lit35, Lit5);
    }

    static Object lambda29() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit130, Lit32, Lit35, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit130, Lit34, Lit35, Lit5);
    }

    static Object lambda30() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit93, Lit29, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit93, Lit30, Lit31, Lit5);
        Object andCoerceProperty$Ex3 = C1158runtime.setAndCoerceProperty$Ex(Lit93, Lit57, Lit58, Lit5);
        Object andCoerceProperty$Ex4 = C1158runtime.setAndCoerceProperty$Ex(Lit93, Lit32, Lit59, Lit5);
        Object andCoerceProperty$Ex5 = C1158runtime.setAndCoerceProperty$Ex(Lit93, Lit34, Lit35, Lit5);
        Object andCoerceProperty$Ex6 = C1158runtime.setAndCoerceProperty$Ex(Lit93, Lit64, Lit65, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit93, Lit66, Lit133, Lit5);
    }

    static Object lambda31() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit93, Lit29, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit93, Lit30, Lit31, Lit5);
        Object andCoerceProperty$Ex3 = C1158runtime.setAndCoerceProperty$Ex(Lit93, Lit57, Lit58, Lit5);
        Object andCoerceProperty$Ex4 = C1158runtime.setAndCoerceProperty$Ex(Lit93, Lit32, Lit59, Lit5);
        Object andCoerceProperty$Ex5 = C1158runtime.setAndCoerceProperty$Ex(Lit93, Lit34, Lit35, Lit5);
        Object andCoerceProperty$Ex6 = C1158runtime.setAndCoerceProperty$Ex(Lit93, Lit64, Lit65, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit93, Lit66, Lit133, Lit5);
    }

    static Object lambda32() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit105, Lit29, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit105, Lit30, Lit31, Lit5);
        Object andCoerceProperty$Ex3 = C1158runtime.setAndCoerceProperty$Ex(Lit105, Lit57, Lit58, Lit5);
        Object andCoerceProperty$Ex4 = C1158runtime.setAndCoerceProperty$Ex(Lit105, Lit32, Lit59, Lit5);
        Object andCoerceProperty$Ex5 = C1158runtime.setAndCoerceProperty$Ex(Lit105, Lit34, Lit35, Lit5);
        Object andCoerceProperty$Ex6 = C1158runtime.setAndCoerceProperty$Ex(Lit105, Lit64, Lit65, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit105, Lit66, Lit136, Lit5);
    }

    static Object lambda33() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit105, Lit29, Boolean.TRUE, Lit10);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit105, Lit30, Lit31, Lit5);
        Object andCoerceProperty$Ex3 = C1158runtime.setAndCoerceProperty$Ex(Lit105, Lit57, Lit58, Lit5);
        Object andCoerceProperty$Ex4 = C1158runtime.setAndCoerceProperty$Ex(Lit105, Lit32, Lit59, Lit5);
        Object andCoerceProperty$Ex5 = C1158runtime.setAndCoerceProperty$Ex(Lit105, Lit34, Lit35, Lit5);
        Object andCoerceProperty$Ex6 = C1158runtime.setAndCoerceProperty$Ex(Lit105, Lit64, Lit65, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit105, Lit66, Lit136, Lit5);
    }

    static Object lambda34() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit139, Lit32, Lit35, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit139, Lit34, Lit35, Lit5);
    }

    static Object lambda35() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit139, Lit32, Lit35, Lit5);
        return C1158runtime.setAndCoerceProperty$Ex(Lit139, Lit34, Lit35, Lit5);
    }

    static Object lambda36() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit142, Lit143, "https://makeroid-default-firebase.firebaseio.com/", Lit7);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit142, Lit144, "poddarrupak2808@gmail:com/", Lit7);
        Object andCoerceProperty$Ex3 = C1158runtime.setAndCoerceProperty$Ex(Lit142, Lit145, "UEjIRP94GuGeF0VgOtwgPTAhU3xEeYszzofLc6wf", Lit7);
        Object andCoerceProperty$Ex4 = C1158runtime.setAndCoerceProperty$Ex(Lit142, Lit146, "https://hackumass-3445e.firebaseio.com/", Lit7);
        return C1158runtime.setAndCoerceProperty$Ex(Lit142, Lit147, "HackUMass", Lit7);
    }

    static Object lambda37() {
        Object andCoerceProperty$Ex = C1158runtime.setAndCoerceProperty$Ex(Lit142, Lit143, "https://makeroid-default-firebase.firebaseio.com/", Lit7);
        Object andCoerceProperty$Ex2 = C1158runtime.setAndCoerceProperty$Ex(Lit142, Lit144, "poddarrupak2808@gmail:com/", Lit7);
        Object andCoerceProperty$Ex3 = C1158runtime.setAndCoerceProperty$Ex(Lit142, Lit145, "UEjIRP94GuGeF0VgOtwgPTAhU3xEeYszzofLc6wf", Lit7);
        Object andCoerceProperty$Ex4 = C1158runtime.setAndCoerceProperty$Ex(Lit142, Lit146, "https://hackumass-3445e.firebaseio.com/", Lit7);
        return C1158runtime.setAndCoerceProperty$Ex(Lit142, Lit147, "HackUMass", Lit7);
    }

    static Object lambda38() {
        return C1158runtime.setAndCoerceProperty$Ex(Lit20, Lit27, Lit152, Lit5);
    }

    static Object lambda39() {
        return C1158runtime.setAndCoerceProperty$Ex(Lit20, Lit27, Lit152, Lit5);
    }

    static Object lambda40() {
        return C1158runtime.setAndCoerceProperty$Ex(Lit155, Lit156, Lit53, Lit5);
    }

    static Object lambda41() {
        return C1158runtime.setAndCoerceProperty$Ex(Lit155, Lit156, Lit53, Lit5);
    }

    public Object Clock1$Timer() {
        C1158runtime.setThisForm();
        return C1158runtime.getProperty$1(Lit41, Lit158) != Boolean.FALSE ? C1158runtime.setAndCoerceProperty$Ex(Lit105, Lit38, C1158runtime.callYailPrimitive(strings.string$Mnappend, LList.list2(C1158runtime.getProperty$1(Lit105, Lit38), C1158runtime.callComponentMethod(Lit41, Lit159, LList.list1(C1158runtime.callComponentMethod(Lit41, Lit160, LList.Empty, LList.Empty)), Lit161)), Lit162, "join"), Lit7) : Values.empty;
    }

    public Object Clock2$Timer() {
        C1158runtime.setThisForm();
        Object[] objArr = new Object[2];
        Object[] objArr2 = objArr;
        objArr[0] = lambda$Fn41;
        Object[] objArr3 = objArr2;
        Object[] objArr4 = objArr3;
        objArr3[1] = lambda$Fn42;
        if (C1158runtime.processAndDelayed$V(objArr4) != Boolean.FALSE) {
            Object callComponentMethod = C1158runtime.callComponentMethod(Lit142, Lit170, LList.list2("0001", C1158runtime.callYailPrimitive(strings.string$Mnappend, LList.list3(C1158runtime.getProperty$1(Lit93, Lit38), "*", C1158runtime.getProperty$1(Lit105, Lit38)), Lit171, "join")), Lit172);
        }
        Object[] objArr5 = new Object[2];
        Object[] objArr6 = objArr5;
        objArr5[0] = lambda$Fn43;
        Object[] objArr7 = objArr6;
        Object[] objArr8 = objArr7;
        objArr7[1] = lambda$Fn44;
        if (C1158runtime.processAndDelayed$V(objArr8) != Boolean.FALSE) {
            Object callComponentMethod2 = C1158runtime.callComponentMethod(Lit142, Lit170, LList.list2("0002", C1158runtime.callYailPrimitive(strings.string$Mnappend, LList.list3(C1158runtime.getProperty$1(Lit93, Lit38), "*", C1158runtime.getProperty$1(Lit105, Lit38)), Lit175, "join")), Lit176);
        }
        Object[] objArr9 = new Object[2];
        Object[] objArr10 = objArr9;
        objArr9[0] = lambda$Fn45;
        Object[] objArr11 = objArr10;
        Object[] objArr12 = objArr11;
        objArr11[1] = lambda$Fn46;
        if (C1158runtime.processAndDelayed$V(objArr12) != Boolean.FALSE) {
            Object callComponentMethod3 = C1158runtime.callComponentMethod(Lit142, Lit170, LList.list2("0003", C1158runtime.callYailPrimitive(strings.string$Mnappend, LList.list3(C1158runtime.getProperty$1(Lit93, Lit38), "*", C1158runtime.getProperty$1(Lit105, Lit38)), Lit179, "join")), Lit180);
        }
        Object[] objArr13 = new Object[2];
        Object[] objArr14 = objArr13;
        objArr13[0] = lambda$Fn47;
        Object[] objArr15 = objArr14;
        Object[] objArr16 = objArr15;
        objArr15[1] = lambda$Fn48;
        if (C1158runtime.processAndDelayed$V(objArr16) != Boolean.FALSE) {
            Object callComponentMethod4 = C1158runtime.callComponentMethod(Lit142, Lit170, LList.list2("0004", C1158runtime.callYailPrimitive(strings.string$Mnappend, LList.list3(C1158runtime.getProperty$1(Lit93, Lit38), "*", C1158runtime.getProperty$1(Lit105, Lit38)), Lit183, "join")), Lit184);
        }
        Object[] objArr17 = new Object[2];
        Object[] objArr18 = objArr17;
        objArr17[0] = lambda$Fn49;
        Object[] objArr19 = objArr18;
        Object[] objArr20 = objArr19;
        objArr19[1] = lambda$Fn50;
        return C1158runtime.processAndDelayed$V(objArr20) != Boolean.FALSE ? C1158runtime.callComponentMethod(Lit142, Lit170, LList.list2("0005", C1158runtime.callYailPrimitive(strings.string$Mnappend, LList.list3(C1158runtime.getProperty$1(Lit93, Lit38), "*", C1158runtime.getProperty$1(Lit105, Lit38)), Lit187, "join")), Lit188) : Values.empty;
    }

    static Object lambda42() {
        return C1158runtime.callYailPrimitive(strings.string$Eq$Qu, LList.list2(C1158runtime.getProperty$1(Lit93, Lit38), "Rupak"), Lit168, "text=");
    }

    static Object lambda43() {
        return C1158runtime.callYailPrimitive(C1158runtime.yail$Mnnot$Mnequal$Qu, LList.list2(C1158runtime.getProperty$1(Lit105, Lit38), ""), Lit169, "not =");
    }

    static Object lambda44() {
        return C1158runtime.callYailPrimitive(strings.string$Eq$Qu, LList.list2(C1158runtime.getProperty$1(Lit93, Lit38), "Akshat"), Lit173, "text=");
    }

    static Object lambda45() {
        return C1158runtime.callYailPrimitive(C1158runtime.yail$Mnnot$Mnequal$Qu, LList.list2(C1158runtime.getProperty$1(Lit105, Lit38), ""), Lit174, "not =");
    }

    static Object lambda46() {
        return C1158runtime.callYailPrimitive(strings.string$Eq$Qu, LList.list2(C1158runtime.getProperty$1(Lit93, Lit38), "Siddhanth"), Lit177, "text=");
    }

    static Object lambda47() {
        return C1158runtime.callYailPrimitive(C1158runtime.yail$Mnnot$Mnequal$Qu, LList.list2(C1158runtime.getProperty$1(Lit105, Lit38), ""), Lit178, "not =");
    }

    static Object lambda48() {
        return C1158runtime.callYailPrimitive(strings.string$Eq$Qu, LList.list2(C1158runtime.getProperty$1(Lit93, Lit38), "Saiyyam"), Lit181, "text=");
    }

    static Object lambda49() {
        return C1158runtime.callYailPrimitive(C1158runtime.yail$Mnnot$Mnequal$Qu, LList.list2(C1158runtime.getProperty$1(Lit105, Lit38), ""), Lit182, "not =");
    }

    static Object lambda50() {
        return C1158runtime.callYailPrimitive(strings.string$Eq$Qu, LList.list2(C1158runtime.getProperty$1(Lit93, Lit38), "Prakhar"), Lit185, "text=");
    }

    static Object lambda51() {
        return C1158runtime.callYailPrimitive(C1158runtime.yail$Mnnot$Mnequal$Qu, LList.list2(C1158runtime.getProperty$1(Lit105, Lit38), ""), Lit186, "not =");
    }

    public String getSimpleName(Object obj) {
        return obj.getClass().getSimpleName();
    }

    public void androidLogForm(Object message) {
    }

    public void addToFormEnvironment(Symbol symbol, Object obj) {
        Symbol name = symbol;
        Object object = obj;
        Object[] objArr = new Object[4];
        Object[] objArr2 = objArr;
        objArr[0] = "Adding ~A to env ~A with value ~A";
        Object[] objArr3 = objArr2;
        Object[] objArr4 = objArr3;
        objArr3[1] = name;
        Object[] objArr5 = objArr4;
        Object[] objArr6 = objArr5;
        objArr5[2] = this.form$Mnenvironment;
        Object[] objArr7 = objArr6;
        Object[] objArr8 = objArr7;
        objArr7[3] = object;
        androidLogForm(Format.formatToString(0, objArr8));
        this.form$Mnenvironment.put(name, object);
    }

    public Object lookupInFormEnvironment(Symbol symbol, Object obj) {
        Object obj2;
        Symbol name = symbol;
        Object default$Mnvalue = obj;
        int i = ((this.form$Mnenvironment == null ? 1 : 0) + 1) & 1;
        if (i == 0 ? i == 0 : !this.form$Mnenvironment.isBound(name)) {
            obj2 = default$Mnvalue;
        } else {
            obj2 = this.form$Mnenvironment.get(name);
        }
        return obj2;
    }

    public boolean isBoundInFormEnvironment(Symbol symbol) {
        return this.form$Mnenvironment.isBound(symbol);
    }

    public void addToGlobalVarEnvironment(Symbol symbol, Object obj) {
        Symbol name = symbol;
        Object object = obj;
        Object[] objArr = new Object[4];
        Object[] objArr2 = objArr;
        objArr[0] = "Adding ~A to env ~A with value ~A";
        Object[] objArr3 = objArr2;
        Object[] objArr4 = objArr3;
        objArr3[1] = name;
        Object[] objArr5 = objArr4;
        Object[] objArr6 = objArr5;
        objArr5[2] = this.global$Mnvar$Mnenvironment;
        Object[] objArr7 = objArr6;
        Object[] objArr8 = objArr7;
        objArr7[3] = object;
        androidLogForm(Format.formatToString(0, objArr8));
        this.global$Mnvar$Mnenvironment.put(name, object);
    }

    public void addToEvents(Object obj, Object obj2) {
        this.events$Mnto$Mnregister = C1175lists.cons(C1175lists.cons(obj, obj2), this.events$Mnto$Mnregister);
    }

    public void addToComponents(Object obj, Object obj2, Object obj3, Object obj4) {
        this.components$Mnto$Mncreate = C1175lists.cons(LList.list4(obj, obj2, obj3, obj4), this.components$Mnto$Mncreate);
    }

    public void addToGlobalVars(Object obj, Object obj2) {
        this.global$Mnvars$Mnto$Mncreate = C1175lists.cons(LList.list2(obj, obj2), this.global$Mnvars$Mnto$Mncreate);
    }

    public void addToFormDoAfterCreation(Object obj) {
        this.form$Mndo$Mnafter$Mncreation = C1175lists.cons(obj, this.form$Mndo$Mnafter$Mncreation);
    }

    public void sendError(Object obj) {
        Object obj2 = obj;
        RetValManager.sendError(obj2 == null ? null : obj2.toString());
    }

    public void processException(Object obj) {
        Object ex = obj;
        Object apply1 = Scheme.applyToArgs.apply1(GetNamedPart.getNamedPart.apply2(ex, Lit1));
        RuntimeErrorAlert.alert(this, apply1 == null ? null : apply1.toString(), ex instanceof YailRuntimeError ? ((YailRuntimeError) ex).getErrorType() : "Runtime Error", "End Application");
    }

    public boolean dispatchEvent(Component component, String str, String str2, Object[] objArr) {
        boolean z;
        boolean z2;
        Component componentObject = component;
        String registeredComponentName = str;
        String eventName = str2;
        Object[] args = objArr;
        SimpleSymbol registeredObject = misc.string$To$Symbol(registeredComponentName);
        if (!isBoundInFormEnvironment(registeredObject)) {
            EventDispatcher.unregisterEventForDelegation(this, registeredComponentName, eventName);
            z = false;
        } else if (lookupInFormEnvironment(registeredObject) == componentObject) {
            try {
                Object apply2 = Scheme.apply.apply2(lookupHandler(registeredComponentName, eventName), LList.makeList(args, 0));
                z2 = true;
            } catch (PermissionException e) {
                PermissionException exception = e;
                exception.printStackTrace();
                boolean x = this == componentObject;
                if (!x ? !x : !IsEqual.apply(eventName, "PermissionNeeded")) {
                    PermissionDenied(componentObject, eventName, exception.getPermissionNeeded());
                } else {
                    processException(exception);
                }
                z2 = false;
            } catch (Throwable th) {
                Throwable exception2 = th;
                androidLogForm(exception2.getMessage());
                exception2.printStackTrace();
                processException(exception2);
                z2 = false;
            }
            z = z2;
        } else {
            z = false;
        }
        return z;
    }

    public void dispatchGenericEvent(Component component, String str, boolean z, Object[] objArr) {
        Boolean bool;
        Component componentObject = component;
        String eventName = str;
        boolean notAlreadyHandled = z;
        Object[] args = objArr;
        Object[] objArr2 = new Object[4];
        Object[] objArr3 = objArr2;
        objArr2[0] = "any$";
        Object[] objArr4 = objArr3;
        Object[] objArr5 = objArr4;
        objArr4[1] = getSimpleName(componentObject);
        Object[] objArr6 = objArr5;
        Object[] objArr7 = objArr6;
        objArr6[2] = "$";
        Object[] objArr8 = objArr7;
        Object[] objArr9 = objArr8;
        objArr8[3] = eventName;
        Object handler = lookupInFormEnvironment(misc.string$To$Symbol(strings.stringAppend(objArr9)));
        if (handler != Boolean.FALSE) {
            try {
                Apply apply = Scheme.apply;
                Object obj = handler;
                Component component2 = componentObject;
                if (notAlreadyHandled) {
                    bool = Boolean.TRUE;
                } else {
                    bool = Boolean.FALSE;
                }
                Object apply2 = apply.apply2(obj, C1175lists.cons(component2, C1175lists.cons(bool, LList.makeList(args, 0))));
            } catch (PermissionException e) {
                PermissionException exception = e;
                exception.printStackTrace();
                boolean x = this == componentObject;
                if (!x ? !x : !IsEqual.apply(eventName, "PermissionNeeded")) {
                    PermissionDenied(componentObject, eventName, exception.getPermissionNeeded());
                } else {
                    processException(exception);
                }
            } catch (Throwable th) {
                Throwable exception2 = th;
                androidLogForm(exception2.getMessage());
                exception2.printStackTrace();
                processException(exception2);
            }
        }
    }

    public Object lookupHandler(Object obj, Object obj2) {
        Object eventName = obj2;
        Object obj3 = obj;
        String obj4 = obj3 == null ? null : obj3.toString();
        Object obj5 = eventName;
        return lookupInFormEnvironment(misc.string$To$Symbol(EventDispatcher.makeFullEventName(obj4, obj5 == null ? null : obj5.toString())));
    }

    /* JADX WARNING: type inference failed for: r3v7 */
    /* JADX WARNING: type inference failed for: r2v6 */
    /* JADX WARNING: type inference failed for: r4v7 */
    /* JADX WARNING: type inference failed for: r4v8 */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void $define() {
        /*
            r20 = this;
            r0 = r20
            kawa.standard.Scheme r12 = kawa.standard.Scheme.getInstance()
            gnu.expr.Language.setDefaults(r12)
            r12 = r0
            r12.run()     // Catch:{ Exception -> 0x006c }
        L_0x000d:
            r12 = r0
            Screen1 = r12
            r12 = r0
            gnu.mapping.SimpleSymbol r13 = Lit0
            r14 = r0
            r12.addToFormEnvironment(r13, r14)
            r12 = r0
            gnu.lists.LList r12 = r12.events$Mnto$Mnregister
            r1 = r12
            r12 = r1
            r2 = r12
        L_0x001d:
            r12 = r2
            gnu.lists.LList r13 = gnu.lists.LList.Empty
            if (r12 != r13) goto L_0x007d
            r12 = r0
            gnu.lists.LList r12 = r12.components$Mnto$Mncreate     // Catch:{ YailRuntimeError -> 0x014d }
            gnu.lists.LList r12 = kawa.lib.C1175lists.reverse(r12)     // Catch:{ YailRuntimeError -> 0x014d }
            r1 = r12
            r12 = r0
            gnu.mapping.SimpleSymbol r13 = Lit2     // Catch:{ YailRuntimeError -> 0x014d }
            gnu.expr.ModuleMethod r14 = lambda$Fn1     // Catch:{ YailRuntimeError -> 0x014d }
            r12.addToGlobalVars(r13, r14)     // Catch:{ YailRuntimeError -> 0x014d }
            r12 = r1
            r2 = r12
            r12 = r0
            r3 = r12
            r12 = r2
            r4 = r12
        L_0x0038:
            r12 = r4
            gnu.lists.LList r13 = gnu.lists.LList.Empty     // Catch:{ YailRuntimeError -> 0x014d }
            if (r12 != r13) goto L_0x00c4
            r12 = r0
            gnu.lists.LList r12 = r12.global$Mnvars$Mnto$Mncreate     // Catch:{ YailRuntimeError -> 0x014d }
            gnu.lists.LList r12 = kawa.lib.C1175lists.reverse(r12)     // Catch:{ YailRuntimeError -> 0x014d }
            r2 = r12
            r12 = r0
            r3 = r12
            r12 = r2
            r4 = r12
        L_0x0049:
            r12 = r4
            gnu.lists.LList r13 = gnu.lists.LList.Empty     // Catch:{ YailRuntimeError -> 0x014d }
            if (r12 != r13) goto L_0x0196
            r12 = r0
            gnu.lists.LList r12 = r12.form$Mndo$Mnafter$Mncreation     // Catch:{ YailRuntimeError -> 0x014d }
            gnu.lists.LList r12 = kawa.lib.C1175lists.reverse(r12)     // Catch:{ YailRuntimeError -> 0x014d }
            r2 = r12
        L_0x0056:
            r12 = r2
            gnu.lists.LList r13 = gnu.lists.LList.Empty     // Catch:{ YailRuntimeError -> 0x014d }
            if (r12 != r13) goto L_0x0214
            r12 = r1
            r2 = r12
            r12 = r2
            r3 = r12
        L_0x005f:
            r12 = r3
            gnu.lists.LList r13 = gnu.lists.LList.Empty     // Catch:{ YailRuntimeError -> 0x014d }
            if (r12 != r13) goto L_0x0250
            r12 = r2
            r3 = r12
        L_0x0066:
            r12 = r3
            gnu.lists.LList r13 = gnu.lists.LList.Empty     // Catch:{ YailRuntimeError -> 0x014d }
            if (r12 != r13) goto L_0x02a4
        L_0x006b:
            return
        L_0x006c:
            r12 = move-exception
            r1 = r12
            r12 = r0
            r13 = r1
            java.lang.String r13 = r13.getMessage()
            r12.androidLogForm(r13)
            r12 = r0
            r13 = r1
            r12.processException(r13)
            goto L_0x000d
        L_0x007d:
            r12 = r2
            r18 = r12
            r12 = r18
            r13 = r18
            r4 = r13
            gnu.lists.Pair r12 = (gnu.lists.Pair) r12     // Catch:{ ClassCastException -> 0x02f8 }
            r3 = r12
            r12 = r3
            java.lang.Object r12 = r12.getCar()
            r4 = r12
            r12 = r0
            gnu.expr.GenericProc r13 = kawa.lib.C1175lists.car
            r14 = r4
            java.lang.Object r13 = r13.apply1(r14)
            r18 = r13
            r13 = r18
            r14 = r18
            if (r14 != 0) goto L_0x00ba
            r13 = 0
        L_0x009f:
            gnu.expr.GenericProc r14 = kawa.lib.C1175lists.cdr
            r15 = r4
            java.lang.Object r14 = r14.apply1(r15)
            r18 = r14
            r14 = r18
            r15 = r18
            if (r15 != 0) goto L_0x00bf
            r14 = 0
        L_0x00af:
            com.google.appinventor.components.runtime.EventDispatcher.registerEventForDelegation(r12, r13, r14)
            r12 = r3
            java.lang.Object r12 = r12.getCdr()
            r2 = r12
            goto L_0x001d
        L_0x00ba:
            java.lang.String r13 = r13.toString()
            goto L_0x009f
        L_0x00bf:
            java.lang.String r14 = r14.toString()
            goto L_0x00af
        L_0x00c4:
            r12 = r4
            r18 = r12
            r12 = r18
            r13 = r18
            r6 = r13
            gnu.lists.Pair r12 = (gnu.lists.Pair) r12     // Catch:{ ClassCastException -> 0x012d }
            r5 = r12
            r12 = r5
            java.lang.Object r12 = r12.getCar()     // Catch:{ YailRuntimeError -> 0x014d }
            r6 = r12
            gnu.expr.GenericProc r12 = kawa.lib.C1175lists.caddr     // Catch:{ YailRuntimeError -> 0x014d }
            r13 = r6
            java.lang.Object r12 = r12.apply1(r13)     // Catch:{ YailRuntimeError -> 0x014d }
            gnu.expr.GenericProc r13 = kawa.lib.C1175lists.cadddr     // Catch:{ YailRuntimeError -> 0x014d }
            r14 = r6
            java.lang.Object r13 = r13.apply1(r14)     // Catch:{ YailRuntimeError -> 0x014d }
            gnu.expr.GenericProc r13 = kawa.lib.C1175lists.cadr     // Catch:{ YailRuntimeError -> 0x014d }
            r14 = r6
            java.lang.Object r13 = r13.apply1(r14)     // Catch:{ YailRuntimeError -> 0x014d }
            r14 = r0
            gnu.expr.GenericProc r15 = kawa.lib.C1175lists.car     // Catch:{ YailRuntimeError -> 0x014d }
            r16 = r6
            java.lang.Object r15 = r15.apply1(r16)     // Catch:{ YailRuntimeError -> 0x014d }
            r18 = r15
            r15 = r18
            r16 = r18
            r10 = r16
            gnu.mapping.Symbol r15 = (gnu.mapping.Symbol) r15     // Catch:{ ClassCastException -> 0x0156 }
            java.lang.Object r14 = r14.lookupInFormEnvironment(r15)     // Catch:{ YailRuntimeError -> 0x014d }
            r9 = r14
            r8 = r13
            r7 = r12
            gnu.kawa.reflect.Invoke r12 = gnu.kawa.reflect.Invoke.make     // Catch:{ YailRuntimeError -> 0x014d }
            r13 = r8
            r14 = r9
            java.lang.Object r12 = r12.apply2(r13, r14)     // Catch:{ YailRuntimeError -> 0x014d }
            r10 = r12
            gnu.kawa.reflect.SlotSet r12 = gnu.kawa.reflect.SlotSet.set$Mnfield$Ex     // Catch:{ YailRuntimeError -> 0x014d }
            r13 = r0
            r14 = r7
            r15 = r10
            java.lang.Object r12 = r12.apply3(r13, r14, r15)     // Catch:{ YailRuntimeError -> 0x014d }
            r12 = r0
            r13 = r7
            r18 = r13
            r13 = r18
            r14 = r18
            r11 = r14
            gnu.mapping.Symbol r13 = (gnu.mapping.Symbol) r13     // Catch:{ ClassCastException -> 0x0176 }
            r14 = r10
            r12.addToFormEnvironment(r13, r14)     // Catch:{ YailRuntimeError -> 0x014d }
            r12 = r5
            java.lang.Object r12 = r12.getCdr()     // Catch:{ YailRuntimeError -> 0x014d }
            r4 = r12
            goto L_0x0038
        L_0x012d:
            r12 = move-exception
            gnu.mapping.WrongType r13 = new gnu.mapping.WrongType     // Catch:{ YailRuntimeError -> 0x014d }
            r18 = r12
            r19 = r13
            r12 = r19
            r13 = r18
            r14 = r19
            r18 = r13
            r19 = r14
            r13 = r19
            r14 = r18
            java.lang.String r15 = "arg0"
            r16 = -2
            r17 = r6
            r13.<init>(r14, r15, r16, r17)     // Catch:{ YailRuntimeError -> 0x014d }
            throw r12     // Catch:{ YailRuntimeError -> 0x014d }
        L_0x014d:
            r12 = move-exception
            r1 = r12
            r12 = r0
            r13 = r1
            r12.processException(r13)
            goto L_0x006b
        L_0x0156:
            r12 = move-exception
            gnu.mapping.WrongType r13 = new gnu.mapping.WrongType     // Catch:{ YailRuntimeError -> 0x014d }
            r18 = r12
            r19 = r13
            r12 = r19
            r13 = r18
            r14 = r19
            r18 = r13
            r19 = r14
            r13 = r19
            r14 = r18
            java.lang.String r15 = "lookup-in-form-environment"
            r16 = 0
            r17 = r10
            r13.<init>(r14, r15, r16, r17)     // Catch:{ YailRuntimeError -> 0x014d }
            throw r12     // Catch:{ YailRuntimeError -> 0x014d }
        L_0x0176:
            r12 = move-exception
            gnu.mapping.WrongType r13 = new gnu.mapping.WrongType     // Catch:{ YailRuntimeError -> 0x014d }
            r18 = r12
            r19 = r13
            r12 = r19
            r13 = r18
            r14 = r19
            r18 = r13
            r19 = r14
            r13 = r19
            r14 = r18
            java.lang.String r15 = "add-to-form-environment"
            r16 = 0
            r17 = r11
            r13.<init>(r14, r15, r16, r17)     // Catch:{ YailRuntimeError -> 0x014d }
            throw r12     // Catch:{ YailRuntimeError -> 0x014d }
        L_0x0196:
            r12 = r4
            r18 = r12
            r12 = r18
            r13 = r18
            r6 = r13
            gnu.lists.Pair r12 = (gnu.lists.Pair) r12     // Catch:{ ClassCastException -> 0x01d4 }
            r5 = r12
            r12 = r5
            java.lang.Object r12 = r12.getCar()     // Catch:{ YailRuntimeError -> 0x014d }
            r6 = r12
            gnu.expr.GenericProc r12 = kawa.lib.C1175lists.car     // Catch:{ YailRuntimeError -> 0x014d }
            r13 = r6
            java.lang.Object r12 = r12.apply1(r13)     // Catch:{ YailRuntimeError -> 0x014d }
            gnu.expr.GenericProc r13 = kawa.lib.C1175lists.cadr     // Catch:{ YailRuntimeError -> 0x014d }
            r14 = r6
            java.lang.Object r13 = r13.apply1(r14)     // Catch:{ YailRuntimeError -> 0x014d }
            r8 = r13
            r7 = r12
            r12 = r0
            r13 = r7
            r18 = r13
            r13 = r18
            r14 = r18
            r9 = r14
            gnu.mapping.Symbol r13 = (gnu.mapping.Symbol) r13     // Catch:{ ClassCastException -> 0x01f4 }
            gnu.kawa.functions.ApplyToArgs r14 = kawa.standard.Scheme.applyToArgs     // Catch:{ YailRuntimeError -> 0x014d }
            r15 = r8
            java.lang.Object r14 = r14.apply1(r15)     // Catch:{ YailRuntimeError -> 0x014d }
            r12.addToGlobalVarEnvironment(r13, r14)     // Catch:{ YailRuntimeError -> 0x014d }
            r12 = r5
            java.lang.Object r12 = r12.getCdr()     // Catch:{ YailRuntimeError -> 0x014d }
            r4 = r12
            goto L_0x0049
        L_0x01d4:
            r12 = move-exception
            gnu.mapping.WrongType r13 = new gnu.mapping.WrongType     // Catch:{ YailRuntimeError -> 0x014d }
            r18 = r12
            r19 = r13
            r12 = r19
            r13 = r18
            r14 = r19
            r18 = r13
            r19 = r14
            r13 = r19
            r14 = r18
            java.lang.String r15 = "arg0"
            r16 = -2
            r17 = r6
            r13.<init>(r14, r15, r16, r17)     // Catch:{ YailRuntimeError -> 0x014d }
            throw r12     // Catch:{ YailRuntimeError -> 0x014d }
        L_0x01f4:
            r12 = move-exception
            gnu.mapping.WrongType r13 = new gnu.mapping.WrongType     // Catch:{ YailRuntimeError -> 0x014d }
            r18 = r12
            r19 = r13
            r12 = r19
            r13 = r18
            r14 = r19
            r18 = r13
            r19 = r14
            r13 = r19
            r14 = r18
            java.lang.String r15 = "add-to-global-var-environment"
            r16 = 0
            r17 = r9
            r13.<init>(r14, r15, r16, r17)     // Catch:{ YailRuntimeError -> 0x014d }
            throw r12     // Catch:{ YailRuntimeError -> 0x014d }
        L_0x0214:
            r12 = r2
            r18 = r12
            r12 = r18
            r13 = r18
            r4 = r13
            gnu.lists.Pair r12 = (gnu.lists.Pair) r12     // Catch:{ ClassCastException -> 0x0230 }
            r3 = r12
            r12 = r3
            java.lang.Object r12 = r12.getCar()     // Catch:{ YailRuntimeError -> 0x014d }
            java.lang.Object r12 = kawa.lib.misc.force(r12)     // Catch:{ YailRuntimeError -> 0x014d }
            r12 = r3
            java.lang.Object r12 = r12.getCdr()     // Catch:{ YailRuntimeError -> 0x014d }
            r2 = r12
            goto L_0x0056
        L_0x0230:
            r12 = move-exception
            gnu.mapping.WrongType r13 = new gnu.mapping.WrongType     // Catch:{ YailRuntimeError -> 0x014d }
            r18 = r12
            r19 = r13
            r12 = r19
            r13 = r18
            r14 = r19
            r18 = r13
            r19 = r14
            r13 = r19
            r14 = r18
            java.lang.String r15 = "arg0"
            r16 = -2
            r17 = r4
            r13.<init>(r14, r15, r16, r17)     // Catch:{ YailRuntimeError -> 0x014d }
            throw r12     // Catch:{ YailRuntimeError -> 0x014d }
        L_0x0250:
            r12 = r3
            r18 = r12
            r12 = r18
            r13 = r18
            r5 = r13
            gnu.lists.Pair r12 = (gnu.lists.Pair) r12     // Catch:{ ClassCastException -> 0x0284 }
            r4 = r12
            r12 = r4
            java.lang.Object r12 = r12.getCar()     // Catch:{ YailRuntimeError -> 0x014d }
            r5 = r12
            gnu.expr.GenericProc r12 = kawa.lib.C1175lists.caddr     // Catch:{ YailRuntimeError -> 0x014d }
            r13 = r5
            java.lang.Object r12 = r12.apply1(r13)     // Catch:{ YailRuntimeError -> 0x014d }
            gnu.expr.GenericProc r12 = kawa.lib.C1175lists.cadddr     // Catch:{ YailRuntimeError -> 0x014d }
            r13 = r5
            java.lang.Object r12 = r12.apply1(r13)     // Catch:{ YailRuntimeError -> 0x014d }
            r6 = r12
            r12 = r6
            java.lang.Boolean r13 = java.lang.Boolean.FALSE     // Catch:{ YailRuntimeError -> 0x014d }
            if (r12 == r13) goto L_0x027c
            gnu.kawa.functions.ApplyToArgs r12 = kawa.standard.Scheme.applyToArgs     // Catch:{ YailRuntimeError -> 0x014d }
            r13 = r6
            java.lang.Object r12 = r12.apply1(r13)     // Catch:{ YailRuntimeError -> 0x014d }
        L_0x027c:
            r12 = r4
            java.lang.Object r12 = r12.getCdr()     // Catch:{ YailRuntimeError -> 0x014d }
            r3 = r12
            goto L_0x005f
        L_0x0284:
            r12 = move-exception
            gnu.mapping.WrongType r13 = new gnu.mapping.WrongType     // Catch:{ YailRuntimeError -> 0x014d }
            r18 = r12
            r19 = r13
            r12 = r19
            r13 = r18
            r14 = r19
            r18 = r13
            r19 = r14
            r13 = r19
            r14 = r18
            java.lang.String r15 = "arg0"
            r16 = -2
            r17 = r5
            r13.<init>(r14, r15, r16, r17)     // Catch:{ YailRuntimeError -> 0x014d }
            throw r12     // Catch:{ YailRuntimeError -> 0x014d }
        L_0x02a4:
            r12 = r3
            r18 = r12
            r12 = r18
            r13 = r18
            r5 = r13
            gnu.lists.Pair r12 = (gnu.lists.Pair) r12     // Catch:{ ClassCastException -> 0x02d8 }
            r4 = r12
            r12 = r4
            java.lang.Object r12 = r12.getCar()     // Catch:{ YailRuntimeError -> 0x014d }
            r5 = r12
            gnu.expr.GenericProc r12 = kawa.lib.C1175lists.caddr     // Catch:{ YailRuntimeError -> 0x014d }
            r13 = r5
            java.lang.Object r12 = r12.apply1(r13)     // Catch:{ YailRuntimeError -> 0x014d }
            gnu.expr.GenericProc r13 = kawa.lib.C1175lists.cadddr     // Catch:{ YailRuntimeError -> 0x014d }
            r14 = r5
            java.lang.Object r13 = r13.apply1(r14)     // Catch:{ YailRuntimeError -> 0x014d }
            r6 = r12
            r12 = r0
            gnu.kawa.reflect.SlotGet r13 = gnu.kawa.reflect.SlotGet.field     // Catch:{ YailRuntimeError -> 0x014d }
            r14 = r0
            r15 = r6
            java.lang.Object r13 = r13.apply2(r14, r15)     // Catch:{ YailRuntimeError -> 0x014d }
            r12.callInitialize(r13)     // Catch:{ YailRuntimeError -> 0x014d }
            r12 = r4
            java.lang.Object r12 = r12.getCdr()     // Catch:{ YailRuntimeError -> 0x014d }
            r3 = r12
            goto L_0x0066
        L_0x02d8:
            r12 = move-exception
            gnu.mapping.WrongType r13 = new gnu.mapping.WrongType     // Catch:{ YailRuntimeError -> 0x014d }
            r18 = r12
            r19 = r13
            r12 = r19
            r13 = r18
            r14 = r19
            r18 = r13
            r19 = r14
            r13 = r19
            r14 = r18
            java.lang.String r15 = "arg0"
            r16 = -2
            r17 = r5
            r13.<init>(r14, r15, r16, r17)     // Catch:{ YailRuntimeError -> 0x014d }
            throw r12     // Catch:{ YailRuntimeError -> 0x014d }
        L_0x02f8:
            r12 = move-exception
            gnu.mapping.WrongType r13 = new gnu.mapping.WrongType
            r18 = r12
            r19 = r13
            r12 = r19
            r13 = r18
            r14 = r19
            r18 = r13
            r19 = r14
            r13 = r19
            r14 = r18
            java.lang.String r15 = "arg0"
            r16 = -2
            r17 = r4
            r13.<init>(r14, r15, r16, r17)
            throw r12
        */
        throw new UnsupportedOperationException("Method not decompiled: p004io.kodular.poddarrupak2808.HackUMass.Screen1.$define():void");
    }

    public static SimpleSymbol lambda1symbolAppend$V(Object[] objArr) {
        WrongType wrongType;
        WrongType wrongType2;
        WrongType wrongType3;
        Object makeList = LList.makeList(objArr, 0);
        Object obj = makeList;
        Object obj2 = makeList;
        Apply apply = Scheme.apply;
        ModuleMethod moduleMethod = strings.string$Mnappend;
        Object obj3 = obj2;
        Object obj4 = LList.Empty;
        while (true) {
            Object obj5 = obj4;
            Object obj6 = obj3;
            if (obj6 == LList.Empty) {
                Object apply2 = apply.apply2(moduleMethod, LList.reverseInPlace(obj5));
                Object obj7 = apply2;
                try {
                    return misc.string$To$Symbol((CharSequence) apply2);
                } catch (ClassCastException e) {
                    ClassCastException classCastException = e;
                    WrongType wrongType4 = wrongType;
                    WrongType wrongType5 = new WrongType(classCastException, "string->symbol", 1, obj7);
                    throw wrongType4;
                }
            } else {
                Object obj8 = obj6;
                Object obj9 = obj8;
                try {
                    Pair arg0 = (Pair) obj8;
                    obj3 = arg0.getCdr();
                    Object car = arg0.getCar();
                    Object obj10 = car;
                    try {
                        obj4 = Pair.make(misc.symbol$To$String((Symbol) car), obj5);
                    } catch (ClassCastException e2) {
                        ClassCastException classCastException2 = e2;
                        WrongType wrongType6 = wrongType3;
                        WrongType wrongType7 = new WrongType(classCastException2, "symbol->string", 1, obj10);
                        throw wrongType6;
                    }
                } catch (ClassCastException e3) {
                    ClassCastException classCastException3 = e3;
                    WrongType wrongType8 = wrongType2;
                    WrongType wrongType9 = new WrongType(classCastException3, "arg0", -2, obj9);
                    throw wrongType8;
                }
            }
        }
    }

    static Object lambda2() {
        return null;
    }
}
