package androidx.browser.browseractions;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.support.p000v4.view.animation.LinearOutSlowInInterpolator;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.view.Window;

class BrowserActionsFallbackMenuDialog extends Dialog {
    private static final long ENTER_ANIMATION_DURATION_MS = 250;
    private static final long EXIT_ANIMATION_DURATION_MS = 150;
    private final View mContentView;

    BrowserActionsFallbackMenuDialog(Context context, View view) {
        View contentView = view;
        super(context);
        this.mContentView = contentView;
    }

    public void show() {
        ColorDrawable colorDrawable;
        Window window = getWindow();
        ColorDrawable colorDrawable2 = colorDrawable;
        ColorDrawable colorDrawable3 = new ColorDrawable(0);
        window.setBackgroundDrawable(colorDrawable2);
        startAnimation(true);
        super.show();
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() != 0) {
            return false;
        }
        dismiss();
        return true;
    }

    public void dismiss() {
        startAnimation(false);
    }

    private void startAnimation(boolean z) {
        LinearOutSlowInInterpolator linearOutSlowInInterpolator;
        C05241 r11;
        boolean isEnterAnimation = z;
        float from = isEnterAnimation ? 0.0f : 1.0f;
        float to = isEnterAnimation ? 1.0f : 0.0f;
        long duration = isEnterAnimation ? ENTER_ANIMATION_DURATION_MS : 150;
        this.mContentView.setScaleX(from);
        this.mContentView.setScaleY(from);
        ViewPropertyAnimator duration2 = this.mContentView.animate().scaleX(to).scaleY(to).setDuration(duration);
        LinearOutSlowInInterpolator linearOutSlowInInterpolator2 = linearOutSlowInInterpolator;
        LinearOutSlowInInterpolator linearOutSlowInInterpolator3 = new LinearOutSlowInInterpolator();
        ViewPropertyAnimator interpolator = duration2.setInterpolator(linearOutSlowInInterpolator2);
        C05241 r7 = r11;
        final boolean z2 = isEnterAnimation;
        C05241 r8 = new AnimatorListenerAdapter(this) {
            final /* synthetic */ BrowserActionsFallbackMenuDialog this$0;

            {
                boolean z = r7;
                this.this$0 = r6;
            }

            public void onAnimationEnd(Animator animator) {
                Animator animator2 = animator;
                if (!z2) {
                    BrowserActionsFallbackMenuDialog.super.dismiss();
                }
            }
        };
        interpolator.setListener(r7).start();
    }
}
