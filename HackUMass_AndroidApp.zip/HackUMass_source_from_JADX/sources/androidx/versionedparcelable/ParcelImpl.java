package androidx.versionedparcelable;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.annotation.RestrictTo;
import android.support.annotation.RestrictTo.Scope;

@RestrictTo({Scope.LIBRARY})
public class ParcelImpl implements Parcelable {
    public static final Creator<ParcelImpl> CREATOR;
    private final VersionedParcelable mParcel;

    public ParcelImpl(VersionedParcelable versionedParcelable) {
        this.mParcel = versionedParcelable;
    }

    protected ParcelImpl(Parcel parcel) {
        VersionedParcelParcel versionedParcelParcel;
        VersionedParcelParcel versionedParcelParcel2 = versionedParcelParcel;
        VersionedParcelParcel versionedParcelParcel3 = new VersionedParcelParcel(parcel);
        this.mParcel = versionedParcelParcel2.readVersionedParcelable();
    }

    public <T extends VersionedParcelable> T getVersionedParcel() {
        return this.mParcel;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        VersionedParcelParcel versionedParcelParcel;
        int i2 = i;
        VersionedParcelParcel versionedParcelParcel2 = versionedParcelParcel;
        VersionedParcelParcel versionedParcelParcel3 = new VersionedParcelParcel(parcel);
        versionedParcelParcel2.writeVersionedParcelable(this.mParcel);
    }

    static {
        C05271 r2;
        C05271 r0 = r2;
        C05271 r1 = new Creator<ParcelImpl>() {
            public ParcelImpl createFromParcel(Parcel parcel) {
                ParcelImpl parcelImpl;
                ParcelImpl parcelImpl2 = parcelImpl;
                ParcelImpl parcelImpl3 = new ParcelImpl(parcel);
                return parcelImpl2;
            }

            public ParcelImpl[] newArray(int i) {
                return new ParcelImpl[i];
            }
        };
        CREATOR = r0;
    }
}
