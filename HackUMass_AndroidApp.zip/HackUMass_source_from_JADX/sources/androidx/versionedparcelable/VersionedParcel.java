package androidx.versionedparcelable;

import android.os.BadParcelableException;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.NetworkOnMainThreadException;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.annotation.RestrictTo.Scope;
import android.support.p000v4.util.C1526ArraySet;
import android.util.Size;
import android.util.SizeF;
import android.util.SparseBooleanArray;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamClass;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

@RestrictTo({Scope.LIBRARY_GROUP})
public abstract class VersionedParcel {
    private static final int EX_BAD_PARCELABLE = -2;
    private static final int EX_ILLEGAL_ARGUMENT = -3;
    private static final int EX_ILLEGAL_STATE = -5;
    private static final int EX_NETWORK_MAIN_THREAD = -6;
    private static final int EX_NULL_POINTER = -4;
    private static final int EX_PARCELABLE = -9;
    private static final int EX_SECURITY = -1;
    private static final int EX_UNSUPPORTED_OPERATION = -7;
    private static final String TAG = "VersionedParcel";
    private static final int TYPE_BINDER = 5;
    private static final int TYPE_PARCELABLE = 2;
    private static final int TYPE_SERIALIZABLE = 3;
    private static final int TYPE_STRING = 4;
    private static final int TYPE_VERSIONED_PARCELABLE = 1;

    public static class ParcelException extends RuntimeException {
        public ParcelException(Throwable th) {
            super(th);
        }
    }

    /* access modifiers changed from: protected */
    public abstract void closeField();

    /* access modifiers changed from: protected */
    public abstract VersionedParcel createSubParcel();

    /* access modifiers changed from: protected */
    public abstract boolean readBoolean();

    /* access modifiers changed from: protected */
    public abstract Bundle readBundle();

    /* access modifiers changed from: protected */
    public abstract byte[] readByteArray();

    /* access modifiers changed from: protected */
    public abstract double readDouble();

    /* access modifiers changed from: protected */
    public abstract boolean readField(int i);

    /* access modifiers changed from: protected */
    public abstract float readFloat();

    /* access modifiers changed from: protected */
    public abstract int readInt();

    /* access modifiers changed from: protected */
    public abstract long readLong();

    /* access modifiers changed from: protected */
    public abstract <T extends Parcelable> T readParcelable();

    /* access modifiers changed from: protected */
    public abstract String readString();

    /* access modifiers changed from: protected */
    public abstract IBinder readStrongBinder();

    /* access modifiers changed from: protected */
    public abstract void setOutputField(int i);

    /* access modifiers changed from: protected */
    public abstract void writeBoolean(boolean z);

    /* access modifiers changed from: protected */
    public abstract void writeBundle(Bundle bundle);

    /* access modifiers changed from: protected */
    public abstract void writeByteArray(byte[] bArr);

    /* access modifiers changed from: protected */
    public abstract void writeByteArray(byte[] bArr, int i, int i2);

    /* access modifiers changed from: protected */
    public abstract void writeDouble(double d);

    /* access modifiers changed from: protected */
    public abstract void writeFloat(float f);

    /* access modifiers changed from: protected */
    public abstract void writeInt(int i);

    /* access modifiers changed from: protected */
    public abstract void writeLong(long j);

    /* access modifiers changed from: protected */
    public abstract void writeParcelable(Parcelable parcelable);

    /* access modifiers changed from: protected */
    public abstract void writeString(String str);

    /* access modifiers changed from: protected */
    public abstract void writeStrongBinder(IBinder iBinder);

    /* access modifiers changed from: protected */
    public abstract void writeStrongInterface(IInterface iInterface);

    public VersionedParcel() {
    }

    public boolean isStream() {
        return false;
    }

    public void setSerializationFlags(boolean allowSerialization, boolean ignoreParcelables) {
    }

    public void writeStrongInterface(IInterface iInterface, int i) {
        IInterface val = iInterface;
        setOutputField(i);
        writeStrongInterface(val);
    }

    public void writeBundle(Bundle bundle, int i) {
        Bundle val = bundle;
        setOutputField(i);
        writeBundle(val);
    }

    public void writeBoolean(boolean z, int i) {
        boolean val = z;
        setOutputField(i);
        writeBoolean(val);
    }

    public void writeByteArray(byte[] bArr, int i) {
        byte[] b = bArr;
        setOutputField(i);
        writeByteArray(b);
    }

    public void writeByteArray(byte[] bArr, int i, int i2, int i3) {
        byte[] b = bArr;
        int offset = i;
        int len = i2;
        setOutputField(i3);
        writeByteArray(b, offset, len);
    }

    public void writeInt(int i, int i2) {
        int val = i;
        setOutputField(i2);
        writeInt(val);
    }

    public void writeLong(long j, int i) {
        long val = j;
        setOutputField(i);
        writeLong(val);
    }

    public void writeFloat(float f, int i) {
        float val = f;
        setOutputField(i);
        writeFloat(val);
    }

    public void writeDouble(double d, int i) {
        double val = d;
        setOutputField(i);
        writeDouble(val);
    }

    public void writeString(String str, int i) {
        String val = str;
        setOutputField(i);
        writeString(val);
    }

    public void writeStrongBinder(IBinder iBinder, int i) {
        IBinder val = iBinder;
        setOutputField(i);
        writeStrongBinder(val);
    }

    public void writeParcelable(Parcelable parcelable, int i) {
        Parcelable p = parcelable;
        setOutputField(i);
        writeParcelable(p);
    }

    public boolean readBoolean(boolean z, int i) {
        boolean def = z;
        if (!readField(i)) {
            return def;
        }
        return readBoolean();
    }

    public int readInt(int i, int i2) {
        int def = i;
        if (!readField(i2)) {
            return def;
        }
        return readInt();
    }

    public long readLong(long j, int i) {
        long def = j;
        if (!readField(i)) {
            return def;
        }
        return readLong();
    }

    public float readFloat(float f, int i) {
        float def = f;
        if (!readField(i)) {
            return def;
        }
        return readFloat();
    }

    public double readDouble(double d, int i) {
        double def = d;
        if (!readField(i)) {
            return def;
        }
        return readDouble();
    }

    public String readString(String str, int i) {
        String def = str;
        if (!readField(i)) {
            return def;
        }
        return readString();
    }

    public IBinder readStrongBinder(IBinder iBinder, int i) {
        IBinder def = iBinder;
        if (!readField(i)) {
            return def;
        }
        return readStrongBinder();
    }

    public byte[] readByteArray(byte[] bArr, int i) {
        byte[] def = bArr;
        if (!readField(i)) {
            return def;
        }
        return readByteArray();
    }

    public <T extends Parcelable> T readParcelable(T t, int i) {
        VersionedParcel def = t;
        if (!readField(i)) {
            return def;
        }
        return readParcelable();
    }

    public Bundle readBundle(Bundle bundle, int i) {
        Bundle def = bundle;
        if (!readField(i)) {
            return def;
        }
        return readBundle();
    }

    public void writeByte(byte b, int i) {
        byte val = b;
        setOutputField(i);
        writeInt(val);
    }

    @RequiresApi(api = 21)
    public void writeSize(Size size, int i) {
        Size val = size;
        setOutputField(i);
        writeBoolean(val != null);
        if (val != null) {
            writeInt(val.getWidth());
            writeInt(val.getHeight());
        }
    }

    @RequiresApi(api = 21)
    public void writeSizeF(SizeF sizeF, int i) {
        SizeF val = sizeF;
        setOutputField(i);
        writeBoolean(val != null);
        if (val != null) {
            writeFloat(val.getWidth());
            writeFloat(val.getHeight());
        }
    }

    public void writeSparseBooleanArray(SparseBooleanArray sparseBooleanArray, int i) {
        SparseBooleanArray val = sparseBooleanArray;
        setOutputField(i);
        if (val == null) {
            writeInt(-1);
            return;
        }
        int n = val.size();
        writeInt(n);
        for (int i2 = 0; i2 < n; i2++) {
            writeInt(val.keyAt(i2));
            writeBoolean(val.valueAt(i2));
        }
    }

    public void writeBooleanArray(boolean[] zArr, int i) {
        boolean[] val = zArr;
        setOutputField(i);
        writeBooleanArray(val);
    }

    /* access modifiers changed from: protected */
    public void writeBooleanArray(boolean[] zArr) {
        boolean[] val = zArr;
        if (val != null) {
            int n = val.length;
            writeInt(n);
            for (int i = 0; i < n; i++) {
                writeInt(val[i] ? 1 : 0);
            }
            return;
        }
        writeInt(-1);
    }

    public boolean[] readBooleanArray(boolean[] zArr, int i) {
        boolean[] def = zArr;
        if (!readField(i)) {
            return def;
        }
        return readBooleanArray();
    }

    /* access modifiers changed from: protected */
    public boolean[] readBooleanArray() {
        int n = readInt();
        if (n < 0) {
            return null;
        }
        boolean[] val = new boolean[n];
        for (int i = 0; i < n; i++) {
            val[i] = readInt() != 0;
        }
        return val;
    }

    public void writeCharArray(char[] cArr, int i) {
        char[] val = cArr;
        setOutputField(i);
        if (val != null) {
            int n = val.length;
            writeInt(n);
            for (int i2 = 0; i2 < n; i2++) {
                writeInt(val[i2]);
            }
            return;
        }
        writeInt(-1);
    }

    public char[] readCharArray(char[] cArr, int i) {
        char[] def = cArr;
        if (!readField(i)) {
            return def;
        }
        int n = readInt();
        if (n < 0) {
            return null;
        }
        char[] val = new char[n];
        for (int i2 = 0; i2 < n; i2++) {
            val[i2] = (char) readInt();
        }
        return val;
    }

    public void writeIntArray(int[] iArr, int i) {
        int[] val = iArr;
        setOutputField(i);
        writeIntArray(val);
    }

    /* access modifiers changed from: protected */
    public void writeIntArray(int[] iArr) {
        int[] val = iArr;
        if (val != null) {
            int n = val.length;
            writeInt(n);
            for (int i = 0; i < n; i++) {
                writeInt(val[i]);
            }
            return;
        }
        writeInt(-1);
    }

    public int[] readIntArray(int[] iArr, int i) {
        int[] def = iArr;
        if (!readField(i)) {
            return def;
        }
        return readIntArray();
    }

    /* access modifiers changed from: protected */
    public int[] readIntArray() {
        int n = readInt();
        if (n < 0) {
            return null;
        }
        int[] val = new int[n];
        for (int i = 0; i < n; i++) {
            val[i] = readInt();
        }
        return val;
    }

    public void writeLongArray(long[] jArr, int i) {
        long[] val = jArr;
        setOutputField(i);
        writeLongArray(val);
    }

    /* access modifiers changed from: protected */
    public void writeLongArray(long[] jArr) {
        long[] val = jArr;
        if (val != null) {
            int n = val.length;
            writeInt(n);
            for (int i = 0; i < n; i++) {
                writeLong(val[i]);
            }
            return;
        }
        writeInt(-1);
    }

    public long[] readLongArray(long[] jArr, int i) {
        long[] def = jArr;
        if (!readField(i)) {
            return def;
        }
        return readLongArray();
    }

    /* access modifiers changed from: protected */
    public long[] readLongArray() {
        int n = readInt();
        if (n < 0) {
            return null;
        }
        long[] val = new long[n];
        for (int i = 0; i < n; i++) {
            val[i] = readLong();
        }
        return val;
    }

    public void writeFloatArray(float[] fArr, int i) {
        float[] val = fArr;
        setOutputField(i);
        writeFloatArray(val);
    }

    /* access modifiers changed from: protected */
    public void writeFloatArray(float[] fArr) {
        float[] val = fArr;
        if (val != null) {
            int n = val.length;
            writeInt(n);
            for (int i = 0; i < n; i++) {
                writeFloat(val[i]);
            }
            return;
        }
        writeInt(-1);
    }

    public float[] readFloatArray(float[] fArr, int i) {
        float[] def = fArr;
        if (!readField(i)) {
            return def;
        }
        return readFloatArray();
    }

    /* access modifiers changed from: protected */
    public float[] readFloatArray() {
        int n = readInt();
        if (n < 0) {
            return null;
        }
        float[] val = new float[n];
        for (int i = 0; i < n; i++) {
            val[i] = readFloat();
        }
        return val;
    }

    public void writeDoubleArray(double[] dArr, int i) {
        double[] val = dArr;
        setOutputField(i);
        writeDoubleArray(val);
    }

    /* access modifiers changed from: protected */
    public void writeDoubleArray(double[] dArr) {
        double[] val = dArr;
        if (val != null) {
            int n = val.length;
            writeInt(n);
            for (int i = 0; i < n; i++) {
                writeDouble(val[i]);
            }
            return;
        }
        writeInt(-1);
    }

    public double[] readDoubleArray(double[] dArr, int i) {
        double[] def = dArr;
        if (!readField(i)) {
            return def;
        }
        return readDoubleArray();
    }

    /* access modifiers changed from: protected */
    public double[] readDoubleArray() {
        int n = readInt();
        if (n < 0) {
            return null;
        }
        double[] val = new double[n];
        for (int i = 0; i < n; i++) {
            val[i] = readDouble();
        }
        return val;
    }

    public <T> void writeSet(Set<T> set, int i) {
        writeCollection(set, i);
    }

    public <T> void writeList(List<T> list, int i) {
        writeCollection(list, i);
    }

    private <T> void writeCollection(Collection<T> collection, int i) {
        Collection<T> val = collection;
        setOutputField(i);
        if (val == null) {
            writeInt(-1);
            return;
        }
        int n = val.size();
        writeInt(n);
        if (n > 0) {
            int type = getType(val.iterator().next());
            writeInt(type);
            switch (type) {
                case 1:
                    for (T writeVersionedParcelable : val) {
                        writeVersionedParcelable(writeVersionedParcelable);
                    }
                    return;
                case 2:
                    for (T writeParcelable : val) {
                        writeParcelable(writeParcelable);
                    }
                    return;
                case 3:
                    for (T writeSerializable : val) {
                        writeSerializable(writeSerializable);
                    }
                    return;
                case 4:
                    for (T writeString : val) {
                        writeString(writeString);
                    }
                    return;
                case 5:
                    for (T writeStrongBinder : val) {
                        writeStrongBinder(writeStrongBinder);
                    }
                    return;
                default:
                    return;
            }
        }
    }

    public <T> void writeArray(T[] tArr, int i) {
        T[] val = tArr;
        setOutputField(i);
        writeArray(val);
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x003f, code lost:
        if (r3 >= r2) goto L_0x000a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0041, code lost:
        writeParcelable((android.os.Parcelable) r1[r3]);
        r3 = r3 + 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x0050, code lost:
        if (r3 >= r2) goto L_0x000a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0052, code lost:
        writeVersionedParcelable((androidx.versionedparcelable.VersionedParcelable) r1[r3]);
        r3 = r3 + 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0061, code lost:
        if (r3 >= r2) goto L_0x000a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0063, code lost:
        writeSerializable((java.io.Serializable) r1[r3]);
        r3 = r3 + 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0072, code lost:
        if (r3 >= r2) goto L_0x000a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0074, code lost:
        writeStrongBinder((android.os.IBinder) r1[r3]);
        r3 = r3 + 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x002e, code lost:
        if (r3 >= r2) goto L_0x000a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0030, code lost:
        writeString((java.lang.String) r1[r3]);
        r3 = r3 + 1;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public <T> void writeArray(T[] r9) {
        /*
            r8 = this;
            r0 = r8
            r1 = r9
            r5 = r1
            if (r5 != 0) goto L_0x000b
            r5 = r0
            r6 = -1
            r5.writeInt(r6)
        L_0x000a:
            return
        L_0x000b:
            r5 = r1
            int r5 = r5.length
            r2 = r5
            r5 = 0
            r3 = r5
            r5 = r0
            r6 = r2
            r5.writeInt(r6)
            r5 = r2
            if (r5 <= 0) goto L_0x002b
            r5 = r0
            r6 = r1
            r7 = 0
            r6 = r6[r7]
            int r5 = r5.getType(r6)
            r4 = r5
            r5 = r0
            r6 = r4
            r5.writeInt(r6)
            r5 = r4
            switch(r5) {
                case 1: goto L_0x004e;
                case 2: goto L_0x003d;
                case 3: goto L_0x005f;
                case 4: goto L_0x002c;
                case 5: goto L_0x0070;
                default: goto L_0x002b;
            }
        L_0x002b:
            goto L_0x000a
        L_0x002c:
            r5 = r3
            r6 = r2
            if (r5 >= r6) goto L_0x002b
            r5 = r0
            r6 = r1
            r7 = r3
            r6 = r6[r7]
            java.lang.String r6 = (java.lang.String) r6
            r5.writeString(r6)
            int r3 = r3 + 1
            goto L_0x002c
        L_0x003d:
            r5 = r3
            r6 = r2
            if (r5 >= r6) goto L_0x002b
            r5 = r0
            r6 = r1
            r7 = r3
            r6 = r6[r7]
            android.os.Parcelable r6 = (android.os.Parcelable) r6
            r5.writeParcelable(r6)
            int r3 = r3 + 1
            goto L_0x003d
        L_0x004e:
            r5 = r3
            r6 = r2
            if (r5 >= r6) goto L_0x002b
            r5 = r0
            r6 = r1
            r7 = r3
            r6 = r6[r7]
            androidx.versionedparcelable.VersionedParcelable r6 = (androidx.versionedparcelable.VersionedParcelable) r6
            r5.writeVersionedParcelable(r6)
            int r3 = r3 + 1
            goto L_0x004e
        L_0x005f:
            r5 = r3
            r6 = r2
            if (r5 >= r6) goto L_0x002b
            r5 = r0
            r6 = r1
            r7 = r3
            r6 = r6[r7]
            java.io.Serializable r6 = (java.io.Serializable) r6
            r5.writeSerializable(r6)
            int r3 = r3 + 1
            goto L_0x005f
        L_0x0070:
            r5 = r3
            r6 = r2
            if (r5 >= r6) goto L_0x002b
            r5 = r0
            r6 = r1
            r7 = r3
            r6 = r6[r7]
            android.os.IBinder r6 = (android.os.IBinder) r6
            r5.writeStrongBinder(r6)
            int r3 = r3 + 1
            goto L_0x0070
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.versionedparcelable.VersionedParcel.writeArray(java.lang.Object[]):void");
    }

    private <T> int getType(T t) {
        IllegalArgumentException illegalArgumentException;
        StringBuilder sb;
        T t2 = t;
        if (t2 instanceof String) {
            return 4;
        }
        if (t2 instanceof Parcelable) {
            return 2;
        }
        if (t2 instanceof VersionedParcelable) {
            return 1;
        }
        if (t2 instanceof Serializable) {
            return 3;
        }
        if (t2 instanceof IBinder) {
            return 5;
        }
        IllegalArgumentException illegalArgumentException2 = illegalArgumentException;
        StringBuilder sb2 = sb;
        StringBuilder sb3 = new StringBuilder();
        IllegalArgumentException illegalArgumentException3 = new IllegalArgumentException(sb2.append(t2.getClass().getName()).append(" cannot be VersionedParcelled").toString());
        throw illegalArgumentException2;
    }

    public void writeVersionedParcelable(VersionedParcelable versionedParcelable, int i) {
        VersionedParcelable p = versionedParcelable;
        setOutputField(i);
        writeVersionedParcelable(p);
    }

    /* access modifiers changed from: protected */
    public void writeVersionedParcelable(VersionedParcelable versionedParcelable) {
        VersionedParcelable p = versionedParcelable;
        if (p == null) {
            writeString(null);
            return;
        }
        writeVersionedParcelableCreator(p);
        VersionedParcel subParcel = createSubParcel();
        writeToParcel(p, subParcel);
        subParcel.closeField();
    }

    private void writeVersionedParcelableCreator(VersionedParcelable versionedParcelable) {
        RuntimeException runtimeException;
        StringBuilder sb;
        VersionedParcelable p = versionedParcelable;
        try {
            writeString(findParcelClass(p.getClass()).getName());
        } catch (ClassNotFoundException e) {
            ClassNotFoundException e2 = e;
            RuntimeException runtimeException2 = runtimeException;
            StringBuilder sb2 = sb;
            StringBuilder sb3 = new StringBuilder();
            RuntimeException runtimeException3 = new RuntimeException(sb2.append(p.getClass().getSimpleName()).append(" does not have a Parcelizer").toString(), e2);
            throw runtimeException2;
        }
    }

    public void writeSerializable(Serializable serializable, int i) {
        Serializable s = serializable;
        setOutputField(i);
        writeSerializable(s);
    }

    private void writeSerializable(Serializable serializable) {
        ByteArrayOutputStream byteArrayOutputStream;
        RuntimeException runtimeException;
        StringBuilder sb;
        ObjectOutputStream objectOutputStream;
        Serializable s = serializable;
        if (s == null) {
            writeString(null);
            return;
        }
        String name = s.getClass().getName();
        writeString(name);
        ByteArrayOutputStream byteArrayOutputStream2 = byteArrayOutputStream;
        ByteArrayOutputStream byteArrayOutputStream3 = new ByteArrayOutputStream();
        ByteArrayOutputStream baos = byteArrayOutputStream2;
        try {
            ObjectOutputStream objectOutputStream2 = objectOutputStream;
            ObjectOutputStream objectOutputStream3 = new ObjectOutputStream(baos);
            ObjectOutputStream oos = objectOutputStream2;
            oos.writeObject(s);
            oos.close();
            writeByteArray(baos.toByteArray());
        } catch (IOException e) {
            IOException ioe = e;
            RuntimeException runtimeException2 = runtimeException;
            StringBuilder sb2 = sb;
            StringBuilder sb3 = new StringBuilder();
            RuntimeException runtimeException3 = new RuntimeException(sb2.append("VersionedParcelable encountered IOException writing serializable object (name = ").append(name).append(")").toString(), ioe);
            throw runtimeException2;
        }
    }

    public void writeException(Exception exc, int i) {
        RuntimeException runtimeException;
        Exception e = exc;
        setOutputField(i);
        if (e == null) {
            writeNoException();
            return;
        }
        int code = 0;
        if ((e instanceof Parcelable) && e.getClass().getClassLoader() == Parcelable.class.getClassLoader()) {
            code = -9;
        } else if (e instanceof SecurityException) {
            code = -1;
        } else if (e instanceof BadParcelableException) {
            code = -2;
        } else if (e instanceof IllegalArgumentException) {
            code = -3;
        } else if (e instanceof NullPointerException) {
            code = -4;
        } else if (e instanceof IllegalStateException) {
            code = -5;
        } else if (e instanceof NetworkOnMainThreadException) {
            code = -6;
        } else if (e instanceof UnsupportedOperationException) {
            code = -7;
        }
        writeInt(code);
        if (code != 0) {
            writeString(e.getMessage());
            switch (code) {
                case -9:
                    writeParcelable((Parcelable) e);
                    return;
                default:
                    return;
            }
        } else if (e instanceof RuntimeException) {
            throw ((RuntimeException) e);
        } else {
            RuntimeException runtimeException2 = runtimeException;
            RuntimeException runtimeException3 = new RuntimeException(e);
            throw runtimeException2;
        }
    }

    /* access modifiers changed from: protected */
    public void writeNoException() {
        writeInt(0);
    }

    public Exception readException(Exception exc, int i) {
        Exception def = exc;
        if (!readField(i)) {
            return def;
        }
        int code = readExceptionCode();
        if (code == 0) {
            return def;
        }
        return readException(code, readString());
    }

    private int readExceptionCode() {
        return readInt();
    }

    private Exception readException(int i, String str) {
        return createException(i, str);
    }

    @NonNull
    protected static Throwable getRootCause(@NonNull Throwable th) {
        Throwable t = th;
        while (t.getCause() != null) {
            t = t.getCause();
        }
        return t;
    }

    private Exception createException(int i, String str) {
        UnsupportedOperationException unsupportedOperationException;
        NetworkOnMainThreadException networkOnMainThreadException;
        IllegalStateException illegalStateException;
        NullPointerException nullPointerException;
        IllegalArgumentException illegalArgumentException;
        BadParcelableException badParcelableException;
        SecurityException securityException;
        RuntimeException runtimeException;
        StringBuilder sb;
        int code = i;
        String msg = str;
        switch (code) {
            case -9:
                return (Exception) readParcelable();
            case -7:
                UnsupportedOperationException unsupportedOperationException2 = unsupportedOperationException;
                UnsupportedOperationException unsupportedOperationException3 = new UnsupportedOperationException(msg);
                return unsupportedOperationException2;
            case -6:
                NetworkOnMainThreadException networkOnMainThreadException2 = networkOnMainThreadException;
                NetworkOnMainThreadException networkOnMainThreadException3 = new NetworkOnMainThreadException();
                return networkOnMainThreadException2;
            case -5:
                IllegalStateException illegalStateException2 = illegalStateException;
                IllegalStateException illegalStateException3 = new IllegalStateException(msg);
                return illegalStateException2;
            case -4:
                NullPointerException nullPointerException2 = nullPointerException;
                NullPointerException nullPointerException3 = new NullPointerException(msg);
                return nullPointerException2;
            case -3:
                IllegalArgumentException illegalArgumentException2 = illegalArgumentException;
                IllegalArgumentException illegalArgumentException3 = new IllegalArgumentException(msg);
                return illegalArgumentException2;
            case -2:
                BadParcelableException badParcelableException2 = badParcelableException;
                BadParcelableException badParcelableException3 = new BadParcelableException(msg);
                return badParcelableException2;
            case -1:
                SecurityException securityException2 = securityException;
                SecurityException securityException3 = new SecurityException(msg);
                return securityException2;
            default:
                RuntimeException runtimeException2 = runtimeException;
                StringBuilder sb2 = sb;
                StringBuilder sb3 = new StringBuilder();
                RuntimeException runtimeException3 = new RuntimeException(sb2.append("Unknown exception code: ").append(code).append(" msg ").append(msg).toString());
                return runtimeException2;
        }
    }

    public byte readByte(byte b, int i) {
        byte def = b;
        if (!readField(i)) {
            return def;
        }
        return (byte) (readInt() & 255);
    }

    @RequiresApi(api = 21)
    public Size readSize(Size size, int i) {
        Size size2;
        Size def = size;
        if (!readField(i)) {
            return def;
        }
        if (!readBoolean()) {
            return null;
        }
        Size size3 = size2;
        Size size4 = new Size(readInt(), readInt());
        return size3;
    }

    @RequiresApi(api = 21)
    public SizeF readSizeF(SizeF sizeF, int i) {
        SizeF sizeF2;
        SizeF def = sizeF;
        if (!readField(i)) {
            return def;
        }
        if (!readBoolean()) {
            return null;
        }
        SizeF sizeF3 = sizeF2;
        SizeF sizeF4 = new SizeF(readFloat(), readFloat());
        return sizeF3;
    }

    public SparseBooleanArray readSparseBooleanArray(SparseBooleanArray sparseBooleanArray, int i) {
        SparseBooleanArray sparseBooleanArray2;
        SparseBooleanArray def = sparseBooleanArray;
        if (!readField(i)) {
            return def;
        }
        int n = readInt();
        if (n < 0) {
            return null;
        }
        SparseBooleanArray sparseBooleanArray3 = sparseBooleanArray2;
        SparseBooleanArray sparseBooleanArray4 = new SparseBooleanArray(n);
        SparseBooleanArray sa = sparseBooleanArray3;
        for (int i2 = 0; i2 < n; i2++) {
            sa.put(readInt(), readBoolean());
        }
        return sa;
    }

    public <T> Set<T> readSet(Set<T> set, int i) {
        C1526ArraySet arraySet;
        Set<T> def = set;
        int fieldId = i;
        if (!readField(fieldId)) {
            return def;
        }
        int i2 = fieldId;
        C1526ArraySet arraySet2 = arraySet;
        C1526ArraySet arraySet3 = new C1526ArraySet();
        return (Set) readCollection(i2, arraySet2);
    }

    public <T> List<T> readList(List<T> list, int i) {
        ArrayList arrayList;
        List<T> def = list;
        int fieldId = i;
        if (!readField(fieldId)) {
            return def;
        }
        int i2 = fieldId;
        ArrayList arrayList2 = arrayList;
        ArrayList arrayList3 = new ArrayList();
        return (List) readCollection(i2, arrayList2);
    }

    /* Code decompiled incorrectly, please refer to instructions dump. */
    private <T, S extends java.util.Collection<T>> S readCollection(int r8, S r9) {
        /*
            r7 = this;
            r0 = r7
            r1 = r8
            r2 = r9
            r5 = r0
            int r5 = r5.readInt()
            r3 = r5
            r5 = r3
            if (r5 >= 0) goto L_0x000f
            r5 = 0
            r0 = r5
        L_0x000e:
            return r0
        L_0x000f:
            r5 = r3
            if (r5 == 0) goto L_0x0022
            r5 = r0
            int r5 = r5.readInt()
            r4 = r5
            r5 = r3
            if (r5 >= 0) goto L_0x001e
            r5 = 0
            r0 = r5
            goto L_0x000e
        L_0x001e:
            r5 = r4
            switch(r5) {
                case 1: goto L_0x0045;
                case 2: goto L_0x0035;
                case 3: goto L_0x0055;
                case 4: goto L_0x0025;
                case 5: goto L_0x0065;
                default: goto L_0x0022;
            }
        L_0x0022:
            r5 = r2
            r0 = r5
            goto L_0x000e
        L_0x0025:
            r5 = r3
            if (r5 <= 0) goto L_0x0022
            r5 = r2
            r6 = r0
            java.lang.String r6 = r6.readString()
            boolean r5 = r5.add(r6)
            int r3 = r3 + -1
            goto L_0x0025
        L_0x0035:
            r5 = r3
            if (r5 <= 0) goto L_0x0022
            r5 = r2
            r6 = r0
            android.os.Parcelable r6 = r6.readParcelable()
            boolean r5 = r5.add(r6)
            int r3 = r3 + -1
            goto L_0x0035
        L_0x0045:
            r5 = r3
            if (r5 <= 0) goto L_0x0022
            r5 = r2
            r6 = r0
            androidx.versionedparcelable.VersionedParcelable r6 = r6.readVersionedParcelable()
            boolean r5 = r5.add(r6)
            int r3 = r3 + -1
            goto L_0x0045
        L_0x0055:
            r5 = r3
            if (r5 <= 0) goto L_0x0022
            r5 = r2
            r6 = r0
            java.io.Serializable r6 = r6.readSerializable()
            boolean r5 = r5.add(r6)
            int r3 = r3 + -1
            goto L_0x0055
        L_0x0065:
            r5 = r3
            if (r5 <= 0) goto L_0x0022
            r5 = r2
            r6 = r0
            android.os.IBinder r6 = r6.readStrongBinder()
            boolean r5 = r5.add(r6)
            int r3 = r3 + -1
            goto L_0x0065
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.versionedparcelable.VersionedParcel.readCollection(int, java.util.Collection):java.util.Collection");
    }

    public <T> T[] readArray(T[] tArr, int i) {
        T[] def = tArr;
        if (!readField(i)) {
            return def;
        }
        return readArray(def);
    }

    /* access modifiers changed from: protected */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public <T> T[] readArray(T[] r10) {
        /*
            r9 = this;
            r0 = r9
            r1 = r10
            r5 = r0
            int r5 = r5.readInt()
            r2 = r5
            r5 = r2
            if (r5 >= 0) goto L_0x000e
            r5 = 0
            r0 = r5
        L_0x000d:
            return r0
        L_0x000e:
            java.util.ArrayList r5 = new java.util.ArrayList
            r8 = r5
            r5 = r8
            r6 = r8
            r7 = r2
            r6.<init>(r7)
            r3 = r5
            r5 = r2
            if (r5 == 0) goto L_0x002b
            r5 = r0
            int r5 = r5.readInt()
            r4 = r5
            r5 = r2
            if (r5 >= 0) goto L_0x0027
            r5 = 0
            r0 = r5
            goto L_0x000d
        L_0x0027:
            r5 = r4
            switch(r5) {
                case 1: goto L_0x0053;
                case 2: goto L_0x0043;
                case 3: goto L_0x0063;
                case 4: goto L_0x0033;
                case 5: goto L_0x0073;
                default: goto L_0x002b;
            }
        L_0x002b:
            r5 = r3
            r6 = r1
            java.lang.Object[] r5 = r5.toArray(r6)
            r0 = r5
            goto L_0x000d
        L_0x0033:
            r5 = r2
            if (r5 <= 0) goto L_0x002b
            r5 = r3
            r6 = r0
            java.lang.String r6 = r6.readString()
            boolean r5 = r5.add(r6)
            int r2 = r2 + -1
            goto L_0x0033
        L_0x0043:
            r5 = r2
            if (r5 <= 0) goto L_0x002b
            r5 = r3
            r6 = r0
            android.os.Parcelable r6 = r6.readParcelable()
            boolean r5 = r5.add(r6)
            int r2 = r2 + -1
            goto L_0x0043
        L_0x0053:
            r5 = r2
            if (r5 <= 0) goto L_0x002b
            r5 = r3
            r6 = r0
            androidx.versionedparcelable.VersionedParcelable r6 = r6.readVersionedParcelable()
            boolean r5 = r5.add(r6)
            int r2 = r2 + -1
            goto L_0x0053
        L_0x0063:
            r5 = r2
            if (r5 <= 0) goto L_0x002b
            r5 = r3
            r6 = r0
            java.io.Serializable r6 = r6.readSerializable()
            boolean r5 = r5.add(r6)
            int r2 = r2 + -1
            goto L_0x0063
        L_0x0073:
            r5 = r2
            if (r5 <= 0) goto L_0x002b
            r5 = r3
            r6 = r0
            android.os.IBinder r6 = r6.readStrongBinder()
            boolean r5 = r5.add(r6)
            int r2 = r2 + -1
            goto L_0x0073
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.versionedparcelable.VersionedParcel.readArray(java.lang.Object[]):java.lang.Object[]");
    }

    public <T extends VersionedParcelable> T readVersionedParcelable(T t, int i) {
        VersionedParcel def = t;
        if (!readField(i)) {
            return def;
        }
        return readVersionedParcelable();
    }

    /* access modifiers changed from: protected */
    public <T extends VersionedParcelable> T readVersionedParcelable() {
        String name = readString();
        if (name == null) {
            return null;
        }
        return readFromParcel(name, createSubParcel());
    }

    /* access modifiers changed from: protected */
    public Serializable readSerializable() {
        ByteArrayInputStream byteArrayInputStream;
        RuntimeException runtimeException;
        StringBuilder sb;
        RuntimeException runtimeException2;
        StringBuilder sb2;
        C05291 r9;
        String name = readString();
        if (name == null) {
            return null;
        }
        ByteArrayInputStream byteArrayInputStream2 = byteArrayInputStream;
        ByteArrayInputStream byteArrayInputStream3 = new ByteArrayInputStream(readByteArray());
        ByteArrayInputStream bais = byteArrayInputStream2;
        try {
            C05291 r5 = r9;
            C05291 r6 = new ObjectInputStream(this, bais) {
                final /* synthetic */ VersionedParcel this$0;

                {
                    InputStream x0 = r7;
                    this.this$0 = r6;
                }

                /* access modifiers changed from: protected */
                public Class<?> resolveClass(ObjectStreamClass objectStreamClass) throws IOException, ClassNotFoundException {
                    ObjectStreamClass osClass = objectStreamClass;
                    Class cls = Class.forName(osClass.getName(), false, getClass().getClassLoader());
                    if (cls != null) {
                        return cls;
                    }
                    return super.resolveClass(osClass);
                }
            };
            return (Serializable) r5.readObject();
        } catch (IOException e) {
            IOException ioe = e;
            RuntimeException runtimeException3 = runtimeException2;
            StringBuilder sb3 = sb2;
            StringBuilder sb4 = new StringBuilder();
            RuntimeException runtimeException4 = new RuntimeException(sb3.append("VersionedParcelable encountered IOException reading a Serializable object (name = ").append(name).append(")").toString(), ioe);
            throw runtimeException3;
        } catch (ClassNotFoundException e2) {
            ClassNotFoundException cnfe = e2;
            RuntimeException runtimeException5 = runtimeException;
            StringBuilder sb5 = sb;
            StringBuilder sb6 = new StringBuilder();
            RuntimeException runtimeException6 = new RuntimeException(sb5.append("VersionedParcelable encountered ClassNotFoundException reading a Serializable object (name = ").append(name).append(")").toString(), cnfe);
            throw runtimeException5;
        }
    }

    protected static <T extends VersionedParcelable> T readFromParcel(String str, VersionedParcel versionedParcel) {
        RuntimeException runtimeException;
        RuntimeException runtimeException2;
        RuntimeException runtimeException3;
        RuntimeException runtimeException4;
        VersionedParcel versionedParcel2 = versionedParcel;
        String str2 = str;
        try {
            Class[] clsArr = new Class[1];
            Class[] clsArr2 = clsArr;
            clsArr[0] = VersionedParcel.class;
            Method declaredMethod = Class.forName(str2, true, VersionedParcel.class.getClassLoader()).getDeclaredMethod("read", clsArr2);
            Object[] objArr = new Object[1];
            Object[] objArr2 = objArr;
            objArr[0] = versionedParcel2;
            return (VersionedParcelable) declaredMethod.invoke(null, objArr2);
        } catch (IllegalAccessException e) {
            IllegalAccessException e2 = e;
            RuntimeException runtimeException5 = runtimeException4;
            RuntimeException runtimeException6 = new RuntimeException("VersionedParcel encountered IllegalAccessException", e2);
            throw runtimeException5;
        } catch (InvocationTargetException e3) {
            InvocationTargetException e4 = e3;
            if (e4.getCause() instanceof RuntimeException) {
                throw ((RuntimeException) e4.getCause());
            }
            RuntimeException runtimeException7 = runtimeException3;
            RuntimeException runtimeException8 = new RuntimeException("VersionedParcel encountered InvocationTargetException", e4);
            throw runtimeException7;
        } catch (NoSuchMethodException e5) {
            NoSuchMethodException e6 = e5;
            RuntimeException runtimeException9 = runtimeException2;
            RuntimeException runtimeException10 = new RuntimeException("VersionedParcel encountered NoSuchMethodException", e6);
            throw runtimeException9;
        } catch (ClassNotFoundException e7) {
            ClassNotFoundException e8 = e7;
            RuntimeException runtimeException11 = runtimeException;
            RuntimeException runtimeException12 = new RuntimeException("VersionedParcel encountered ClassNotFoundException", e8);
            throw runtimeException11;
        }
    }

    protected static <T extends VersionedParcelable> void writeToParcel(T t, VersionedParcel versionedParcel) {
        RuntimeException runtimeException;
        RuntimeException runtimeException2;
        RuntimeException runtimeException3;
        RuntimeException runtimeException4;
        T val = t;
        VersionedParcel versionedParcel2 = versionedParcel;
        try {
            Class[] clsArr = new Class[2];
            Class[] clsArr2 = clsArr;
            clsArr[0] = val.getClass();
            Class[] clsArr3 = clsArr2;
            Class[] clsArr4 = clsArr3;
            clsArr3[1] = VersionedParcel.class;
            Method declaredMethod = findParcelClass(val).getDeclaredMethod("write", clsArr4);
            Object[] objArr = new Object[2];
            Object[] objArr2 = objArr;
            objArr[0] = val;
            Object[] objArr3 = objArr2;
            Object[] objArr4 = objArr3;
            objArr3[1] = versionedParcel2;
            Object invoke = declaredMethod.invoke(null, objArr4);
        } catch (IllegalAccessException e) {
            IllegalAccessException e2 = e;
            RuntimeException runtimeException5 = runtimeException4;
            RuntimeException runtimeException6 = new RuntimeException("VersionedParcel encountered IllegalAccessException", e2);
            throw runtimeException5;
        } catch (InvocationTargetException e3) {
            InvocationTargetException e4 = e3;
            if (e4.getCause() instanceof RuntimeException) {
                throw ((RuntimeException) e4.getCause());
            }
            RuntimeException runtimeException7 = runtimeException3;
            RuntimeException runtimeException8 = new RuntimeException("VersionedParcel encountered InvocationTargetException", e4);
            throw runtimeException7;
        } catch (NoSuchMethodException e5) {
            NoSuchMethodException e6 = e5;
            RuntimeException runtimeException9 = runtimeException2;
            RuntimeException runtimeException10 = new RuntimeException("VersionedParcel encountered NoSuchMethodException", e6);
            throw runtimeException9;
        } catch (ClassNotFoundException e7) {
            ClassNotFoundException e8 = e7;
            RuntimeException runtimeException11 = runtimeException;
            RuntimeException runtimeException12 = new RuntimeException("VersionedParcel encountered ClassNotFoundException", e8);
            throw runtimeException11;
        }
    }

    private static <T extends VersionedParcelable> Class findParcelClass(T t) throws ClassNotFoundException {
        return findParcelClass(t.getClass());
    }

    private static Class findParcelClass(Class<? extends VersionedParcelable> cls) throws ClassNotFoundException {
        Class<? extends VersionedParcelable> cls2 = cls;
        Object[] objArr = new Object[2];
        Object[] objArr2 = objArr;
        objArr[0] = cls2.getPackage().getName();
        Object[] objArr3 = objArr2;
        Object[] objArr4 = objArr3;
        objArr3[1] = cls2.getSimpleName();
        return Class.forName(String.format("%s.%sParcelizer", objArr4), false, cls2.getClassLoader());
    }
}
