package androidx.versionedparcelable;

/* renamed from: androidx.versionedparcelable.R */
public final class C0528R {
    public C0528R() {
    }
}
